--
-- PostgreSQL database dump
--

\restrict uHcQ3dbBZMslDeXLaYjNygH4dvSwNSk0lWKo2oygce2mJjVOgLFoCzNjdNn8tWg

-- Dumped from database version 15.18 (Debian 15.18-1.pgdg13+1)
-- Dumped by pg_dump version 15.18 (Debian 15.18-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_sessions DROP CONSTRAINT IF EXISTS user_sessions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_images DROP CONSTRAINT IF EXISTS user_images_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.template_segments DROP CONSTRAINT IF EXISTS template_segments_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subscription_records DROP CONSTRAINT IF EXISTS subscription_records_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.smtp_configs DROP CONSTRAINT IF EXISTS smtp_configs_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.send_rate_limits DROP CONSTRAINT IF EXISTS send_rate_limits_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.posts DROP CONSTRAINT IF EXISTS posts_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.posts DROP CONSTRAINT IF EXISTS posts_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS password_reset_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.message_templates DROP CONSTRAINT IF EXISTS message_templates_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.message_templates DROP CONSTRAINT IF EXISTS message_templates_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.message_queue DROP CONSTRAINT IF EXISTS message_queue_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.message_history DROP CONSTRAINT IF EXISTS message_history_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.message_groups DROP CONSTRAINT IF EXISTS message_groups_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.email_verification_tokens DROP CONSTRAINT IF EXISTS email_verification_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contacts DROP CONSTRAINT IF EXISTS contacts_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contacts DROP CONSTRAINT IF EXISTS contacts_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.birthday_schedules DROP CONSTRAINT IF EXISTS birthday_schedules_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.birthday_configs DROP CONSTRAINT IF EXISTS birthday_configs_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.birthday_configs DROP CONSTRAINT IF EXISTS birthday_configs_post_id_fkey;
ALTER TABLE IF EXISTS ONLY public.birthday_configs DROP CONSTRAINT IF EXISTS birthday_configs_message_group_id_fkey;
DROP INDEX IF EXISTS public.uq_post_user_label;
DROP INDEX IF EXISTS public.uq_message_template_user_title;
DROP INDEX IF EXISTS public.uq_contact_user_profile_url;
DROP INDEX IF EXISTS public.uniq_schedule_user_days;
DROP INDEX IF EXISTS public.uniq_birthday_config_user_mode_offset;
DROP INDEX IF EXISTS public.uniq_active_subscription_per_user;
DROP INDEX IF EXISTS public.idx_user_sessions_user_revoked;
DROP INDEX IF EXISTS public.idx_user_sessions_user_last_seen;
DROP INDEX IF EXISTS public.idx_user_sessions_expires;
DROP INDEX IF EXISTS public.idx_user_image_user_created;
DROP INDEX IF EXISTS public.idx_user_image_source;
DROP INDEX IF EXISTS public.idx_template_user_type;
DROP INDEX IF EXISTS public.idx_template_user_deleted;
DROP INDEX IF EXISTS public.idx_subscription_user_status;
DROP INDEX IF EXISTS public.idx_subscription_user;
DROP INDEX IF EXISTS public.idx_smtp_config_user;
DROP INDEX IF EXISTS public.idx_send_rate_limit_user;
DROP INDEX IF EXISTS public.idx_schedule_user_enabled;
DROP INDEX IF EXISTS public.idx_revoked_jti;
DROP INDEX IF EXISTS public.idx_revoked_expires;
DROP INDEX IF EXISTS public.idx_reset_user_created;
DROP INDEX IF EXISTS public.idx_reset_token_expires;
DROP INDEX IF EXISTS public.idx_queue_user_status;
DROP INDEX IF EXISTS public.idx_queue_scheduled_time;
DROP INDEX IF EXISTS public.idx_post_user_gender;
DROP INDEX IF EXISTS public.idx_post_user_default;
DROP INDEX IF EXISTS public.idx_post_group;
DROP INDEX IF EXISTS public.idx_message_template_user_gender;
DROP INDEX IF EXISTS public.idx_message_template_user;
DROP INDEX IF EXISTS public.idx_message_template_group;
DROP INDEX IF EXISTS public.idx_message_group_user;
DROP INDEX IF EXISTS public.idx_history_user_status;
DROP INDEX IF EXISTS public.idx_history_user_sent;
DROP INDEX IF EXISTS public.idx_email_verif_user_created;
DROP INDEX IF EXISTS public.idx_email_verif_token_expires;
DROP INDEX IF EXISTS public.idx_contact_user_gender;
DROP INDEX IF EXISTS public.idx_contact_user_birthday;
DROP INDEX IF EXISTS public.idx_contact_group;
DROP INDEX IF EXISTS public.idx_birthday_config_user_mode;
DROP INDEX IF EXISTS public.idx_birthday_config_user_enabled;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_sessions DROP CONSTRAINT IF EXISTS user_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.user_sessions DROP CONSTRAINT IF EXISTS user_sessions_current_refresh_token_jti_key;
ALTER TABLE IF EXISTS ONLY public.user_images DROP CONSTRAINT IF EXISTS user_images_pkey;
ALTER TABLE IF EXISTS ONLY public.template_segments DROP CONSTRAINT IF EXISTS template_segments_pkey;
ALTER TABLE IF EXISTS ONLY public.subscription_records DROP CONSTRAINT IF EXISTS subscription_records_pkey;
ALTER TABLE IF EXISTS ONLY public.smtp_configs DROP CONSTRAINT IF EXISTS smtp_configs_user_id_key;
ALTER TABLE IF EXISTS ONLY public.smtp_configs DROP CONSTRAINT IF EXISTS smtp_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.send_rate_limits DROP CONSTRAINT IF EXISTS send_rate_limits_user_id_key;
ALTER TABLE IF EXISTS ONLY public.send_rate_limits DROP CONSTRAINT IF EXISTS send_rate_limits_pkey;
ALTER TABLE IF EXISTS ONLY public.revoked_tokens DROP CONSTRAINT IF EXISTS revoked_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.posts DROP CONSTRAINT IF EXISTS posts_pkey;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS password_reset_tokens_token_key;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS password_reset_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.message_templates DROP CONSTRAINT IF EXISTS message_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.message_queue DROP CONSTRAINT IF EXISTS message_queue_pkey;
ALTER TABLE IF EXISTS ONLY public.message_history DROP CONSTRAINT IF EXISTS message_history_pkey;
ALTER TABLE IF EXISTS ONLY public.message_groups DROP CONSTRAINT IF EXISTS message_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.email_verification_tokens DROP CONSTRAINT IF EXISTS email_verification_tokens_token_key;
ALTER TABLE IF EXISTS ONLY public.email_verification_tokens DROP CONSTRAINT IF EXISTS email_verification_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.contacts DROP CONSTRAINT IF EXISTS contacts_pkey;
ALTER TABLE IF EXISTS ONLY public.birthday_schedules DROP CONSTRAINT IF EXISTS birthday_schedules_pkey;
ALTER TABLE IF EXISTS ONLY public.birthday_configs DROP CONSTRAINT IF EXISTS birthday_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_sessions;
DROP TABLE IF EXISTS public.user_images;
DROP TABLE IF EXISTS public.template_segments;
DROP TABLE IF EXISTS public.subscription_records;
DROP TABLE IF EXISTS public.smtp_configs;
DROP TABLE IF EXISTS public.send_rate_limits;
DROP TABLE IF EXISTS public.revoked_tokens;
DROP TABLE IF EXISTS public.posts;
DROP TABLE IF EXISTS public.password_reset_tokens;
DROP TABLE IF EXISTS public.message_templates;
DROP TABLE IF EXISTS public.message_queue;
DROP TABLE IF EXISTS public.message_history;
DROP TABLE IF EXISTS public.message_groups;
DROP TABLE IF EXISTS public.email_verification_tokens;
DROP TABLE IF EXISTS public.contacts;
DROP TABLE IF EXISTS public.birthday_schedules;
DROP TABLE IF EXISTS public.birthday_configs;
DROP TABLE IF EXISTS public.alembic_version;
DROP TYPE IF EXISTS public.subscription_status_enum;
DROP TYPE IF EXISTS public.segment_type_enum;
DROP TYPE IF EXISTS public.message_status_enum;
DROP TYPE IF EXISTS public.gender_enum;
DROP TYPE IF EXISTS public.birthday_mode_enum;
DROP EXTENSION IF EXISTS citext;
--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: birthday_mode_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.birthday_mode_enum AS ENUM (
    'EARLY',
    'ON_DAY',
    'BELATED'
);


--
-- Name: gender_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.gender_enum AS ENUM (
    'MALE',
    'FEMALE',
    'NEUTRAL',
    'ALL'
);


--
-- Name: message_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.message_status_enum AS ENUM (
    'pending',
    'processing',
    'sent',
    'delivered',
    'failed'
);


--
-- Name: segment_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.segment_type_enum AS ENUM (
    'GREETING',
    'BODY',
    'CLOSING'
);


--
-- Name: subscription_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.subscription_status_enum AS ENUM (
    'ACTIVE',
    'TRIALING',
    'PAST_DUE',
    'CANCELED',
    'UNPAID',
    'INCOMPLETE',
    'INCOMPLETE_EXPIRED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: birthday_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.birthday_configs (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    mode public.birthday_mode_enum NOT NULL,
    days_offset integer NOT NULL,
    message_group_id uuid,
    post_id uuid,
    gender_filter public.gender_enum NOT NULL,
    archive_enabled boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: birthday_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.birthday_schedules (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    days_before integer NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    facebook_profile_url text NOT NULL,
    birthday timestamp with time zone NOT NULL,
    gender public.gender_enum,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    birthday_month_only boolean DEFAULT false NOT NULL,
    group_id uuid
);


--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_verification_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: message_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_groups (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    color text DEFAULT '#6b7280'::text NOT NULL
);


--
-- Name: message_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_history (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friend_name text NOT NULL,
    friend_profile_url text NOT NULL,
    birthday_date timestamp with time zone NOT NULL,
    message_content text NOT NULL,
    sent_at timestamp with time zone DEFAULT now() NOT NULL,
    status public.message_status_enum DEFAULT 'sent'::public.message_status_enum NOT NULL,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: message_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_queue (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friend_name text NOT NULL,
    friend_profile_url text NOT NULL,
    birthday_date timestamp with time zone NOT NULL,
    scheduled_send_time timestamp with time zone NOT NULL,
    message_content text NOT NULL,
    status public.message_status_enum DEFAULT 'pending'::public.message_status_enum NOT NULL,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: message_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_templates (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title text NOT NULL,
    greeting text NOT NULL,
    sentiment text NOT NULL,
    closing text NOT NULL,
    image_url text,
    days_in_advance integer DEFAULT 0 NOT NULL,
    gender public.gender_enum DEFAULT 'ALL'::public.gender_enum NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    group_id uuid
);


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.posts (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    content text NOT NULL,
    image_url text,
    gender public.gender_enum NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    label text,
    font_family text DEFAULT 'Arial'::text,
    font_size integer DEFAULT 48,
    font_color text DEFAULT '#ffffff'::text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    group_id uuid
);


--
-- Name: revoked_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.revoked_tokens (
    id uuid NOT NULL,
    refresh_token_jti character varying(64) NOT NULL,
    user_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: send_rate_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.send_rate_limits (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    timestamps json DEFAULT '[]'::json NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: smtp_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smtp_configs (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    host text NOT NULL,
    port integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    use_tls boolean DEFAULT true NOT NULL,
    from_email text NOT NULL,
    from_name text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: subscription_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_records (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    status public.subscription_status_enum NOT NULL,
    price_id character varying NOT NULL,
    stripe_subscription_id character varying NOT NULL,
    stripe_customer_id character varying NOT NULL,
    current_period_start timestamp with time zone,
    current_period_end timestamp with time zone,
    cancel_at_period_end boolean DEFAULT false NOT NULL,
    canceled_at timestamp with time zone,
    trial_end timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata json DEFAULT '{}'::json NOT NULL
);


--
-- Name: template_segments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.template_segments (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    segment_type public.segment_type_enum NOT NULL,
    label text,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: user_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_images (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    url text NOT NULL,
    filename text NOT NULL,
    size integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    source character varying(32) DEFAULT 'library'::character varying NOT NULL
);


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    current_refresh_token_jti character varying(64) NOT NULL,
    ip_address character varying(64),
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    revoked_reason character varying(50)
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email public.citext NOT NULL,
    password_hash text NOT NULL,
    stripe_customer_id character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_login_at timestamp with time zone,
    metadata json DEFAULT '{}'::json NOT NULL,
    failed_login_count integer DEFAULT 0 NOT NULL,
    locked_until timestamp with time zone,
    email_verified boolean DEFAULT false NOT NULL
);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
i9j0k1l2m3n4
\.


--
-- Data for Name: birthday_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.birthday_configs (id, user_id, mode, days_offset, message_group_id, post_id, gender_filter, archive_enabled, enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: birthday_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.birthday_schedules (id, user_id, days_before, enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts (id, user_id, name, facebook_profile_url, birthday, gender, notes, created_at, updated_at, birthday_month_only, group_id) FROM stdin;
4ac45607-14f9-438e-b632-0c93ded65548	321816a3-3698-4041-8cd9-7b6d17aedae1	Shabnam Shaikh	https://www.facebook.com/profile.php?id=100029672222817	2000-10-01 00:00:00+00	\N	\N	2026-05-27 15:33:39.555022+00	2026-05-27 15:34:07.095921+00	t	\N
be4fd9df-43c4-433b-b328-ad8b5523133b	321816a3-3698-4041-8cd9-7b6d17aedae1	UnreadYou have a new friend suggestion: Sanem Shaikh.4w	https://www.facebook.com/profile.php?id=61565752040875	2000-06-23 00:00:00+00	\N	\N	2026-06-25 14:49:48.398998+00	2026-06-25 14:50:41.181893+00	f	\N
1f7be00b-b0bb-4ccb-9745-fdc28ee365e5	321816a3-3698-4041-8cd9-7b6d17aedae1	अजय वाघमोडे	https://www.facebook.com/profile.php?id=100073466310443	2026-06-18 00:00:00+00	\N	\N	2026-05-27 15:33:39.555022+00	2026-07-11 13:17:39.54323+00	f	\N
2daf76df-f103-4679-9919-ac1de203a474	321816a3-3698-4041-8cd9-7b6d17aedae1	Er Praveen Satpute	https://www.facebook.com/ErPravinsatpute	2000-10-01 00:00:00+00	\N	\N	2026-05-27 15:33:39.555022+00	2026-07-11 13:17:39.54323+00	t	\N
76eb1ae7-247b-4fa4-9a51-0e838a91c18c	321816a3-3698-4041-8cd9-7b6d17aedae1	Ajay Bhoi	https://www.facebook.com/ajay.bhoi.10048	2000-04-01 00:00:00+00	\N	\N	2026-05-27 15:33:39.555022+00	2026-07-11 13:17:39.54323+00	t	\N
7d060e1b-2903-4ec5-9401-ca16719c7af4	321816a3-3698-4041-8cd9-7b6d17aedae1	Farhan Shaikh	https://www.facebook.com/profile.php?id=100005759854714	2000-01-01 00:00:00+00	\N	\N	2026-05-27 15:33:39.555022+00	2026-07-11 13:17:39.54323+00	t	\N
83c3f992-78e1-47eb-8697-069ffff8a425	321816a3-3698-4041-8cd9-7b6d17aedae1	Sabir Khan	https://www.facebook.com/sabir.khan.33865	2000-09-01 00:00:00+00	\N	\N	2026-05-27 15:33:39.555022+00	2026-07-11 13:17:39.54323+00	t	\N
9fac1bf4-0ea5-48db-acce-850d83de8708	321816a3-3698-4041-8cd9-7b6d17aedae1	Mohin Mohin	https://www.facebook.com/mohin.mohin.628162	2000-04-01 00:00:00+00	\N	\N	2026-05-27 15:33:39.555022+00	2026-07-11 13:17:39.54323+00	t	\N
b32c12a2-1ee4-4c6a-9c7f-1411da994140	321816a3-3698-4041-8cd9-7b6d17aedae1	Aslam Pathan	https://www.facebook.com/aslam.pathan.5070	2000-06-01 00:00:00+00	\N	\N	2026-05-27 15:33:39.555022+00	2026-07-11 13:17:39.54323+00	t	\N
c781205f-c023-466a-be97-6bbb3f65484c	321816a3-3698-4041-8cd9-7b6d17aedae1	Aman Ali	https://www.facebook.com/mdsahadamanali.ali	2000-01-01 00:00:00+00	\N	\N	2026-05-27 15:33:39.555022+00	2026-07-11 13:17:39.54323+00	t	\N
d47667da-da71-44b3-aacd-969e4528ed54	321816a3-3698-4041-8cd9-7b6d17aedae1	Gorakh More	https://www.facebook.com/profile.php?id=100088150615674	2000-06-01 00:00:00+00	\N	\N	2026-05-27 15:33:39.555022+00	2026-07-11 13:17:39.54323+00	t	\N
e014192c-fc7c-4b48-b2af-28d02389705d	321816a3-3698-4041-8cd9-7b6d17aedae1	Arfan Shaikh	https://www.facebook.com/profile.php?id=100013539643658	2000-03-01 00:00:00+00	\N	\N	2026-05-27 15:33:39.555022+00	2026-07-11 13:17:39.54323+00	t	\N
e7fea746-f1b0-4c04-912b-61bcc20c27c7	321816a3-3698-4041-8cd9-7b6d17aedae1	Bazil Nachan	https://www.facebook.com/bazil.nachan	2000-10-01 00:00:00+00	\N	\N	2026-07-11 13:17:39.538294+00	2026-07-11 13:17:39.538294+00	t	\N
eb8ad953-e909-4312-92a1-244137ee2250	321816a3-3698-4041-8cd9-7b6d17aedae1	Nitesh Jadhav	https://www.facebook.com/nitesh.jadhav.601685	2000-05-01 00:00:00+00	\N	\N	2026-07-11 13:17:39.538294+00	2026-07-11 13:17:39.538294+00	t	\N
5e15f0be-7e0c-45f4-b5be-c4d64a3e48ea	321816a3-3698-4041-8cd9-7b6d17aedae1	Waseem Baksh, 15 July 2000	https://www.facebook.com/waseem.baksh.125	2026-07-11 00:00:00+00	\N	\N	2026-05-27 15:33:39.555022+00	2026-07-11 13:17:40.95233+00	f	\N
c4bfc7db-2423-4805-8b11-06ac40d7b591	321816a3-3698-4041-8cd9-7b6d17aedae1	Nab Fam, 16 July 2001	https://www.facebook.com/profile.php?id=100093180366200	2026-07-11 00:00:00+00	\N	\N	2026-05-27 15:33:39.555022+00	2026-07-11 13:17:40.95233+00	f	\N
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_verification_tokens (id, user_id, token, expires_at, used_at, created_at) FROM stdin;
bafee40e-c105-4e14-b477-d9ccbd1f4928	bd8cdd8f-9067-4946-b87b-57a69cc86259	d707f0bac774c0dd976b798ecdec4cc3383befdf741efbdb61715bc9853c2a39	2026-05-27 10:02:55.102236+00	\N	2026-05-26 10:02:55.102247+00
3fb37fa8-b5e6-4b95-887a-e9edec32e033	f4ea36a4-0da7-444d-9146-f0f962dc1a09	89eca9e28ed3c9d413922bd265a8cb5b7d98d7fde92312a30b5a65e154fb1fe4	2026-05-28 12:19:49.842484+00	\N	2026-05-27 12:19:49.842495+00
95d47899-763e-44c7-8f83-c1ce0cbf4558	bd8cdd8f-9067-4946-b87b-57a69cc86259	8469c651aa23b80772849be62d5201dfe88a2f06e5ccc099a6a4ab92d64602ab	2026-05-28 15:15:50.601974+00	\N	2026-05-27 15:15:50.601984+00
d2de20fb-c60a-455c-810c-65455828e817	321816a3-3698-4041-8cd9-7b6d17aedae1	5a0bb03fd175af344adc307c339ec8b0ac4ccccd58cf23e8758241dc17021265	2026-05-28 15:28:13.698038+00	2026-05-27 15:29:45.368726+00	2026-05-27 15:28:13.69805+00
\.


--
-- Data for Name: message_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_groups (id, user_id, name, created_at, updated_at, color) FROM stdin;
\.


--
-- Data for Name: message_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_history (id, user_id, friend_name, friend_profile_url, birthday_date, message_content, sent_at, status, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: message_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_queue (id, user_id, friend_name, friend_profile_url, birthday_date, scheduled_send_time, message_content, status, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: message_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_templates (id, user_id, title, greeting, sentiment, closing, image_url, days_in_advance, gender, created_at, updated_at, group_id) FROM stdin;
c10d7836-fd52-4706-b8e7-7c9239063ada	321816a3-3698-4041-8cd9-7b6d17aedae1	simple birthday	Wishing you the happiest of birthdays, {First_Name}!	Another year of amazing memories together! You're one of a kind and I hope this year brings you everything you wish for.	Wishing you the best and happy birthday to you!	\N	0	ALL	2026-05-27 15:35:20.53106+00	2026-05-27 15:35:20.53106+00	\N
5ff61029-4a9a-4fb0-b139-e9088123c73e	321816a3-3698-4041-8cd9-7b6d17aedae1	exampletemplate	{First_Name}{Last_Name}{Today}	Your birthday reminds me of all the wonderful qualities that make you so special. You bring joy to everyone around you.	Have an amazing birthday! 🎂🎈	\N	0	ALL	2026-06-18 13:13:04.351641+00	2026-06-18 13:13:04.351641+00	\N
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (id, user_id, token, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.posts (id, user_id, content, image_url, gender, is_default, label, font_family, font_size, font_color, created_at, updated_at, group_id) FROM stdin;
0a1a32b9-3605-4f9b-a298-a1d76cb1bea9	321816a3-3698-4041-8cd9-7b6d17aedae1	{First_Name}{Today}	data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCAVGBDgDASIAAhEBAxEB/8QAHQABAQADAAMBAQAAAAAAAAAAAAQBAgMFBggHCf/EAFIQAQEAAgEDAwQBAQQDCQsICwATAWECAwRRBQYRBxIhMQhBFBUiMhZxgQkYIzdCV3OhsTM2YnJ1kaKmsrPTFyRSdoLBw+E4Q1N0laW00dLU8P/EABQBAQAAAAAAAAAAAAAAAAAAAAD/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwD+qYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADGf0yxn9A1AAAAbY/TVtj9AyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAxn9MgNBn45HxyBgZ+OR8cgYbY/THxybAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADHzg+cAyMfOD5wDIx84PnAMsZz8HzhjkDOM/LLXi2AAAABj7sMtG3zgGRj5wfOAZGPnB84BkY+cHzgGQAAAAAGPuwy0BuMfOD5wDIx84PnAMjHzg+cAyMfOGQAAAAAYzn4A+7DLRt84BkY+cHzgGRj5wfOAZGPnB84BkAAAAAAAAAAAAAAAAAAAAAAABj8Ywy1zn5BnGfllrj9s/OAZGPnB84Azn4MZ+WORjPwDYAAAAAAY+cHzgGRj5wfOAZGPnB84BkY+cHzgGQAAAAAAY+cAyMfOD5wDIx84PnAMjHzg+cAZz8GM/LHI4g2AAAAY+7DLQG4x84PnAMjHzg+cAyMfOD5wDLGc/B84Y5AzjPyy14tgAAAAY+7A1AAAAAAAAAZ4tmvFsAAAADQAAAAAAAGeLZrxbAAAAANG7QAAAAAABniwzxBsAADXP7Azn5YGM5+AZGjcAAAAAAGeLZrxbAAAAAAAA1zn5AzyYAGcZ+GcZ+WoDcYxn5ZAAAAAAAY+cMtAM5+Qa5z8g2GuP22AAAGOTGM/ANm2M/LUBuMY/TIAANAAAAAAAAZ+7TZozjPwDYAAABo3aAAAAAAAM8WGeINgAAAGjdoAAAAAAAADPFs14tgAAAAaAAAAAAAAAAzxbNeLYAAAAGgAAAAAAAM8WzXi2AAAAAaN2gAAAAAADPFhniDYABrn9tmucfOQYa5x8NgGjdr9uWwAAAAAAM8WzXi2AAAAAAAY+MMgNc4/DDbP6agY/bb4wxj9tgYxj4ZAAAAAAABo3a/bsGGjczj5Brj9tmMY+MsgAAxyats4+TGPgDGPjDIzjHyDOP0yxj8YZAABoAAAAAAADOMfLPxhji2AAAAAaN2gAAAAAADPFhniDYAAABo3aAAAAAAAAAzxbNeLYAAAAGgAM/bs+3bYBr9uz7dtgGv27Pt22Aa/btjOPhu15AcWzXi2AAAABoz9u2G4Nft2fbtsA1+3Z9u2wDX7dn27bAMYx8MgAAAAA0btAZ+3Z9u2wDX7dn27bANft2fbtsA1+3bOMfDIAAAADGcfLGcfDYBoz9u2G4Nft2fbtsA1+3Z9u2wDX7dn27bAMYx8MgAAAAAAAADGf01bZ/TUGcfts1x+2wAAAAAAAAAAMZx8tc4+G7Gf0DVn7dmP22Br9uz7dtgGmcfAzyOIH27bAAAAADX7dn27bANft2fbtsA1+3Z9u2wDX7dsZx8N2vIDi2a8WwAAAADX7dtgGv27Pt22Aa/bs+3bYBr9uz7dtgGmcfDPE5HEGwAAADRu0Bn7dn27bANft2fbtsA1+3Z9u2wDX7dsZx8N2vIDi2a8WwAAAANAAbgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFAElSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlRHUBHQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQS0AR1Ko6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVEdQElCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdBJUBJUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUR1z5ASUKJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0ElQEdSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlRHQBJQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQSVAR1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXAkoAkoUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CugkrsBHYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYR0AS1Ko6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVEdQEdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+RJQBJUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUSVARUKOYDpQo5gOlCjmA6UKOYDpQo5gOlCjmA6UKOYDpQo5gOlCjmA6UKOYDpQo5gOlCjmA6UKOYDpQo5gOlCjmA6UKOYDpQo5gOlCjmA6UKOYDpQo5gOlCjmA6UKOYDpQo5gOlCjm9h9M+nf1A9a7Lp+pejexfcPf8AZ9bGc9PuO29M6/V6fPGM/Gfjlx45xn8+AeCoUdPUPTvUPSe86vp3qnY9x2fd9Dl9nV6HcdLl0+p0+Xjlx5YxnGf9acHShRzAdKFFPpPovrHr/e8fTfQvSe89S7vnjPLj2/adDn1upyxj95xx44znPwt9b9k+8/bPbcO89ye0fWvSu36vOXDq992HV6HDlz+M5+3HLnxxjOfjGc/Gsg8TQo5gOlCjmA6UKOYDpQo7enel+pesd3w7D0j07ue+7nqf5Oj23R5dXqcv9XHjjOcvMeofTn6hek9pz7/1X2J7h7Ltelj7ufW7j0vr9Pp8cec8uXHGMYB4GhRzAdKFHsHafTX6jeodtw73sPYHuTue36nH7uHV6PpXX58OWPOOWOPxnDwXedl3np3ddTsfUO063a9z0eX29To9bp54c+GfGeOfzjINKFHN570v2D769c9P4+rei+yvXvUOx5/d9vc9r6b1ur0s/bn45fHPjxzj8ZxnGfz+PgHhaFHN7J2n01+o3qHbcO97D2B7k7nt+px+7h1ej6V1+fDljzjljj8ZwD1+hRv3nZd56d3XU7H1DtOt2vc9Hl9vU6PW6eeHPhnxnjn84y4A6UKPZel9K/qf1+nw63R+nHujqdPqcccuHPj6P3GccsZ/WcZxw/OG3/yTfVT/AJtPdf8A/Bu5/wD8AesUKK/WfQfXfbneY9P9w+i9/wCl91nhjqY6He9tz6HU+zPz8cvt54xn4z8Z/OmfRfb3r/uTuuXZe3fQ/UPVe44cM9Tl0ey7bn1+fHj8/H3Z48MZzjHznH52COhRX6z6D677c7zHp/uH0Xv/AEvus8MdTHQ73tufQ6n2Z+fjl9vPGM/GfjP50o9E9o+7PcvHnz9ue2PVvVePTz8c89l2XV6+OOfGfs45+AeMoUeW9Z9k+8/bnQx3XuH2j616X0c5+3HU7zsOr0OOc+Pnnxxh4UHShR07D071D1Xu+n2HpfY9x3nc9XPx0+j2/S5dTqc8648cZzl5rv8A6cfUP0vtOff+p+w/cXZ9t0sfdz63X9L6/T6fHHnPLlxxjGAeBoUcwHShR7D230y+pPe9Dj3XZ/T33L1+jzx93HqdL0nuOXHljzjOOHxl4X1P0j1X0Tu+XYes+md32HdccYzy6PddHl0upjHnPHljGQcKFHNf6P6B677h7jPZ+gei9/6n1+OPuz0uz7bn1ueMefjhjOfgElCjzHrPsb3r7d7b+2+4PZ/rfpnb/OONe89P63R4fOf1j7ufHGHgwdKFHMB0oUcwHShRzAdKFHMB0oUcwHShRzAdKFHMB0oUcwHShRzAdKFHMB0oUcwHShRzAdKFHMB0oUcwHShRzAdKFHMB0oUcwHShRzAdKFHMB0oUcwHShRzAdKFHMB0oOYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/oP/Gn/AIlfbn/RdX/3vJ/Ph/Qf+NP/ABK+3P8Aour/AO95A+GPqr3Pc9x9cfqRw6/cdTqcej7g58OnjnzznHDjHp5+MfP6x+c/h4LpdHq9x1eHQ6HS59TqdTljjw4cOOc8uWc/rGMY/eXm/qZw59T67fUvp9Phy58+fuPlx48eOPnOc56PS+MYw+2fov8ASL2t9HfZvH3H670u24+s57TPd+peodbGM/2bh9v3cuHDOf8ALx44/ecfv4+c/wBMYD4wx9LfqdnpXx9OfdGen8fP3/3R3H2/Hn5+x631+h1+163Pt+56PPpdXp8s8efT58c8eXHOP3jOM/nGX036b/uh3tX1v3dy7D0T6Yev937V4dbPRz69/ael0+efjl8U49tz+M8uH9f8/wB/x/yfn8P1z6yfSX2v9ZfZnL130fodvy9Yx2uO69M9Q6XHGOXX4/b93Hp88/8AK48sfjHz+s5/p+QfM/8AE3/jo9O//de5/wDYfpX+6C9z3Xb+xvYvDtu46vTx1/d/Q6fUxw55x9/HPa9x/hz8fvH4x+H5r/E35x9afT+PLGccuPbd1x5Yz+8ZxwzjOM7xl9YfXD3d9OPpx7Px9TfqT6dw7ztva/Xx3fYcJcep1cd5z456XCPHlnGKZxz5ccZznHxjlnPzgHwj0/pn9SOt22O96X0+9y8+35cfvx1ePpPXzwzx8/d9nx8PXOp0+fS58ul1eHLhz4Zzx5ceWPjOM4/eM4faf8f/AOW3a/XD3D1vbve/Tn1P2v1ufS59x2HV7jvOn1+Hc9Pj8fOOWMY48+nz+M/Px9ucfGM/4vPov84fa/o3onW9te9u27Xp9DuPWO95ek91y6fHGK9SXLq9Pny+P3n46fPj874+AfMir070z1L1ju+HYek+n9z3vddT/J0e26XLqdTl/q48cZzl9gfwk/7wvXv/ACx/+D02Prj9f/p5/GX3B1en6f7Q7r3P75938s97y7TtufDpc48cY4cc9XrZ48s9Pp4+34xjHHl+uWc/1yD5T9W9h++fQO0z3/rvsz1307tsZxjPW7v07rdHp4+f/C5ccYeE6fT59Xqcel0uGefPnnHHjxxj5znOf1jD+i30f+qPpX1s9i8fcnD0Hrem8ufPn2nfem93z6fWz0epjGPnjnlwznjz4545xnGfx84z+cY/T4g+untz0/2R9ZPcPtX0no8e37bo56Hfdr0+H4x0+l1+P3YxjxjHPjzxjxjGAfZ/089oezPoN9MuXqnq3V7Xscdn2X9u9a9T6mPjOc44/dzznP7+3j+scf8A78vH/Rf+UX0v+vPqXf8ApHsvh610ev2fDl1OP949hnocO66OM4456nS5Yzyxyx85x84z8csfP54vgj1fh7m93dt1Pbvce+vdnHsvUvs7frdj0vW+4x23Wx84xjjy6OeWennH6/H2vvD6Gfxx9vfRfPP1np+rdf1P1Dn2mO24c/7Pjo9PodL8Zzx4dPGeWc5z8Y/Pzn9fjGAfhX8wfp76D7H90+je4fQ+16XZdD3LnrdPq9Dp4xx4Y7rp4xzznjxx+vu455Zz8fj547ee/iD9JfS/Xefd/UX3F2PDuun2XXx2/p3S6vD7uFcYxnl1fjP4znHzjGPGfnP7+H5L/Kb6q+4Pqz9YOw9A6Ptv1f0P257Iz1s8c+qdnz7Xrd93XU4/bXHT54xyxw+3/L5xnOc/vD7D/jH6d0vTvor7f49L8/2jj1u455z/AF5c+ryz/wDl/sB4j6h/y7+jv01+onQ+mPrfd+rd36xy+zPeZ9O7HPcdL0/HLGM8c9fOM4zj8Zxn4445ZxjOM5xjGVX8ivpl6R9Rvp53nr3p3Z9Lq+s+l9rnvuw7np8cff1unx4/dy6Xz/XHLj8/GM/1+Mvg73P3f98/Vv6k+4etwzfufdPfdrnly/Ofs6HOXHHz4/w5f0Z+jXW6nqn0g9rc+8556nLrekdHp888s/OeWMcPt/P+zAP5v9Hq9Pr9Lh1+jzxz6fU4458eWP1nGfzjL7g93ep9b6K/xA9R9Q6XPj0O/wDTvbPKefnOMf2vrcPjG/8AP1Hxz9MvbOPXfqB2nsnodD56XS9x9x6Xnp8uPx8dHo91z45x8a6fH9afR3+6F+vce2+mXtj6e9vjGc+5vXu36fV4Yz8fHbdvjPU5Z+P6/wCLHAHgv4P/AEe7T1T0Xp+//d/Qz6h1Owx0+h2XHuvnqYz3GOOOXPq5+75+7PHOcYx8/rPz4x8fsf1D/l39Hfpr9ROh9MfW+79W7v1jl9me8z6d2Oe46Xp+OWMZ456+cZxnH4zjPxxxyzjGcZzjGMvLfxi9O6Ppv0U9vcOj/wDr+PW7jlnfPq8s/wD5f7HwF7n7v++fq39SfcPW4Zv3Punvu1zy5fnP2dDnLjj58f4cg+8f5FfTL0j6jfTzvPXvTuz6XV9Z9L7XPfdh3PT44+/rdPjx+7l0vn+uOXH5+MZ/r8ZfC/tfsul7g9b9J9O6PLHU6fqXddDocc8c/wCbHU58cY+P/O/oh9Gut1PVPpB7W595zz1OXW9I6PT555Z+c8sY4fb+f9mHw/8Axs9C4999a/TPQul0Mw9F9e7/AKOeOcfH2dPter1ccfx/T4+zjgH3h769/wDsv6Rezur7t99esY9K9E9Oj0Or3H9n6vW+zPPlx6fDGOHS48uefnlnGPxjPx+8/h+T/wC/2/id/wA63/8AIvUv/wDXfoH1r+j3pX1w9qdv7L9e9Z730/0zj6h0O+7n+x44V62OlnPLj08cueM444+74znP25/GPj8fPy/LPcH8JPaPU9P6n+ivuz1jt++xj56efUM9LrdLlnxnHDhwzj/X+fjxkHzL9dPq97L+sf107z3D9O/c3V9Y9C6Xt/s+3xzz0Ov0OHHuOPV6ueeMdPrceGfn45cfz8fGfP4fQf8ACD29n7PcvurqYxnGeXR7Dpfj9ZxjPPn+f9vB82e7vaXrvsb3B3ftn3H2ee273s+X28sfPzx58c/5efHP9eOcfnGf+zPzh9mfQrh2302/jln3T6h9vT447Pu/W+ty/X+DGOXLj/6HHiD8H9ueh8/5EfzC99dX1Xvur3Htr293XHso8epnPDPDteOOHLp4x8/GM8urnPznH9MZx+/y+nPqx9Z/pb/G32n2Hee6MdTs+063P+yem+m+mdpjn1etyxj5+3p9PHxxxjGP68s4x+cfn5zh/PT6Q+/vf/tD0XvPcPtj3H1vRvVvcvPrd53fcdHo9PqZzy6vU5c8Z+Opx5Y/HzjP5w293eufUf6ke4vSPcH1N9/dT3Jz9B6fW6fYcOr6Z23bRr9v3Z+ejx445f5cfvGf1+PgH9EfpP8AWT2D9fvbPdd/7f7L1Dh0unnHQ77031nsM9DrdP7sfOMc+Gfnhz45x8/njy5cfxnHz+Hx/wDyR+n3pf03+qGfRvQ+ljpdj6v2uPUez6HHPzPH3549Thxx4xy+PjXLGP6P3b+GnsH1j0D0H1X3j6r0Op2/T9dj0+z6fPj8Z59Lp/dmnx4znl+POMfP6zh+PfXn3p6d9Rf5ke3favpfU49fsvafDtfS+96vHPzxz3Pcd10+XPp+P8PHHHGfj+vzj+gPpz6MfTb259HPp/w9T9R4dv0PUOp2n9t9X9Q6uMfPDGOP38uP3Z/OOHDH9NZz+8vG/SL+WP0l+t3ubvfavszn6zjr9vjny6HX730/l0e373hx+Pu5dHn85/Xz/l544cvxnP2/GHX+Xff9b0z+Nfv7q9tnlx5dT0jn23+HPxnGOpy48M/9XLL49/jfwx6F9TvZXb9nx+zHQ7np9DGMfj8cuGePL/z4zkH6j/L/AOmHpXs713033p6D2XDtey9f6vPt+66XS4/bw4d3jjnnjljGMfGPv4455zvj55PeP4jfSL0Xh7e4/Uv1zsOn3Xf931efH07HW4YzjtunwznjnqccZ/5XLOM/4vGMfH7y81/OXtvn6Ad/6pw6XPn1fSvVfTO64fZx+c8cf2rhw55/1fZz5fOnyt2f1o+t3oHpPZ+iey/qb3XofZ9jx5cOn0ePp3adzw+M/n4+Or0+Wfxnf9cg+sPqB/NL6MfTv371fp13/wDpB6r6p2fPHT9Q5+k+m57no9jnOPn/AIXP3Y5Z+MZx844ceecfPx+3v/vn2V7P+tXsXHT6nDod10u+7XHc+md/x4fHPpcuXH54dThnP5xj9fOP64/GcP5v+0/a/uP1j1/uunnuet6/7i9zepdTu+v1uPb46fU7jr9XPzn/AA8f8PHGM/Ofx8ccY+fxjGH9H/Tev6b9FPo30O490+odPh2vtX0fHPvOv+uOc9Ph88sY8/OfxjH9fnAPgv6b+yO8+oXvrsvZXbc59Tqd51e27vqcP8WOhjo8uWOtn/Z9nLGN/Hl91+s+sfSv+NP016vq3qfPo+i+g+mcePHly48Pv63c9XP4xjGMf4up1OWf/wDsYx+Pl3+APHqe5PePuL3t33Qz0+v33HvPUOnw5Z+c8Md13Wef+38f12/av5QfQr3P9f8A1D2Z7Z7Lv+27D0D0nvet6p6p3Hccc88Z58eH2dHp8enjOPv5Zzy5Z/OcYxjGfz8/GMh7f9IPrh9O/wCQ/tzvu79tdl6jx6HS+Ol3fYesdjHqfZzxn7eWePzy4c+HLGM/GePLOP6Z+Mvjr+QPsXs/px9VPUPbvpvSz0uw7rodP1LseP8ATj0upnljPDGf/B58eWP9WeL9f9U/h19QPb/onqHH6e/WHvu27zu+l9nU4dnX0zn1eOPzjGOr0+ry/P7+Pux8fn+j5Z7/ANp+s+3fcnd8fdfqHr/eeudtjl2nccvWO+6ncdbhj7vnPH555/Xz+cZx+M/Pzj9g3AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXel+h+t+udXPR9F9H771DqY/fDte359Xlj/ZxxlC+tP4Se6PT8el+vezer1+HDvP7Tx9R6XDOcYz1OGeHHhy+PPxnhx+f/GwD5X9V9G9X9B7zl6d656V3np3d8cY5cuh3fQ5dHqYxn84znjyxjPxl99/xp/4lfbn/AEXV/wDe8nov13/i/wCtfU731w98e2/c/bdrz6/adHs+67Pvvvlxny5fHV6eeOM/4s8efxnjnGMZ+3j+cP1r2t6R6N9Ifpr2vp3qfqvS4dh7e7Hl1O773qYnw+OOM8up1M4zn8Y+fnPx8g+E++4dHn/LD3Rw7jGM9Ll767bHU+f19v8AwHz/ANT67/l51O+6X8bPf/8Ad+M05+k8+nz+P6dPly445/8Ao5y+APTfd3de7PdfuT6ldty5dHPrnuHufU+y5fbnGePSxzxjpZ+M/wBcY44/24f0W9j+7/Z319+mfX9P77j0e44eo9jy7D1n0/lyxnn088+H288Zx+/tz85zxz8fkH86PS+y6Hp3pvbdh23DHHp9DpceHHGNYf0W/jl1e46v0Y9s57nPLPLj23Ljx+f/AKGOfLHH/q+H4fw/g76v0vXen2/D3v2nL0HhnHz1eXR5f2z7MZ/y/Z8fZ8/H/K+74+fz9v8AR+tfWn6t+yP4w/SW339Hj3Pbdp/YvQfS8dT/AIXu+vjj8cMYx+/txn4zy5fH4xvOMA+d/wCOXU7b/fVe6O17LPDPb9r6/wCt9Pp/Zy+7GPnny5csf7OXLlj4/p+v6Pe/90Q5dTqfTn2V6dnn/wDN+894dtw6/D4xnHU48e36/PGM/wD2uOMvyD+EPa+pdH6p9h3vrXLPL1P1Pj33qHe8s4+M563Vxnny+d/l+vf7oX/3j+wf/rl0P/6XuAfmn8VOXLj9afSMcc/H3dHuMZ3ieX67/Pvlnj9LvbeeOfjP+lPZf+z1H5D/ABW/46vR/wDou4/91yfrv8/f+K323/8AWrsv/Z6gPI/wk/7wvXv/ACx/+D03zz/K3p46/wDKT13uer/i59t6B6d0elnOP8vHlnqZzjH+3D6G/hJ/3hevf+WP/wAHpvnz+VH/AOk57k/8i+l/9nVB+/8A8IufLPsn3Dwzn/Dj1TjnGN56PH/+2H4P/K7h1et/KH1fodHhy58+p7f9L48eHHHznlyzy62MYxj+uX7v/CL/ALzPcX/lTh/7ri/Ev5Nep9f0T+W3ees9rjGet2Ho3o/ddPGf193DqdXlj/rwD0fn7P8AfnoXb8fcXX9p+udl23ac+HVx3nV9P6vDpdPljlj7c558uP24/Px+36P9A/q59T+P1k7HHrX1A9c9Z9O9wdzx7buPTe+7jHV7bpfPH448ujxzj56WcZxjP+HOMZ+c/OMvrXse+9nfXn6Zdbo47jl1fTfXO0z2/dcOj1fs63b9TOP8XH5x+ePPjn84zrGf09I+mH8VPbP0592cPdnX9wd36x1u05cuXYdLq9Dj0uPRznHx93L4zn7+WMZz8Z/w4/P6/QPF/wA1/b/pvP6U8ve/PtOGe99B7ztsVx8Y5Z7frdXj0+px+c/vGPvxz+P/AAdvdv40950e9+ivtzn0OXzjpdLq9Hlrlx6vLGf+vD5//n59YfR/UfTfTv4+e3O56fe+seq972/ees46XLHLHY9r0eeOpxxzzj9c+XLHHOMeOP5/ePn27+Gv1J9O/unu/pr6l3XDo930uty7v0/jzz8Y6vDl/n4cfPLGcfPx4zrIPlL3B6d1/SvqJ7/7LufimPd3qvVzjH9MdTr558f3rlh/RT6I8OXa/R72nb/D9vpPR55+f6Yzx+f+zL0L31/Ej2f719/d3744eu976dj1XrcO49T7Pp9Ljz49fqceGOGeXDlnOJ55cePH5/HL9Zz+M5eU/kp9WfQfoJ9F/Ue86PW6XR9R63aZ9L9B7LGf8fV7jlw+zh9vH95xwx/iznxjeAfNn8MvSMe6vrV677mzjPW7bs/VPWfUeHUzjHxjl1O558eH/nxz5ZTfzZ9wY9x/yK9D9ucP8XR9o+gcu45Z/px6/dc/zj/X9nDjl+n/AO57+yOXtz6c+o+sd30s8e47jqdPtc8s/wBfs4558/8A0upnH+x8we8fcP8Apv8AWb6i+9/u5cun3frvU7Dts8s/P/A9rjHS4/Gs/b8g/oB/GnvOj3v0V9uc+hy+cdLpdXo8tcuPV5Yz/wBeHwB7g9O6/pX1E9/9l3PxTHu71Xq5xj+mOp188+P71yw+rf4a/Un07+6u7+m3qfdcOj3fS6/Lu/T8c8/GOrw5f5+HHzyxnHz8eM6y9q99fxI9n+9ff3d++OHrve+nY9V63DuPU+z6fS48+PX6nHhjhnlw5ZzieeXHjx+fxy/Wc/jOQe+/RHhy7X6Pe07f4ft9J6PPPz/TGePz/wBmXwj9CPfHuX2x9QPcPvf2l7W6vuXuOv6v6vy4dvw6XUz/AIOr3XPOOX/B4znj8/H7+Pj85/D7F/kp9WfQfoJ9F/Ue86PW6XR9R63aZ9L9B7LGf8fV7jlw+zh9vH95xwx/iznxjeHyX/D/AN59r9HvcXpXbev9xjoen+odp/Y+/wCpy/y9Lqc+X3458tY5/jOfGc5/oDzH1z/kV/KD3T/dvt3oe0+/+knp3X4c+fdd70u459Tuu9+PjHx0epz6XS59PGPnH+XHz85x88v+Tn9L/hn9S/fPqXrPfewfdvu/1f3L0On2We87XuvVerx63cdLPDlx48uOer8Y588Z+/Gf8eeWfxn8v3L6tfR/2x9afROy7f1Hv+v23W7Plnr9j3va88csY+7j8Zxnj/l58M4+M/GsZxnCD6N/Qf279Guj3ne9H1Xq+pepd308cOv3nW4Y6XHj0+P5+3hw+c/bj5/OfnlnP4/YPxL+b/o/S/0y+n/c9l0//n3r3LuvSeWMY/HUzx+zn0s5z+/xnPPH/wBr/U9u/mF6px+nX8Ue+9r+mY4cOt6l0Oy9udv08fj5x1M8eHPGMf8AiY5/h+beve/PTv5HfzP9o+g+1urjv/a306z1+r1u76XP56Pcd5nH3c88f6cuPHPDhxxn8/8AK+Pxn5zv/ug/uD+8fdH03+nfD45cOHX7n1/ucfP+WXGfS+cbzz5/+YHzz2Xa8Oy7Podn08fHDodLj0+P+rGPh9M/x1/jX/pHjtvff1A7Plx9L+cdXsfT+pj4z3XjqdTH/wCz8Y/5X9fx+/SP40/S/tPqT79+71noY6vpPovT4933XTz+ury+fjp9POs5xnOfOOOcf1fb/u32xx91e1u/9q9L1z1P0Pp9/wBDPbZ7z0rqdPpdz0eGcfGZ8ufDnx45+Px8/b84+fx8Z/IPmL+UP8xej7O6ncfSL6H56PqfvDqcc9v3Xf8ASxjl2vovD4+M5+f8vLq4/pj/AC8f6/Ofjjn5q+i/o3T9r+8fbvW7vu+fdd31vXO07zv+76mc559fq56/Hly5Zzn85/r+/wDX+8vrn2//AAF+i/tvteXbenet+7c8upy+7q9bqd523Lq9Xl55cv7P+f8Asfif8i/p37V+ifvL217f9q996z1+49U7Pr+oV7zqdLnjp56PU4Yx8Z4cOHx/m+f1n9fsH05/MHter3f8a/ffDo/nPD022f8AxeHU48s/9WMvkb6CdLn3H1b9o8Ol+c/2/p8v9mMZzn/qw+2vZPuT2p9dfpby6Hdy7rtvVOx5en+r9nnl/i6fPlw+3qcOWP3j5+c5xn+uM4y9U+k38WfbX0t90cfdHH3B3fq/V7Xhy6fYcOv0OPCGM8ftzy5ZxnP38/j5x84xxx/iz+AeJ/nj6lz7D+NnrvS6PWn1e+7307teHxjGc8vu7vp55Y/P/g45Pjv0L0P1b3J6t2voXonZdXvO+7zqY6XR6PTx88uXLP8A2Yx+85z+MYxnOX7F/PL6q+n+6fdntn6G+3e94dzz9M7zj636/npcvux0Ps4/8D0eWf192fuzyzj94+eHl+x/xH+lnZe3/aXD6gepdrx5+q+t8c/2fnyx856Ha/PxjHHxnnnH3Zz4+3H9AeV+l/0q9kfx29o937397+q9j0vUel22ep6j6p3HLHHpdp0/3np9LOf6fPxj5/fLPxrD49/kD/In17+UXqf+jHtvt+49I+mnp3dY6mc9XH2df1jqcM/4efLH/J4Yzj8cf6fvP+L4xx+2frj/ABy9qfyAx6Z2vvb3V7o7b0z0vnnq8fTPTe66HR7Xr9T/AOn1ccujy5cs4x+Mf4sYxj5+MfnL1Po/wj+k3b9Lh0Oh637o6fT6fHHHhw49z22MccY/WMYgD84/hB1+17T3j636Zw+zhnqemcM9Lhj8f4eHUxjPxjxj7sP0r+Yn1y96fRn2d6L0fp32nacvX/c3qOew7fue74ff0+04ceGefPqfZ+uXL4xj4+fxj85+M/Hxn5o+k/1D9M+mf1j7n1Ts/wC1/wB0+ler976J3VuPHPV5dDh1eXT5cv8AD+M5x9vHl+MY+fj9Y/T7U+pX0y9kfXv2j6f0e+7zPU6HS6vH1D0v1Hs+fHlnpc88c8fu4/PzjljPHlnGceM/0zj5B+X/AMRfrN9R/qBj1P2z9TPWez9a7/sejw7no+odDseHa8+XHOft5cOfDh/gz8Z+PjPHjx3h+e/zf9K7f0j6j+1/Vu37fjx/v/0/uel3HLGcY+er2/Lhnhn4854dTljOfj/kY0+g/ox9BvQ/o3x77vOh6x1vVPUO+48en1e56nSx0uPDp8c/OOPHhjOfj8/nOc5z+sfp8cfyp+qno/1b+vnZem+1e46fe+kewuw6/adTvely+7p9Xvevy4048c4/GccccOOPnGf3x5ePyHoQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC70X1v1f256n0PWfQvUev2Pfdty+/pdfo8/t5cc/wD3484z+M/1QgP1rl/Mb+SPp3Q4dv6Zj2L6pjjj4z1vVfTe54dbO+Weh1uPDOf9XDi/NPqd9Tfrp9c+jx9J+pnvLsey9Axz48+p6N6B0efQ7fr5x+cU5c8558sfPx+OWeWPx84xjP5QAOXa9r2/Zdt0u07Tpcel0ejxxw4cOOPxx44/WHkPTPV/V/Q+84eo+h+r996Z3nT/AMncdn3HPo9XjrHLjnGfjzj9Z/WfnCQB7b3f18/k/wAuH9n9O+vHedDofb9uMdb0D07q9T4/6THR48v9v7fnncei+oeue4M+7/fXub1T3T65n9d56n1s9Sf5znGOHHPzjhjHz+MY/GP6fDywDzPtP3f7j9jes9P3D7V9R/sPqPS4cuHDrR6fV+3HLHxn/Dz48uOfxp473t71+tX1Px6V2n1K+qv9/enekeocfUuh2v8Acfadr8dbjx5cMZ+/o8ePL/Lz5Y/Pzj8/pOA8v7V92e4PZPrXR9xe2PUP7F6j2+OXHp9aXDqfbjlj4z/h54zxz+M/1wk96+/frj9TOh2Xpn1E+rH99eldj33T7/h2f9xdn23/AAnD5+3/AITo8ePL9Zzj95xpGA9m9A+q/wBWPYvofc+i/Tf3x/o9x7ruMdz1Of8Adnbd388vjHHP463Dl+8Yxj8Z/o9V771D3v7n909/7z+oPvD/AEh9X7/odHtuXcf3f0e0+On0vu+3H29LGOP/ACs/0xn/AFugD2X299Vfqr7E9F7v0f6b+9f9Hv7Z1uPX6nU/u3tu7+eWMYx+utw5fvGPj9vVvUPUvfXur3X3nvT6h+8v9IvVu77Xo9nnr/3d0e0+3pdLPLPHH29HGOOf82fz8fO8ugDy/t73h7w9n9fl3ns/3R6j6L3PP99TtOpj45ePu4cscuHP/Vz45xpX619bP5Peudr1vTe6+v8A6j0uz6+M8OWO29F7Ltuvjjnx1ujw4c+Od4+MvXQHiPQvbHp/oPPr9z0ufX7rvu7556nc973XUz1Ov1uWc/Oc8uWfOfzv+vzl5vodfr9r1uHcdt1up0er0uWOXDqdPlnjy48sfrOM4/OMuYD3Dq/Xn+SHa9Dh2nt/62+odl0OHH7ccO69J7LvuWMf9J1elnqZ/wBfLlnL889S7D3B7s9ycfeP1I95eqe7PWen/wBx63fc/jpdDHjpdLH+Hhj+vxx+MfP5+Pn8vJgPaew+sP1o9r+2ul7V+n31Dx7e7Hh1OfU5ccekdp3WeX3/AD92Pnq8M8sfOc/Pz8/0/Hw9E9u+jZ9B9K6fp3Pu+XddTjy59Tq9flx+M9Xny5Z5Z5Zx85/Pzny8kA6dDr9ftetw7jtut1Oj1elyxy4dTp8s8eXHlj9ZxnH5xl7Z1frz/JDtehw7T2/9bfUOy6HDj9uOHdek9l33LGP+k6vSz1M/6+XLOXp4DxnqXYe4PdnuTj7x+pHvL1T3Z6z0/wDuPW77n8dLoY8dLpY/w8Mf1+OPxj5/Px8/l5MAey+i/Vb6ve0ewz2Hsb6l+q+idLH+XpZ6XQ7zocf9XS7jhz48cf8Aifb8/wBXhfeHv769fUf07n6H79+uPrHfeldbGePX7Tsex7f07HW45/fHnnoceP38c+OWM4SALvp167619JOrnu/px3vT9H7vHQ59Dj1/7N0+vn45fHznOOrx5Yzn544/P7/Hx8/DxnrHqPv33n7w5e+fqV725e5PVuPY8fT+j1c+n9HtMdLo4555fGOPRxjj+85/Px8+c5dQHsftn6m/Ur2B6f6h2n0592cfQev6h9mep3H939v3Wfnj+vx1uGf6Zz+Pn4/Kj/fBfyx/5/8A/wBVfTf/AIb1QB7X/vgv5Y/8/wD/AOqvpv8A8N6t7j9xfVD3/wC5Ow9y/U76hf6Sdx6Z2vV7TtMf3T2/Zz4dTlx5cv8AuOOOM/njj94y1AeU9v8Aur3R7S7zPqPtT3F3/o/d5x8W7Tq/bnPjHLjn5488f+DyxnGl3rf1s/k7652vW9N6/wBfvUej2fX454csdv6N2Xb9fHHPjr9Hhw58c7x8ZeugPE+g+2ew9A/tHV6PU6/c933nUz1e67zuepTrdfnnOc5zy5Z/f5znP+vPzn8v0jqfXr+RHYdj2HpHs/6scfQvTvT+349t0u24+3+w7jGOPH8cf8XPp/P4x8YemgPa/wDfBfyx/wCf/wD9VfTf/hn++C/lj/z/AP8A6q+m/wDw3qgCH0nsvUO04931vV/Vf7x77v8Avev3/ddzDj0adXq888+efs4/jHzyznPxj4x4xh7d7e+pH1M9l9vz6Hsb376p6Fjl85+zpY6XX6Pz5z0evw59P585xxxnb18B5D3Z9SP5Ce//AE7qeh+8vrt6v3PpfXxnj1+37D0/tvTs9Xhn98eXPoceOeXHP9cZ+cZ8PAeieh+me3ux4+neldtjpdLj+c/15c+X9eXLP9crwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+AHeWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAkloVy0AriRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COIsloBZLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0KpaAWS0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctCyWgFctEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLQrloBZLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0K5aAVy0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktCuWgFstEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLQrloBXLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktCuOfACyWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAkloVy0ArlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWhZEBXLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0LJaAVS0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLQsljwAslolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaFctAK5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjloWTAdAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAa5z+QbDGP0yAAAAAAAAAAAAAAAAAAAAAAAAAAADGc/AMsYz8tQG41xn4bAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANc/ts1z+wZx+mWuM/GGfuwDIx92D7sAyAAAAAAAADGc/AMsYz8tQG41xn4bAAAAAAAAAAAxnPw1bZ/TUAABnGfhhnj+wbAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAxn9Ay1z+2AAAAG2P0DIAAAAAAAMZz8NW2f01AAAZxn4YZ4/sGwAAAAAAAAAMZ/TVtn9NQAAGeP7YZ4/sGwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADGf0yxn9A1AAAAbY/TVtj9AyAAAAAAADGf01bZ/TUAABnj+2GeP7BsAAAAAAAAADGf01AAABnj+wBsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAxn9ADUAAABtj9ADIAAAAAAAMZ/TUAAAGeP7AGwAP/9k=	NEUTRAL	f	Birthday post	Arial	48	#ffffff	2026-05-30 18:07:05.906982+00	2026-05-30 18:07:05.906982+00	\N
\.


--
-- Data for Name: revoked_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.revoked_tokens (id, refresh_token_jti, user_id, expires_at, revoked_at) FROM stdin;
6ea82062-3495-4d3c-9eda-dd0c9b46b4bd	fc49f70c-409e-4c98-a421-cb0982f48eab	321816a3-3698-4041-8cd9-7b6d17aedae1	2026-06-26 15:30:05+00	2026-05-30 18:02:16.623402+00
56ef2aef-1d02-48ae-b469-ca386451da8c	9e8d744f-7257-4ec0-9cc7-25de6466424e	321816a3-3698-4041-8cd9-7b6d17aedae1	2026-07-16 13:41:43+00	2026-06-18 10:40:59.224217+00
c6c17e36-f971-481c-ac98-552a8cae4a06	0bc156ba-cec5-45cb-8d34-f065c4a23d8c	321816a3-3698-4041-8cd9-7b6d17aedae1	2026-07-18 10:40:59+00	2026-06-18 13:10:40.175867+00
\.


--
-- Data for Name: send_rate_limits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.send_rate_limits (id, user_id, timestamps, updated_at) FROM stdin;
\.


--
-- Data for Name: smtp_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smtp_configs (id, user_id, host, port, username, password, use_tls, from_email, from_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: subscription_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_records (id, user_id, status, price_id, stripe_subscription_id, stripe_customer_id, current_period_start, current_period_end, cancel_at_period_end, canceled_at, trial_end, started_at, ended_at, created_at, updated_at, metadata) FROM stdin;
\.


--
-- Data for Name: template_segments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.template_segments (id, user_id, segment_type, label, content, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: user_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_images (id, user_id, url, filename, size, created_at, source) FROM stdin;
60816778-332b-4121-bdce-fa9bc173acca	321816a3-3698-4041-8cd9-7b6d17aedae1	data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCAVGBDgDASIAAhEBAxEB/8QAHQABAQADAAMBAQAAAAAAAAAAAAQBAgMFBggHCf/EAFIQAQEAAgEDAwQBAQQDCQsICwATAWECAwRRBQYRBxIhMQhBFBUiMhZxgQkYIzdCV3OhsTM2YnJ1kaKmsrPTFyRSdoLBw+E4Q1N0laW00dLU8P/EABQBAQAAAAAAAAAAAAAAAAAAAAD/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwD+qYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADGf0yxn9A1AAAAbY/TVtj9AyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAxn9MgNBn45HxyBgZ+OR8cgYbY/THxybAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADHzg+cAyMfOD5wDIx84PnAMsZz8HzhjkDOM/LLXi2AAAABj7sMtG3zgGRj5wfOAZGPnB84BkY+cHzgGQAAAAAGPuwy0BuMfOD5wDIx84PnAMjHzg+cAyMfOGQAAAAAYzn4A+7DLRt84BkY+cHzgGRj5wfOAZGPnB84BkAAAAAAAAAAAAAAAAAAAAAAABj8Ywy1zn5BnGfllrj9s/OAZGPnB84Azn4MZ+WORjPwDYAAAAAAY+cHzgGRj5wfOAZGPnB84BkY+cHzgGQAAAAAAY+cAyMfOD5wDIx84PnAMjHzg+cAZz8GM/LHI4g2AAAAY+7DLQG4x84PnAMjHzg+cAyMfOD5wDLGc/B84Y5AzjPyy14tgAAAAY+7A1AAAAAAAAAZ4tmvFsAAAADQAAAAAAAGeLZrxbAAAAANG7QAAAAAABniwzxBsAADXP7Azn5YGM5+AZGjcAAAAAAGeLZrxbAAAAAAAA1zn5AzyYAGcZ+GcZ+WoDcYxn5ZAAAAAAAY+cMtAM5+Qa5z8g2GuP22AAAGOTGM/ANm2M/LUBuMY/TIAANAAAAAAAAZ+7TZozjPwDYAAABo3aAAAAAAAM8WGeINgAAAGjdoAAAAAAAADPFs14tgAAAAaAAAAAAAAAAzxbNeLYAAAAGgAAAAAAAM8WzXi2AAAAAaN2gAAAAAADPFhniDYABrn9tmucfOQYa5x8NgGjdr9uWwAAAAAAM8WzXi2AAAAAAAY+MMgNc4/DDbP6agY/bb4wxj9tgYxj4ZAAAAAAABo3a/bsGGjczj5Brj9tmMY+MsgAAxyats4+TGPgDGPjDIzjHyDOP0yxj8YZAABoAAAAAAADOMfLPxhji2AAAAAaN2gAAAAAADPFhniDYAAABo3aAAAAAAAAAzxbNeLYAAAAGgAM/bs+3bYBr9uz7dtgGv27Pt22Aa/btjOPhu15AcWzXi2AAAABoz9u2G4Nft2fbtsA1+3Z9u2wDX7dn27bAMYx8MgAAAAA0btAZ+3Z9u2wDX7dn27bANft2fbtsA1+3bOMfDIAAAADGcfLGcfDYBoz9u2G4Nft2fbtsA1+3Z9u2wDX7dn27bAMYx8MgAAAAAAAADGf01bZ/TUGcfts1x+2wAAAAAAAAAAMZx8tc4+G7Gf0DVn7dmP22Br9uz7dtgGmcfAzyOIH27bAAAAADX7dn27bANft2fbtsA1+3Z9u2wDX7dsZx8N2vIDi2a8WwAAAADX7dtgGv27Pt22Aa/bs+3bYBr9uz7dtgGmcfDPE5HEGwAAADRu0Bn7dn27bANft2fbtsA1+3Z9u2wDX7dsZx8N2vIDi2a8WwAAAANAAbgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFCgO44UKA7jhQoDuOFAElSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlSqOpUFlRHUBHQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQoloUBVQS0AR1Ko6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVEdQElCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdCiSpUFdBJUBJUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUqjrnyVz5BZUR1z5ASUKJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0KJKlQV0ElQEdSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlSqOhQFlRHQBJQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQokqVBXQSVAR1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXBXCShQFdcFcJKFAV1wVwkoUBXXAkoAkoUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CuhRJXZXYK6FEldldgroUSV2V2CugkrsBHYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYsjoUBZYR0AS1Ko6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVKo6lQWVEdQEdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+SufKShQFdc+RJQBJUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUqkqVBXUSVARUKOYDpQo5gOlCjmA6UKOYDpQo5gOlCjmA6UKOYDpQo5gOlCjmA6UKOYDpQo5gOlCjmA6UKOYDpQo5gOlCjmA6UKOYDpQo5gOlCjmA6UKOYDpQo5gOlCjmA6UKOYDpQo5gOlCjm9h9M+nf1A9a7Lp+pejexfcPf8AZ9bGc9PuO29M6/V6fPGM/Gfjlx45xn8+AeCoUdPUPTvUPSe86vp3qnY9x2fd9Dl9nV6HcdLl0+p0+Xjlx5YxnGf9acHShRzAdKFFPpPovrHr/e8fTfQvSe89S7vnjPLj2/adDn1upyxj95xx44znPwt9b9k+8/bPbcO89ye0fWvSu36vOXDq992HV6HDlz+M5+3HLnxxjOfjGc/Gsg8TQo5gOlCjmA6UKOYDpQo7enel+pesd3w7D0j07ue+7nqf5Oj23R5dXqcv9XHjjOcvMeofTn6hek9pz7/1X2J7h7Ltelj7ufW7j0vr9Pp8cec8uXHGMYB4GhRzAdKFHsHafTX6jeodtw73sPYHuTue36nH7uHV6PpXX58OWPOOWOPxnDwXedl3np3ddTsfUO063a9z0eX29To9bp54c+GfGeOfzjINKFHN570v2D769c9P4+rei+yvXvUOx5/d9vc9r6b1ur0s/bn45fHPjxzj8ZxnGfz+PgHhaFHN7J2n01+o3qHbcO97D2B7k7nt+px+7h1ej6V1+fDljzjljj8ZwD1+hRv3nZd56d3XU7H1DtOt2vc9Hl9vU6PW6eeHPhnxnjn84y4A6UKPZel9K/qf1+nw63R+nHujqdPqcccuHPj6P3GccsZ/WcZxw/OG3/yTfVT/AJtPdf8A/Bu5/wD8AesUKK/WfQfXfbneY9P9w+i9/wCl91nhjqY6He9tz6HU+zPz8cvt54xn4z8Z/OmfRfb3r/uTuuXZe3fQ/UPVe44cM9Tl0ey7bn1+fHj8/H3Z48MZzjHznH52COhRX6z6D677c7zHp/uH0Xv/AEvus8MdTHQ73tufQ6n2Z+fjl9vPGM/GfjP50o9E9o+7PcvHnz9ue2PVvVePTz8c89l2XV6+OOfGfs45+AeMoUeW9Z9k+8/bnQx3XuH2j616X0c5+3HU7zsOr0OOc+Pnnxxh4UHShR07D071D1Xu+n2HpfY9x3nc9XPx0+j2/S5dTqc8648cZzl5rv8A6cfUP0vtOff+p+w/cXZ9t0sfdz63X9L6/T6fHHnPLlxxjGAeBoUcwHShR7D230y+pPe9Dj3XZ/T33L1+jzx93HqdL0nuOXHljzjOOHxl4X1P0j1X0Tu+XYes+md32HdccYzy6PddHl0upjHnPHljGQcKFHNf6P6B677h7jPZ+gei9/6n1+OPuz0uz7bn1ueMefjhjOfgElCjzHrPsb3r7d7b+2+4PZ/rfpnb/OONe89P63R4fOf1j7ufHGHgwdKFHMB0oUcwHShRzAdKFHMB0oUcwHShRzAdKFHMB0oUcwHShRzAdKFHMB0oUcwHShRzAdKFHMB0oUcwHShRzAdKFHMB0oUcwHShRzAdKFHMB0oUcwHShRzAdKFHMB0oOYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/oP/Gn/AIlfbn/RdX/3vJ/Ph/Qf+NP/ABK+3P8Aour/AO95A+GPqr3Pc9x9cfqRw6/cdTqcej7g58OnjnzznHDjHp5+MfP6x+c/h4LpdHq9x1eHQ6HS59TqdTljjw4cOOc8uWc/rGMY/eXm/qZw59T67fUvp9Phy58+fuPlx48eOPnOc56PS+MYw+2fov8ASL2t9HfZvH3H670u24+s57TPd+peodbGM/2bh9v3cuHDOf8ALx44/ecfv4+c/wBMYD4wx9LfqdnpXx9OfdGen8fP3/3R3H2/Hn5+x631+h1+163Pt+56PPpdXp8s8efT58c8eXHOP3jOM/nGX036b/uh3tX1v3dy7D0T6Yev937V4dbPRz69/ael0+efjl8U49tz+M8uH9f8/wB/x/yfn8P1z6yfSX2v9ZfZnL130fodvy9Yx2uO69M9Q6XHGOXX4/b93Hp88/8AK48sfjHz+s5/p+QfM/8AE3/jo9O//de5/wDYfpX+6C9z3Xb+xvYvDtu46vTx1/d/Q6fUxw55x9/HPa9x/hz8fvH4x+H5r/E35x9afT+PLGccuPbd1x5Yz+8ZxwzjOM7xl9YfXD3d9OPpx7Px9TfqT6dw7ztva/Xx3fYcJcep1cd5z456XCPHlnGKZxz5ccZznHxjlnPzgHwj0/pn9SOt22O96X0+9y8+35cfvx1ePpPXzwzx8/d9nx8PXOp0+fS58ul1eHLhz4Zzx5ceWPjOM4/eM4faf8f/AOW3a/XD3D1vbve/Tn1P2v1ufS59x2HV7jvOn1+Hc9Pj8fOOWMY48+nz+M/Px9ucfGM/4vPov84fa/o3onW9te9u27Xp9DuPWO95ek91y6fHGK9SXLq9Pny+P3n46fPj874+AfMir070z1L1ju+HYek+n9z3vddT/J0e26XLqdTl/q48cZzl9gfwk/7wvXv/ACx/+D02Prj9f/p5/GX3B1en6f7Q7r3P75938s97y7TtufDpc48cY4cc9XrZ48s9Pp4+34xjHHl+uWc/1yD5T9W9h++fQO0z3/rvsz1307tsZxjPW7v07rdHp4+f/C5ccYeE6fT59Xqcel0uGefPnnHHjxxj5znOf1jD+i30f+qPpX1s9i8fcnD0Hrem8ufPn2nfem93z6fWz0epjGPnjnlwznjz4545xnGfx84z+cY/T4g+untz0/2R9ZPcPtX0no8e37bo56Hfdr0+H4x0+l1+P3YxjxjHPjzxjxjGAfZ/089oezPoN9MuXqnq3V7Xscdn2X9u9a9T6mPjOc44/dzznP7+3j+scf8A78vH/Rf+UX0v+vPqXf8ApHsvh610ev2fDl1OP949hnocO66OM4456nS5Yzyxyx85x84z8csfP54vgj1fh7m93dt1Pbvce+vdnHsvUvs7frdj0vW+4x23Wx84xjjy6OeWennH6/H2vvD6Gfxx9vfRfPP1np+rdf1P1Dn2mO24c/7Pjo9PodL8Zzx4dPGeWc5z8Y/Pzn9fjGAfhX8wfp76D7H90+je4fQ+16XZdD3LnrdPq9Dp4xx4Y7rp4xzznjxx+vu455Zz8fj547ee/iD9JfS/Xefd/UX3F2PDuun2XXx2/p3S6vD7uFcYxnl1fjP4znHzjGPGfnP7+H5L/Kb6q+4Pqz9YOw9A6Ptv1f0P257Iz1s8c+qdnz7Xrd93XU4/bXHT54xyxw+3/L5xnOc/vD7D/jH6d0vTvor7f49L8/2jj1u455z/AF5c+ryz/wDl/sB4j6h/y7+jv01+onQ+mPrfd+rd36xy+zPeZ9O7HPcdL0/HLGM8c9fOM4zj8Zxn4445ZxjOM5xjGVX8ivpl6R9Rvp53nr3p3Z9Lq+s+l9rnvuw7np8cff1unx4/dy6Xz/XHLj8/GM/1+Mvg73P3f98/Vv6k+4etwzfufdPfdrnly/Ofs6HOXHHz4/w5f0Z+jXW6nqn0g9rc+8556nLrekdHp888s/OeWMcPt/P+zAP5v9Hq9Pr9Lh1+jzxz6fU4458eWP1nGfzjL7g93ep9b6K/xA9R9Q6XPj0O/wDTvbPKefnOMf2vrcPjG/8AP1Hxz9MvbOPXfqB2nsnodD56XS9x9x6Xnp8uPx8dHo91z45x8a6fH9afR3+6F+vce2+mXtj6e9vjGc+5vXu36fV4Yz8fHbdvjPU5Z+P6/wCLHAHgv4P/AEe7T1T0Xp+//d/Qz6h1Owx0+h2XHuvnqYz3GOOOXPq5+75+7PHOcYx8/rPz4x8fsf1D/l39Hfpr9ROh9MfW+79W7v1jl9me8z6d2Oe46Xp+OWMZ456+cZxnH4zjPxxxyzjGcZzjGMvLfxi9O6Ppv0U9vcOj/wDr+PW7jlnfPq8s/wD5f7HwF7n7v++fq39SfcPW4Zv3Punvu1zy5fnP2dDnLjj58f4cg+8f5FfTL0j6jfTzvPXvTuz6XV9Z9L7XPfdh3PT44+/rdPjx+7l0vn+uOXH5+MZ/r8ZfC/tfsul7g9b9J9O6PLHU6fqXddDocc8c/wCbHU58cY+P/O/oh9Gut1PVPpB7W595zz1OXW9I6PT555Z+c8sY4fb+f9mHw/8Axs9C4999a/TPQul0Mw9F9e7/AKOeOcfH2dPter1ccfx/T4+zjgH3h769/wDsv6Rezur7t99esY9K9E9Oj0Or3H9n6vW+zPPlx6fDGOHS48uefnlnGPxjPx+8/h+T/wC/2/id/wA63/8AIvUv/wDXfoH1r+j3pX1w9qdv7L9e9Z730/0zj6h0O+7n+x44V62OlnPLj08cueM444+74znP25/GPj8fPy/LPcH8JPaPU9P6n+ivuz1jt++xj56efUM9LrdLlnxnHDhwzj/X+fjxkHzL9dPq97L+sf107z3D9O/c3V9Y9C6Xt/s+3xzz0Ov0OHHuOPV6ueeMdPrceGfn45cfz8fGfP4fQf8ACD29n7PcvurqYxnGeXR7Dpfj9ZxjPPn+f9vB82e7vaXrvsb3B3ftn3H2ee273s+X28sfPzx58c/5efHP9eOcfnGf+zPzh9mfQrh2302/jln3T6h9vT447Pu/W+ty/X+DGOXLj/6HHiD8H9ueh8/5EfzC99dX1Xvur3Htr293XHso8epnPDPDteOOHLp4x8/GM8urnPznH9MZx+/y+nPqx9Z/pb/G32n2Hee6MdTs+063P+yem+m+mdpjn1etyxj5+3p9PHxxxjGP68s4x+cfn5zh/PT6Q+/vf/tD0XvPcPtj3H1vRvVvcvPrd53fcdHo9PqZzy6vU5c8Z+Opx5Y/HzjP5w293eufUf6ke4vSPcH1N9/dT3Jz9B6fW6fYcOr6Z23bRr9v3Z+ejx445f5cfvGf1+PgH9EfpP8AWT2D9fvbPdd/7f7L1Dh0unnHQ77031nsM9DrdP7sfOMc+Gfnhz45x8/njy5cfxnHz+Hx/wDyR+n3pf03+qGfRvQ+ljpdj6v2uPUez6HHPzPH3549Thxx4xy+PjXLGP6P3b+GnsH1j0D0H1X3j6r0Op2/T9dj0+z6fPj8Z59Lp/dmnx4znl+POMfP6zh+PfXn3p6d9Rf5ke3favpfU49fsvafDtfS+96vHPzxz3Pcd10+XPp+P8PHHHGfj+vzj+gPpz6MfTb259HPp/w9T9R4dv0PUOp2n9t9X9Q6uMfPDGOP38uP3Z/OOHDH9NZz+8vG/SL+WP0l+t3ubvfavszn6zjr9vjny6HX730/l0e373hx+Pu5dHn85/Xz/l544cvxnP2/GHX+Xff9b0z+Nfv7q9tnlx5dT0jn23+HPxnGOpy48M/9XLL49/jfwx6F9TvZXb9nx+zHQ7np9DGMfj8cuGePL/z4zkH6j/L/AOmHpXs713033p6D2XDtey9f6vPt+66XS4/bw4d3jjnnjljGMfGPv4455zvj55PeP4jfSL0Xh7e4/Uv1zsOn3Xf931efH07HW4YzjtunwznjnqccZ/5XLOM/4vGMfH7y81/OXtvn6Ad/6pw6XPn1fSvVfTO64fZx+c8cf2rhw55/1fZz5fOnyt2f1o+t3oHpPZ+iey/qb3XofZ9jx5cOn0ePp3adzw+M/n4+Or0+Wfxnf9cg+sPqB/NL6MfTv371fp13/wDpB6r6p2fPHT9Q5+k+m57no9jnOPn/AIXP3Y5Z+MZx844ceecfPx+3v/vn2V7P+tXsXHT6nDod10u+7XHc+md/x4fHPpcuXH54dThnP5xj9fOP64/GcP5v+0/a/uP1j1/uunnuet6/7i9zepdTu+v1uPb46fU7jr9XPzn/AA8f8PHGM/Ofx8ccY+fxjGH9H/Tev6b9FPo30O490+odPh2vtX0fHPvOv+uOc9Ph88sY8/OfxjH9fnAPgv6b+yO8+oXvrsvZXbc59Tqd51e27vqcP8WOhjo8uWOtn/Z9nLGN/Hl91+s+sfSv+NP016vq3qfPo+i+g+mcePHly48Pv63c9XP4xjGMf4up1OWf/wDsYx+Pl3+APHqe5PePuL3t33Qz0+v33HvPUOnw5Z+c8Md13Wef+38f12/av5QfQr3P9f8A1D2Z7Z7Lv+27D0D0nvet6p6p3Hccc88Z58eH2dHp8enjOPv5Zzy5Z/OcYxjGfz8/GMh7f9IPrh9O/wCQ/tzvu79tdl6jx6HS+Ol3fYesdjHqfZzxn7eWePzy4c+HLGM/GePLOP6Z+Mvjr+QPsXs/px9VPUPbvpvSz0uw7rodP1LseP8ATj0upnljPDGf/B58eWP9WeL9f9U/h19QPb/onqHH6e/WHvu27zu+l9nU4dnX0zn1eOPzjGOr0+ry/P7+Pux8fn+j5Z7/ANp+s+3fcnd8fdfqHr/eeudtjl2nccvWO+6ncdbhj7vnPH555/Xz+cZx+M/Pzj9g3AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXel+h+t+udXPR9F9H771DqY/fDte359Xlj/ZxxlC+tP4Se6PT8el+vezer1+HDvP7Tx9R6XDOcYz1OGeHHhy+PPxnhx+f/GwD5X9V9G9X9B7zl6d656V3np3d8cY5cuh3fQ5dHqYxn84znjyxjPxl99/xp/4lfbn/AEXV/wDe8nov13/i/wCtfU731w98e2/c/bdrz6/adHs+67Pvvvlxny5fHV6eeOM/4s8efxnjnGMZ+3j+cP1r2t6R6N9Ifpr2vp3qfqvS4dh7e7Hl1O773qYnw+OOM8up1M4zn8Y+fnPx8g+E++4dHn/LD3Rw7jGM9Ll767bHU+f19v8AwHz/ANT67/l51O+6X8bPf/8Ad+M05+k8+nz+P6dPly445/8Ao5y+APTfd3de7PdfuT6ldty5dHPrnuHufU+y5fbnGePSxzxjpZ+M/wBcY44/24f0W9j+7/Z319+mfX9P77j0e44eo9jy7D1n0/lyxnn088+H288Zx+/tz85zxz8fkH86PS+y6Hp3pvbdh23DHHp9DpceHHGNYf0W/jl1e46v0Y9s57nPLPLj23Ljx+f/AKGOfLHH/q+H4fw/g76v0vXen2/D3v2nL0HhnHz1eXR5f2z7MZ/y/Z8fZ8/H/K+74+fz9v8AR+tfWn6t+yP4w/SW339Hj3Pbdp/YvQfS8dT/AIXu+vjj8cMYx+/txn4zy5fH4xvOMA+d/wCOXU7b/fVe6O17LPDPb9r6/wCt9Pp/Zy+7GPnny5csf7OXLlj4/p+v6Pe/90Q5dTqfTn2V6dnn/wDN+894dtw6/D4xnHU48e36/PGM/wD2uOMvyD+EPa+pdH6p9h3vrXLPL1P1Pj33qHe8s4+M563Vxnny+d/l+vf7oX/3j+wf/rl0P/6XuAfmn8VOXLj9afSMcc/H3dHuMZ3ieX67/Pvlnj9LvbeeOfjP+lPZf+z1H5D/ABW/46vR/wDou4/91yfrv8/f+K323/8AWrsv/Z6gPI/wk/7wvXv/ACx/+D03zz/K3p46/wDKT13uer/i59t6B6d0elnOP8vHlnqZzjH+3D6G/hJ/3hevf+WP/wAHpvnz+VH/AOk57k/8i+l/9nVB+/8A8IufLPsn3Dwzn/Dj1TjnGN56PH/+2H4P/K7h1et/KH1fodHhy58+p7f9L48eHHHznlyzy62MYxj+uX7v/CL/ALzPcX/lTh/7ri/Ev5Nep9f0T+W3ees9rjGet2Ho3o/ddPGf193DqdXlj/rwD0fn7P8AfnoXb8fcXX9p+udl23ac+HVx3nV9P6vDpdPljlj7c558uP24/Px+36P9A/q59T+P1k7HHrX1A9c9Z9O9wdzx7buPTe+7jHV7bpfPH448ujxzj56WcZxjP+HOMZ+c/OMvrXse+9nfXn6Zdbo47jl1fTfXO0z2/dcOj1fs63b9TOP8XH5x+ePPjn84zrGf09I+mH8VPbP0592cPdnX9wd36x1u05cuXYdLq9Dj0uPRznHx93L4zn7+WMZz8Z/w4/P6/QPF/wA1/b/pvP6U8ve/PtOGe99B7ztsVx8Y5Z7frdXj0+px+c/vGPvxz+P/AAdvdv40950e9+ivtzn0OXzjpdLq9Hlrlx6vLGf+vD5//n59YfR/UfTfTv4+e3O56fe+seq972/ees46XLHLHY9r0eeOpxxzzj9c+XLHHOMeOP5/ePn27+Gv1J9O/unu/pr6l3XDo930uty7v0/jzz8Y6vDl/n4cfPLGcfPx4zrIPlL3B6d1/SvqJ7/7LufimPd3qvVzjH9MdTr558f3rlh/RT6I8OXa/R72nb/D9vpPR55+f6Yzx+f+zL0L31/Ej2f719/d3744eu976dj1XrcO49T7Pp9Ljz49fqceGOGeXDlnOJ55cePH5/HL9Zz+M5eU/kp9WfQfoJ9F/Ue86PW6XR9R63aZ9L9B7LGf8fV7jlw+zh9vH95xwx/iznxjeAfNn8MvSMe6vrV677mzjPW7bs/VPWfUeHUzjHxjl1O558eH/nxz5ZTfzZ9wY9x/yK9D9ucP8XR9o+gcu45Z/px6/dc/zj/X9nDjl+n/AO57+yOXtz6c+o+sd30s8e47jqdPtc8s/wBfs4558/8A0upnH+x8we8fcP8Apv8AWb6i+9/u5cun3frvU7Dts8s/P/A9rjHS4/Gs/b8g/oB/GnvOj3v0V9uc+hy+cdLpdXo8tcuPV5Yz/wBeHwB7g9O6/pX1E9/9l3PxTHu71Xq5xj+mOp188+P71yw+rf4a/Un07+6u7+m3qfdcOj3fS6/Lu/T8c8/GOrw5f5+HHzyxnHz8eM6y9q99fxI9n+9ff3d++OHrve+nY9V63DuPU+z6fS48+PX6nHhjhnlw5ZzieeXHjx+fxy/Wc/jOQe+/RHhy7X6Pe07f4ft9J6PPPz/TGePz/wBmXwj9CPfHuX2x9QPcPvf2l7W6vuXuOv6v6vy4dvw6XUz/AIOr3XPOOX/B4znj8/H7+Pj85/D7F/kp9WfQfoJ9F/Ue86PW6XR9R63aZ9L9B7LGf8fV7jlw+zh9vH95xwx/iznxjeHyX/D/AN59r9HvcXpXbev9xjoen+odp/Y+/wCpy/y9Lqc+X3458tY5/jOfGc5/oDzH1z/kV/KD3T/dvt3oe0+/+knp3X4c+fdd70u459Tuu9+PjHx0epz6XS59PGPnH+XHz85x88v+Tn9L/hn9S/fPqXrPfewfdvu/1f3L0On2We87XuvVerx63cdLPDlx48uOer8Y588Z+/Gf8eeWfxn8v3L6tfR/2x9afROy7f1Hv+v23W7Plnr9j3va88csY+7j8Zxnj/l58M4+M/GsZxnCD6N/Qf279Guj3ne9H1Xq+pepd308cOv3nW4Y6XHj0+P5+3hw+c/bj5/OfnlnP4/YPxL+b/o/S/0y+n/c9l0//n3r3LuvSeWMY/HUzx+zn0s5z+/xnPPH/wBr/U9u/mF6px+nX8Ue+9r+mY4cOt6l0Oy9udv08fj5x1M8eHPGMf8AiY5/h+beve/PTv5HfzP9o+g+1urjv/a306z1+r1u76XP56Pcd5nH3c88f6cuPHPDhxxn8/8AK+Pxn5zv/ug/uD+8fdH03+nfD45cOHX7n1/ucfP+WXGfS+cbzz5/+YHzz2Xa8Oy7Podn08fHDodLj0+P+rGPh9M/x1/jX/pHjtvff1A7Plx9L+cdXsfT+pj4z3XjqdTH/wCz8Y/5X9fx+/SP40/S/tPqT79+71noY6vpPovT4933XTz+ury+fjp9POs5xnOfOOOcf1fb/u32xx91e1u/9q9L1z1P0Pp9/wBDPbZ7z0rqdPpdz0eGcfGZ8ufDnx45+Px8/b84+fx8Z/IPmL+UP8xej7O6ncfSL6H56PqfvDqcc9v3Xf8ASxjl2vovD4+M5+f8vLq4/pj/AC8f6/Ofjjn5q+i/o3T9r+8fbvW7vu+fdd31vXO07zv+76mc559fq56/Hly5Zzn85/r+/wDX+8vrn2//AAF+i/tvteXbenet+7c8upy+7q9bqd523Lq9Xl55cv7P+f8Asfif8i/p37V+ifvL217f9q996z1+49U7Pr+oV7zqdLnjp56PU4Yx8Z4cOHx/m+f1n9fsH05/MHter3f8a/ffDo/nPD022f8AxeHU48s/9WMvkb6CdLn3H1b9o8Ol+c/2/p8v9mMZzn/qw+2vZPuT2p9dfpby6Hdy7rtvVOx5en+r9nnl/i6fPlw+3qcOWP3j5+c5xn+uM4y9U+k38WfbX0t90cfdHH3B3fq/V7Xhy6fYcOv0OPCGM8ftzy5ZxnP38/j5x84xxx/iz+AeJ/nj6lz7D+NnrvS6PWn1e+7307teHxjGc8vu7vp55Y/P/g45Pjv0L0P1b3J6t2voXonZdXvO+7zqY6XR6PTx88uXLP8A2Yx+85z+MYxnOX7F/PL6q+n+6fdntn6G+3e94dzz9M7zj636/npcvux0Ps4/8D0eWf192fuzyzj94+eHl+x/xH+lnZe3/aXD6gepdrx5+q+t8c/2fnyx856Ha/PxjHHxnnnH3Zz4+3H9AeV+l/0q9kfx29o937397+q9j0vUel22ep6j6p3HLHHpdp0/3np9LOf6fPxj5/fLPxrD49/kD/In17+UXqf+jHtvt+49I+mnp3dY6mc9XH2df1jqcM/4efLH/J4Yzj8cf6fvP+L4xx+2frj/ABy9qfyAx6Z2vvb3V7o7b0z0vnnq8fTPTe66HR7Xr9T/AOn1ccujy5cs4x+Mf4sYxj5+MfnL1Po/wj+k3b9Lh0Oh637o6fT6fHHHhw49z22MccY/WMYgD84/hB1+17T3j636Zw+zhnqemcM9Lhj8f4eHUxjPxjxj7sP0r+Yn1y96fRn2d6L0fp32nacvX/c3qOew7fue74ff0+04ceGefPqfZ+uXL4xj4+fxj85+M/Hxn5o+k/1D9M+mf1j7n1Ts/wC1/wB0+ler976J3VuPHPV5dDh1eXT5cv8AD+M5x9vHl+MY+fj9Y/T7U+pX0y9kfXv2j6f0e+7zPU6HS6vH1D0v1Hs+fHlnpc88c8fu4/PzjljPHlnGceM/0zj5B+X/AMRfrN9R/qBj1P2z9TPWez9a7/sejw7no+odDseHa8+XHOft5cOfDh/gz8Z+PjPHjx3h+e/zf9K7f0j6j+1/Vu37fjx/v/0/uel3HLGcY+er2/Lhnhn4854dTljOfj/kY0+g/ox9BvQ/o3x77vOh6x1vVPUO+48en1e56nSx0uPDp8c/OOPHhjOfj8/nOc5z+sfp8cfyp+qno/1b+vnZem+1e46fe+kewuw6/adTvely+7p9Xvevy4048c4/GccccOOPnGf3x5ePyHoQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC70X1v1f256n0PWfQvUev2Pfdty+/pdfo8/t5cc/wD3484z+M/1QgP1rl/Mb+SPp3Q4dv6Zj2L6pjjj4z1vVfTe54dbO+Weh1uPDOf9XDi/NPqd9Tfrp9c+jx9J+pnvLsey9Axz48+p6N6B0efQ7fr5x+cU5c8558sfPx+OWeWPx84xjP5QAOXa9r2/Zdt0u07Tpcel0ejxxw4cOOPxx44/WHkPTPV/V/Q+84eo+h+r996Z3nT/AMncdn3HPo9XjrHLjnGfjzj9Z/WfnCQB7b3f18/k/wAuH9n9O+vHedDofb9uMdb0D07q9T4/6THR48v9v7fnncei+oeue4M+7/fXub1T3T65n9d56n1s9Sf5znGOHHPzjhjHz+MY/GP6fDywDzPtP3f7j9jes9P3D7V9R/sPqPS4cuHDrR6fV+3HLHxn/Dz48uOfxp473t71+tX1Px6V2n1K+qv9/enekeocfUuh2v8Acfadr8dbjx5cMZ+/o8ePL/Lz5Y/Pzj8/pOA8v7V92e4PZPrXR9xe2PUP7F6j2+OXHp9aXDqfbjlj4z/h54zxz+M/1wk96+/frj9TOh2Xpn1E+rH99eldj33T7/h2f9xdn23/AAnD5+3/AITo8ePL9Zzj95xpGA9m9A+q/wBWPYvofc+i/Tf3x/o9x7ruMdz1Of8Adnbd388vjHHP463Dl+8Yxj8Z/o9V771D3v7n909/7z+oPvD/AEh9X7/odHtuXcf3f0e0+On0vu+3H29LGOP/ACs/0xn/AFugD2X299Vfqr7E9F7v0f6b+9f9Hv7Z1uPX6nU/u3tu7+eWMYx+utw5fvGPj9vVvUPUvfXur3X3nvT6h+8v9IvVu77Xo9nnr/3d0e0+3pdLPLPHH29HGOOf82fz8fO8ugDy/t73h7w9n9fl3ns/3R6j6L3PP99TtOpj45ePu4cscuHP/Vz45xpX619bP5Peudr1vTe6+v8A6j0uz6+M8OWO29F7Ltuvjjnx1ujw4c+Od4+MvXQHiPQvbHp/oPPr9z0ufX7rvu7556nc973XUz1Ov1uWc/Oc8uWfOfzv+vzl5vodfr9r1uHcdt1up0er0uWOXDqdPlnjy48sfrOM4/OMuYD3Dq/Xn+SHa9Dh2nt/62+odl0OHH7ccO69J7LvuWMf9J1elnqZ/wBfLlnL889S7D3B7s9ycfeP1I95eqe7PWen/wBx63fc/jpdDHjpdLH+Hhj+vxx+MfP5+Pn8vJgPaew+sP1o9r+2ul7V+n31Dx7e7Hh1OfU5ccekdp3WeX3/AD92Pnq8M8sfOc/Pz8/0/Hw9E9u+jZ9B9K6fp3Pu+XddTjy59Tq9flx+M9Xny5Z5Z5Zx85/Pzny8kA6dDr9ftetw7jtut1Oj1elyxy4dTp8s8eXHlj9ZxnH5xl7Z1frz/JDtehw7T2/9bfUOy6HDj9uOHdek9l33LGP+k6vSz1M/6+XLOXp4DxnqXYe4PdnuTj7x+pHvL1T3Z6z0/wDuPW77n8dLoY8dLpY/w8Mf1+OPxj5/Px8/l5MAey+i/Vb6ve0ewz2Hsb6l+q+idLH+XpZ6XQ7zocf9XS7jhz48cf8Aifb8/wBXhfeHv769fUf07n6H79+uPrHfeldbGePX7Tsex7f07HW45/fHnnoceP38c+OWM4SALvp167619JOrnu/px3vT9H7vHQ59Dj1/7N0+vn45fHznOOrx5Yzn544/P7/Hx8/DxnrHqPv33n7w5e+fqV725e5PVuPY8fT+j1c+n9HtMdLo4555fGOPRxjj+85/Px8+c5dQHsftn6m/Ur2B6f6h2n0592cfQev6h9mep3H939v3Wfnj+vx1uGf6Zz+Pn4/Kj/fBfyx/5/8A/wBVfTf/AIb1QB7X/vgv5Y/8/wD/AOqvpv8A8N6t7j9xfVD3/wC5Ow9y/U76hf6Sdx6Z2vV7TtMf3T2/Zz4dTlx5cv8AuOOOM/njj94y1AeU9v8Aur3R7S7zPqPtT3F3/o/d5x8W7Tq/bnPjHLjn5488f+DyxnGl3rf1s/k7652vW9N6/wBfvUej2fX454csdv6N2Xb9fHHPjr9Hhw58c7x8ZeugPE+g+2ew9A/tHV6PU6/c933nUz1e67zuepTrdfnnOc5zy5Z/f5znP+vPzn8v0jqfXr+RHYdj2HpHs/6scfQvTvT+349t0u24+3+w7jGOPH8cf8XPp/P4x8YemgPa/wDfBfyx/wCf/wD9VfTf/hn++C/lj/z/AP8A6q+m/wDw3qgCH0nsvUO04931vV/Vf7x77v8Avev3/ddzDj0adXq888+efs4/jHzyznPxj4x4xh7d7e+pH1M9l9vz6Hsb376p6Fjl85+zpY6XX6Pz5z0evw59P585xxxnb18B5D3Z9SP5Ce//AE7qeh+8vrt6v3PpfXxnj1+37D0/tvTs9Xhn98eXPoceOeXHP9cZ+cZ8PAeieh+me3ux4+neldtjpdLj+c/15c+X9eXLP9crwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+D4z4BgZ+M+AHeWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAkloVy0AriRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COJFZLRLQI4kVktEtAjiRWS0S0COIsloBZLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0S0qloloEstEtKpaJaBLLRLSqWiWgSy0KpaAWS0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctCyWgFctEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLQrloBZLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0K5aAVy0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktCuWgFstEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLRLSuWiWgSS0S0rloloEktEtK5aJaBJLQrloBXLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktEtK458Ec+ASS0S0rjnwRz4BJLRLSuOfBHPgEktCuOfACyWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAkloVy0ArlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWiWlkSII5aJaWRIgjlolpZEiCOWhZEBXLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0S0sloloEctEtLJaJaBHLRLSyWiWgRy0LJaAVS0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLRLSyWPBLHgEctEtLJY8EseARy0S0sljwSx4BHLQsljwAslolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaJaVy0S0CSWiWlctEtAklolpXLRLQJJaFctAK5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjlolpZMmCOWiWlkyYI5aJaWTJgjloWTAdAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAa5z+QbDGP0yAAAAAAAAAAAAAAAAAAAAAAAAAAADGc/AMsYz8tQG41xn4bAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANc/ts1z+wZx+mWuM/GGfuwDIx92D7sAyAAAAAAAADGc/AMsYz8tQG41xn4bAAAAAAAAAAAxnPw1bZ/TUAABnGfhhnj+wbAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAxn9Ay1z+2AAAAG2P0DIAAAAAAAMZz8NW2f01AAAZxn4YZ4/sGwAAAAAAAAAMZ/TVtn9NQAAGeP7YZ4/sGwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADGf0yxn9A1AAAAbY/TVtj9AyAAAAAAADGf01bZ/TUAABnj+2GeP7BsAAAAAAAAADGf01AAABnj+wBsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAxn9ADUAAABtj9ADIAAAAAAAMZ/TUAAAGeP7AGwAP/9k=	composed_1780164425808.jpg	31376	2026-05-30 18:07:05.825232+00	post
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (id, user_id, current_refresh_token_jti, ip_address, user_agent, created_at, last_seen_at, expires_at, revoked_at, revoked_reason) FROM stdin;
8b9ae3b8-3e1f-41c4-8b87-2d8e29146f0f	321816a3-3698-4041-8cd9-7b6d17aedae1	6a1c69c2-7095-484a-b6e9-236b996c4402	172.19.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-27 15:30:05.388475+00	2026-05-30 18:02:16.627844+00	2026-06-29 18:02:16+00	\N	\N
57d4f771-2cc8-4218-be39-4a83baee0960	321816a3-3698-4041-8cd9-7b6d17aedae1	0fa147dc-49d7-4ef4-9780-b3c3a27218b7	172.19.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 15:47:27.825098+00	2026-06-02 15:47:27.825098+00	2026-07-02 15:47:27+00	\N	\N
1d41d52c-9433-4064-8660-819f35a9efe1	321816a3-3698-4041-8cd9-7b6d17aedae1	4ce767d7-e70e-4eb7-bccb-c0f0319888f0	172.19.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-16 12:47:04.727922+00	2026-06-16 12:47:04.727922+00	2026-07-16 12:47:04+00	\N	\N
ecb2537e-aa79-4b15-9a44-2c4d886a7d8a	321816a3-3698-4041-8cd9-7b6d17aedae1	e8d094b1-0329-4d8a-a51b-a6fcae51d4d8	172.19.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-16 12:48:23.880615+00	2026-06-16 12:48:23.880615+00	2026-07-16 12:48:23+00	\N	\N
3f74edad-254f-47e0-a58f-d67eacbc5f54	321816a3-3698-4041-8cd9-7b6d17aedae1	f452c94f-0000-4134-a2a2-4d6e43161a3b	172.19.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-16 14:06:05.404002+00	2026-06-16 14:06:05.404002+00	2026-07-16 14:06:05+00	\N	\N
15814723-4b2f-4374-85a5-82fbedf0f3ad	321816a3-3698-4041-8cd9-7b6d17aedae1	a99697ff-bfe9-4cf7-89f2-a7d6ce75f5e9	172.19.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-16 14:29:47.29578+00	2026-06-16 14:29:47.29578+00	2026-07-16 14:29:47+00	\N	\N
ac506762-76c4-4f9b-a59a-94216ca2633c	321816a3-3698-4041-8cd9-7b6d17aedae1	40a94a7b-ce21-406c-99d3-2a3b345467a2	172.19.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-18 10:41:19.140537+00	2026-06-18 10:41:19.140537+00	2026-07-18 10:41:19+00	\N	\N
40e27f6d-4749-4747-9a98-980bb00c0568	321816a3-3698-4041-8cd9-7b6d17aedae1	aaa3afaf-6006-44b2-b66c-44b0336803eb	172.19.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-18 13:08:53.70979+00	2026-06-18 13:08:53.70979+00	2026-07-18 13:08:53+00	\N	\N
86723453-dcc0-4b89-afb7-d846f62ba497	321816a3-3698-4041-8cd9-7b6d17aedae1	a8a7f7e3-6c56-4c2d-b253-d4e8aeaaa615	172.19.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-16 13:41:43.39117+00	2026-06-18 13:10:40.176444+00	2026-07-18 13:10:40+00	\N	\N
c342975b-c9a8-4e62-a1a5-ad2ee257bd01	321816a3-3698-4041-8cd9-7b6d17aedae1	cae00736-2edf-4c8a-858e-fd8415ca77d8	172.19.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-25 14:22:48.798848+00	2026-06-25 14:22:48.798848+00	2026-07-25 14:22:48+00	\N	\N
12d16d72-7e60-4f15-8887-a0d3eac08955	321816a3-3698-4041-8cd9-7b6d17aedae1	b7b8982e-103f-46c9-b785-834d2c873cb3	172.19.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-25 14:36:34.355447+00	2026-06-25 14:36:34.355447+00	2026-07-25 14:36:34+00	\N	\N
23436a6a-562c-47ae-9670-aeeac6688481	321816a3-3698-4041-8cd9-7b6d17aedae1	43d3f42c-ef04-44d7-822a-d4178a453a4c	172.20.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-07-07 12:57:49.466816+00	2026-07-07 12:57:49.466816+00	2026-08-06 12:57:49+00	\N	\N
395f7ba5-776f-444e-b16c-b66991a2ef57	321816a3-3698-4041-8cd9-7b6d17aedae1	f0bcb149-1154-4ab0-b583-632defbde332	172.20.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-11 13:13:46.640865+00	2026-07-11 13:13:46.640865+00	2026-08-10 13:13:46+00	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, stripe_customer_id, created_at, updated_at, last_login_at, metadata, failed_login_count, locked_until, email_verified) FROM stdin;
f4ea36a4-0da7-444d-9146-f0f962dc1a09	arfanshaikh0852@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$k9L639tbi7FW6v0f4xwjZA$9xSxlOnDrybXPYQesB4UksrEhaIkwjKF7rk0rsXCR9g	\N	2026-05-27 12:19:49.777413+00	2026-05-27 12:19:49.777413+00	2026-05-27 12:19:49.833736+00	{}	0	\N	f
bd8cdd8f-9067-4946-b87b-57a69cc86259	ayanshaikh0852@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$gxCiFCKkNMb4XwsBgFAKgQ$+ZAoUNb4nurqekOauemdAQlJAO24B5qDt18Illa7dWI	\N	2026-05-26 10:02:55.03075+00	2026-05-26 10:02:55.03075+00	2026-05-26 10:02:55.093969+00	{}	1	\N	f
321816a3-3698-4041-8cd9-7b6d17aedae1	minnahyaan@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$wViLEWLs/d97b83Zm5OSsg$zskwqgTvtyFJwkyVuvRCmy10k6B2fDbOk8LbTdd4RVA	\N	2026-05-27 15:28:13.610648+00	2026-05-27 15:28:13.610648+00	2026-07-11 13:13:46.640674+00	{"timezone": "Europe/London", "name": "Arfan Shaikh"}	0	\N	t
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: birthday_configs birthday_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.birthday_configs
    ADD CONSTRAINT birthday_configs_pkey PRIMARY KEY (id);


--
-- Name: birthday_schedules birthday_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.birthday_schedules
    ADD CONSTRAINT birthday_schedules_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_token_key UNIQUE (token);


--
-- Name: message_groups message_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_groups
    ADD CONSTRAINT message_groups_pkey PRIMARY KEY (id);


--
-- Name: message_history message_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_history
    ADD CONSTRAINT message_history_pkey PRIMARY KEY (id);


--
-- Name: message_queue message_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_queue
    ADD CONSTRAINT message_queue_pkey PRIMARY KEY (id);


--
-- Name: message_templates message_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: revoked_tokens revoked_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.revoked_tokens
    ADD CONSTRAINT revoked_tokens_pkey PRIMARY KEY (id);


--
-- Name: send_rate_limits send_rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.send_rate_limits
    ADD CONSTRAINT send_rate_limits_pkey PRIMARY KEY (id);


--
-- Name: send_rate_limits send_rate_limits_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.send_rate_limits
    ADD CONSTRAINT send_rate_limits_user_id_key UNIQUE (user_id);


--
-- Name: smtp_configs smtp_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smtp_configs
    ADD CONSTRAINT smtp_configs_pkey PRIMARY KEY (id);


--
-- Name: smtp_configs smtp_configs_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smtp_configs
    ADD CONSTRAINT smtp_configs_user_id_key UNIQUE (user_id);


--
-- Name: subscription_records subscription_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_records
    ADD CONSTRAINT subscription_records_pkey PRIMARY KEY (id);


--
-- Name: template_segments template_segments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.template_segments
    ADD CONSTRAINT template_segments_pkey PRIMARY KEY (id);


--
-- Name: user_images user_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_images
    ADD CONSTRAINT user_images_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_current_refresh_token_jti_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_current_refresh_token_jti_key UNIQUE (current_refresh_token_jti);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_birthday_config_user_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_birthday_config_user_enabled ON public.birthday_configs USING btree (user_id, enabled);


--
-- Name: idx_birthday_config_user_mode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_birthday_config_user_mode ON public.birthday_configs USING btree (user_id, mode);


--
-- Name: idx_contact_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contact_group ON public.contacts USING btree (group_id);


--
-- Name: idx_contact_user_birthday; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contact_user_birthday ON public.contacts USING btree (user_id, birthday);


--
-- Name: idx_contact_user_gender; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contact_user_gender ON public.contacts USING btree (user_id, gender);


--
-- Name: idx_email_verif_token_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_verif_token_expires ON public.email_verification_tokens USING btree (token, expires_at);


--
-- Name: idx_email_verif_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_verif_user_created ON public.email_verification_tokens USING btree (user_id, created_at);


--
-- Name: idx_history_user_sent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_history_user_sent ON public.message_history USING btree (user_id, sent_at);


--
-- Name: idx_history_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_history_user_status ON public.message_history USING btree (user_id, status);


--
-- Name: idx_message_group_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_group_user ON public.message_groups USING btree (user_id);


--
-- Name: idx_message_template_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_template_group ON public.message_templates USING btree (group_id);


--
-- Name: idx_message_template_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_template_user ON public.message_templates USING btree (user_id);


--
-- Name: idx_message_template_user_gender; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_template_user_gender ON public.message_templates USING btree (user_id, gender);


--
-- Name: idx_post_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_post_group ON public.posts USING btree (group_id);


--
-- Name: idx_post_user_default; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_post_user_default ON public.posts USING btree (user_id, is_default);


--
-- Name: idx_post_user_gender; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_post_user_gender ON public.posts USING btree (user_id, gender);


--
-- Name: idx_queue_scheduled_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_queue_scheduled_time ON public.message_queue USING btree (scheduled_send_time);


--
-- Name: idx_queue_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_queue_user_status ON public.message_queue USING btree (user_id, status);


--
-- Name: idx_reset_token_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reset_token_expires ON public.password_reset_tokens USING btree (token, expires_at);


--
-- Name: idx_reset_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reset_user_created ON public.password_reset_tokens USING btree (user_id, created_at);


--
-- Name: idx_revoked_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_revoked_expires ON public.revoked_tokens USING btree (expires_at);


--
-- Name: idx_revoked_jti; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_revoked_jti ON public.revoked_tokens USING btree (refresh_token_jti);


--
-- Name: idx_schedule_user_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_schedule_user_enabled ON public.birthday_schedules USING btree (user_id, enabled);


--
-- Name: idx_send_rate_limit_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_send_rate_limit_user ON public.send_rate_limits USING btree (user_id);


--
-- Name: idx_smtp_config_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_smtp_config_user ON public.smtp_configs USING btree (user_id);


--
-- Name: idx_subscription_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscription_user ON public.subscription_records USING btree (user_id);


--
-- Name: idx_subscription_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscription_user_status ON public.subscription_records USING btree (user_id, status);


--
-- Name: idx_template_user_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_template_user_deleted ON public.template_segments USING btree (user_id, deleted_at);


--
-- Name: idx_template_user_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_template_user_type ON public.template_segments USING btree (user_id, segment_type) WHERE (deleted_at IS NULL);


--
-- Name: idx_user_image_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_image_source ON public.user_images USING btree (user_id, source);


--
-- Name: idx_user_image_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_image_user_created ON public.user_images USING btree (user_id, created_at);


--
-- Name: idx_user_sessions_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_sessions_expires ON public.user_sessions USING btree (expires_at);


--
-- Name: idx_user_sessions_user_last_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_sessions_user_last_seen ON public.user_sessions USING btree (user_id, last_seen_at);


--
-- Name: idx_user_sessions_user_revoked; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_sessions_user_revoked ON public.user_sessions USING btree (user_id, revoked_at);


--
-- Name: uniq_active_subscription_per_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_active_subscription_per_user ON public.subscription_records USING btree (user_id) WHERE (status = 'ACTIVE'::public.subscription_status_enum);


--
-- Name: uniq_birthday_config_user_mode_offset; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_birthday_config_user_mode_offset ON public.birthday_configs USING btree (user_id, mode, days_offset);


--
-- Name: uniq_schedule_user_days; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_schedule_user_days ON public.birthday_schedules USING btree (user_id, days_before);


--
-- Name: uq_contact_user_profile_url; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_contact_user_profile_url ON public.contacts USING btree (user_id, facebook_profile_url);


--
-- Name: uq_message_template_user_title; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_message_template_user_title ON public.message_templates USING btree (user_id, title);


--
-- Name: uq_post_user_label; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_post_user_label ON public.posts USING btree (user_id, label) WHERE (label IS NOT NULL);


--
-- Name: birthday_configs birthday_configs_message_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.birthday_configs
    ADD CONSTRAINT birthday_configs_message_group_id_fkey FOREIGN KEY (message_group_id) REFERENCES public.message_groups(id) ON DELETE CASCADE;


--
-- Name: birthday_configs birthday_configs_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.birthday_configs
    ADD CONSTRAINT birthday_configs_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE SET NULL;


--
-- Name: birthday_configs birthday_configs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.birthday_configs
    ADD CONSTRAINT birthday_configs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: birthday_schedules birthday_schedules_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.birthday_schedules
    ADD CONSTRAINT birthday_schedules_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: contacts contacts_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.message_groups(id) ON DELETE SET NULL;


--
-- Name: contacts contacts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: email_verification_tokens email_verification_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: message_groups message_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_groups
    ADD CONSTRAINT message_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: message_history message_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_history
    ADD CONSTRAINT message_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: message_queue message_queue_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_queue
    ADD CONSTRAINT message_queue_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: message_templates message_templates_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.message_groups(id) ON DELETE SET NULL;


--
-- Name: message_templates message_templates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: posts posts_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.message_groups(id) ON DELETE SET NULL;


--
-- Name: posts posts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: send_rate_limits send_rate_limits_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.send_rate_limits
    ADD CONSTRAINT send_rate_limits_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: smtp_configs smtp_configs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smtp_configs
    ADD CONSTRAINT smtp_configs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subscription_records subscription_records_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_records
    ADD CONSTRAINT subscription_records_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: template_segments template_segments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.template_segments
    ADD CONSTRAINT template_segments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_images user_images_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_images
    ADD CONSTRAINT user_images_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict uHcQ3dbBZMslDeXLaYjNygH4dvSwNSk0lWKo2oygce2mJjVOgLFoCzNjdNn8tWg

