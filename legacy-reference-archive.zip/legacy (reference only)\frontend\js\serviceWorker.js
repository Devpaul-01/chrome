/*! For license information please see serviceWorker-old.js.LICENSE.txt */
(() => {
    var e = {
        9669: (e, t, n) => {
            e.exports = n(1609)
        }, 5448: (e, t, n) => {
            "use strict";
            var r = n(4867), i = n(6026), o = n(4372), a = n(5327), s = n(4097), u = n(4109), l = n(7985), c = n(5061);
            e.exports = function (e) {
                return new Promise((function (t, n) {
                    var d = e.data, f = e.headers, h = e.responseType;
                    r.isFormData(d) && delete f["Content-Type"];
                    var p = new XMLHttpRequest;
                    if (e.auth) {
                        var m = e.auth.username || "",
                            g = e.auth.password ? unescape(encodeURIComponent(e.auth.password)) : "";
                        f.Authorization = "Basic " + btoa(m + ":" + g)
                    }
                    var y = s(e.baseURL, e.url);

                    function v() {
                        if (p) {
                            var r = "getAllResponseHeaders" in p ? u(p.getAllResponseHeaders()) : null, o = {
                                data: h && "text" !== h && "json" !== h ? p.response : p.responseText,
                                status: p.status,
                                statusText: p.statusText,
                                headers: r,
                                config: e,
                                request: p
                            };
                            i(t, n, o), p = null
                        }
                    }

                    if (p.open(e.method.toUpperCase(), a(y, e.params, e.paramsSerializer), !0), p.timeout = e.timeout, "onloadend" in p ? p.onloadend = v : p.onreadystatechange = function () {
                        p && 4 === p.readyState && (0 !== p.status || p.responseURL && 0 === p.responseURL.indexOf("file:")) && setTimeout(v)
                    }, p.onabort = function () {
                        p && (n(c("Request aborted", e, "ECONNABORTED", p)), p = null)
                    }, p.onerror = function () {
                        n(c("Network Error", e, null, p)), p = null
                    }, p.ontimeout = function () {
                        var t = "timeout of " + e.timeout + "ms exceeded";
                        e.timeoutErrorMessage && (t = e.timeoutErrorMessage), n(c(t, e, e.transitional && e.transitional.clarifyTimeoutError ? "ETIMEDOUT" : "ECONNABORTED", p)), p = null
                    }, r.isStandardBrowserEnv()) {
                        var w = (e.withCredentials || l(y)) && e.xsrfCookieName ? o.read(e.xsrfCookieName) : void 0;
                        w && (f[e.xsrfHeaderName] = w)
                    }
                    "setRequestHeader" in p && r.forEach(f, (function (e, t) {
                        void 0 === d && "content-type" === t.toLowerCase() ? delete f[t] : p.setRequestHeader(t, e)
                    })), r.isUndefined(e.withCredentials) || (p.withCredentials = !!e.withCredentials), h && "json" !== h && (p.responseType = e.responseType), "function" == typeof e.onDownloadProgress && p.addEventListener("progress", e.onDownloadProgress), "function" == typeof e.onUploadProgress && p.upload && p.upload.addEventListener("progress", e.onUploadProgress), e.cancelToken && e.cancelToken.promise.then((function (e) {
                        p && (p.abort(), n(e), p = null)
                    })), d || (d = null), p.send(d)
                }))
            }
        }, 1609: (e, t, n) => {
            "use strict";
            var r = n(4867), i = n(1849), o = n(321), a = n(7185);

            function s(e) {
                var t = new o(e), n = i(o.prototype.request, t);
                return r.extend(n, o.prototype, t), r.extend(n, t), n
            }

            var u = s(n(5655));
            u.Axios = o, u.create = function (e) {
                return s(a(u.defaults, e))
            }, u.Cancel = n(5263), u.CancelToken = n(4972), u.isCancel = n(6502), u.all = function (e) {
                return Promise.all(e)
            }, u.spread = n(8713), u.isAxiosError = n(6268), e.exports = u, e.exports.default = u
        }, 5263: e => {
            "use strict";

            function t(e) {
                this.message = e
            }

            t.prototype.toString = function () {
                return "Cancel" + (this.message ? ": " + this.message : "")
            }, t.prototype.__CANCEL__ = !0, e.exports = t
        }, 4972: (e, t, n) => {
            "use strict";
            var r = n(5263);

            function i(e) {
                if ("function" != typeof e) throw new TypeError("executor must be a function.");
                var t;
                this.promise = new Promise((function (e) {
                    t = e
                }));
                var n = this;
                e((function (e) {
                    n.reason || (n.reason = new r(e), t(n.reason))
                }))
            }

            i.prototype.throwIfRequested = function () {
                if (this.reason) throw this.reason
            }, i.source = function () {
                var e;
                return {
                    token: new i((function (t) {
                        e = t
                    })), cancel: e
                }
            }, e.exports = i
        }, 6502: e => {
            "use strict";
            e.exports = function (e) {
                return !(!e || !e.__CANCEL__)
            }
        }, 321: (e, t, n) => {
            "use strict";
            var r = n(4867), i = n(5327), o = n(782), a = n(3572), s = n(7185), u = n(4875), l = u.validators;

            function c(e) {
                this.defaults = e, this.interceptors = {request: new o, response: new o}
            }

            c.prototype.request = function (e) {
                "string" == typeof e ? (e = arguments[1] || {}).url = arguments[0] : e = e || {}, (e = s(this.defaults, e)).method ? e.method = e.method.toLowerCase() : this.defaults.method ? e.method = this.defaults.method.toLowerCase() : e.method = "get";
                var t = e.transitional;
                void 0 !== t && u.assertOptions(t, {
                    silentJSONParsing: l.transitional(l.boolean, "1.0.0"),
                    forcedJSONParsing: l.transitional(l.boolean, "1.0.0"),
                    clarifyTimeoutError: l.transitional(l.boolean, "1.0.0")
                }, !1);
                var n = [], r = !0;
                this.interceptors.request.forEach((function (t) {
                    "function" == typeof t.runWhen && !1 === t.runWhen(e) || (r = r && t.synchronous, n.unshift(t.fulfilled, t.rejected))
                }));
                var i, o = [];
                if (this.interceptors.response.forEach((function (e) {
                    o.push(e.fulfilled, e.rejected)
                })), !r) {
                    var c = [a, void 0];
                    for (Array.prototype.unshift.apply(c, n), c = c.concat(o), i = Promise.resolve(e); c.length;) i = i.then(c.shift(), c.shift());
                    return i
                }
                for (var d = e; n.length;) {
                    var f = n.shift(), h = n.shift();
                    try {
                        d = f(d)
                    } catch (e) {
                        h(e);
                        break
                    }
                }
                try {
                    i = a(d)
                } catch (e) {
                    return Promise.reject(e)
                }
                for (; o.length;) i = i.then(o.shift(), o.shift());
                return i
            }, c.prototype.getUri = function (e) {
                return e = s(this.defaults, e), i(e.url, e.params, e.paramsSerializer).replace(/^\?/, "")
            }, r.forEach(["delete", "get", "head", "options"], (function (e) {
                c.prototype[e] = function (t, n) {
                    return this.request(s(n || {}, {method: e, url: t, data: (n || {}).data}))
                }
            })), r.forEach(["post", "put", "patch"], (function (e) {
                c.prototype[e] = function (t, n, r) {
                    return this.request(s(r || {}, {method: e, url: t, data: n}))
                }
            })), e.exports = c
        }, 782: (e, t, n) => {
            "use strict";
            var r = n(4867);

            function i() {
                this.handlers = []
            }

            i.prototype.use = function (e, t, n) {
                return this.handlers.push({
                    fulfilled: e,
                    rejected: t,
                    synchronous: !!n && n.synchronous,
                    runWhen: n ? n.runWhen : null
                }), this.handlers.length - 1
            }, i.prototype.eject = function (e) {
                this.handlers[e] && (this.handlers[e] = null)
            }, i.prototype.forEach = function (e) {
                r.forEach(this.handlers, (function (t) {
                    null !== t && e(t)
                }))
            }, e.exports = i
        }, 4097: (e, t, n) => {
            "use strict";
            var r = n(1793), i = n(7303);
            e.exports = function (e, t) {
                return e && !r(t) ? i(e, t) : t
            }
        }, 5061: (e, t, n) => {
            "use strict";
            var r = n(481);
            e.exports = function (e, t, n, i, o) {
                var a = new Error(e);
                return r(a, t, n, i, o)
            }
        }, 3572: (e, t, n) => {
            "use strict";
            var r = n(4867), i = n(8527), o = n(6502), a = n(5655);

            function s(e) {
                e.cancelToken && e.cancelToken.throwIfRequested()
            }

            e.exports = function (e) {
                return s(e), e.headers = e.headers || {}, e.data = i.call(e, e.data, e.headers, e.transformRequest), e.headers = r.merge(e.headers.common || {}, e.headers[e.method] || {}, e.headers), r.forEach(["delete", "get", "head", "post", "put", "patch", "common"], (function (t) {
                    delete e.headers[t]
                })), (e.adapter || a.adapter)(e).then((function (t) {
                    return s(e), t.data = i.call(e, t.data, t.headers, e.transformResponse), t
                }), (function (t) {
                    return o(t) || (s(e), t && t.response && (t.response.data = i.call(e, t.response.data, t.response.headers, e.transformResponse))), Promise.reject(t)
                }))
            }
        }, 481: e => {
            "use strict";
            e.exports = function (e, t, n, r, i) {
                return e.config = t, n && (e.code = n), e.request = r, e.response = i, e.isAxiosError = !0, e.toJSON = function () {
                    return {
                        message: this.message,
                        name: this.name,
                        description: this.description,
                        number: this.number,
                        fileName: this.fileName,
                        lineNumber: this.lineNumber,
                        columnNumber: this.columnNumber,
                        stack: this.stack,
                        config: this.config,
                        code: this.code
                    }
                }, e
            }
        }, 7185: (e, t, n) => {
            "use strict";
            var r = n(4867);
            e.exports = function (e, t) {
                t = t || {};
                var n = {}, i = ["url", "method", "data"], o = ["headers", "auth", "proxy", "params"],
                    a = ["baseURL", "transformRequest", "transformResponse", "paramsSerializer", "timeout", "timeoutMessage", "withCredentials", "adapter", "responseType", "xsrfCookieName", "xsrfHeaderName", "onUploadProgress", "onDownloadProgress", "decompress", "maxContentLength", "maxBodyLength", "maxRedirects", "transport", "httpAgent", "httpsAgent", "cancelToken", "socketPath", "responseEncoding"],
                    s = ["validateStatus"];

                function u(e, t) {
                    return r.isPlainObject(e) && r.isPlainObject(t) ? r.merge(e, t) : r.isPlainObject(t) ? r.merge({}, t) : r.isArray(t) ? t.slice() : t
                }

                function l(i) {
                    r.isUndefined(t[i]) ? r.isUndefined(e[i]) || (n[i] = u(void 0, e[i])) : n[i] = u(e[i], t[i])
                }

                r.forEach(i, (function (e) {
                    r.isUndefined(t[e]) || (n[e] = u(void 0, t[e]))
                })), r.forEach(o, l), r.forEach(a, (function (i) {
                    r.isUndefined(t[i]) ? r.isUndefined(e[i]) || (n[i] = u(void 0, e[i])) : n[i] = u(void 0, t[i])
                })), r.forEach(s, (function (r) {
                    r in t ? n[r] = u(e[r], t[r]) : r in e && (n[r] = u(void 0, e[r]))
                }));
                var c = i.concat(o).concat(a).concat(s),
                    d = Object.keys(e).concat(Object.keys(t)).filter((function (e) {
                        return -1 === c.indexOf(e)
                    }));
                return r.forEach(d, l), n
            }
        }, 6026: (e, t, n) => {
            "use strict";
            var r = n(5061);
            e.exports = function (e, t, n) {
                var i = n.config.validateStatus;
                n.status && i && !i(n.status) ? t(r("Request failed with status code " + n.status, n.config, null, n.request, n)) : e(n)
            }
        }, 8527: (e, t, n) => {
            "use strict";
            var r = n(4867), i = n(5655);
            e.exports = function (e, t, n) {
                var o = this || i;
                return r.forEach(n, (function (n) {
                    e = n.call(o, e, t)
                })), e
            }
        }, 5655: (e, t, n) => {
            "use strict";
            var r = n(4867), i = n(6016), o = n(481), a = {"Content-Type": "application/x-www-form-urlencoded"};

            function s(e, t) {
                !r.isUndefined(e) && r.isUndefined(e["Content-Type"]) && (e["Content-Type"] = t)
            }

            var u, l = {
                transitional: {silentJSONParsing: !0, forcedJSONParsing: !0, clarifyTimeoutError: !1},
                adapter: (("undefined" != typeof XMLHttpRequest || "undefined" != typeof process && "[object process]" === Object.prototype.toString.call(process)) && (u = n(5448)), u),
                transformRequest: [function (e, t) {
                    return i(t, "Accept"), i(t, "Content-Type"), r.isFormData(e) || r.isArrayBuffer(e) || r.isBuffer(e) || r.isStream(e) || r.isFile(e) || r.isBlob(e) ? e : r.isArrayBufferView(e) ? e.buffer : r.isURLSearchParams(e) ? (s(t, "application/x-www-form-urlencoded;charset=utf-8"), e.toString()) : r.isObject(e) || t && "application/json" === t["Content-Type"] ? (s(t, "application/json"), function (e, t, n) {
                        if (r.isString(e)) try {
                            return (0, JSON.parse)(e), r.trim(e)
                        } catch (e) {
                            if ("SyntaxError" !== e.name) throw e
                        }
                        return (0, JSON.stringify)(e)
                    }(e)) : e
                }],
                transformResponse: [function (e) {
                    var t = this.transitional, n = t && t.silentJSONParsing, i = t && t.forcedJSONParsing,
                        a = !n && "json" === this.responseType;
                    if (a || i && r.isString(e) && e.length) try {
                        return JSON.parse(e)
                    } catch (e) {
                        if (a) {
                            if ("SyntaxError" === e.name) throw o(e, this, "E_JSON_PARSE");
                            throw e
                        }
                    }
                    return e
                }],
                timeout: 0,
                xsrfCookieName: "XSRF-TOKEN",
                xsrfHeaderName: "X-XSRF-TOKEN",
                maxContentLength: -1,
                maxBodyLength: -1,
                validateStatus: function (e) {
                    return e >= 200 && e < 300
                },
                headers: {common: {Accept: "application/json, text/plain, */*"}}
            };
            r.forEach(["delete", "get", "head"], (function (e) {
                l.headers[e] = {}
            })), r.forEach(["post", "put", "patch"], (function (e) {
                l.headers[e] = r.merge(a)
            })), e.exports = l
        }, 1849: e => {
            "use strict";
            e.exports = function (e, t) {
                return function () {
                    for (var n = new Array(arguments.length), r = 0; r < n.length; r++) n[r] = arguments[r];
                    return e.apply(t, n)
                }
            }
        }, 5327: (e, t, n) => {
            "use strict";
            var r = n(4867);

            function i(e) {
                return encodeURIComponent(e).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]")
            }

            e.exports = function (e, t, n) {
                if (!t) return e;
                var o;
                if (n) o = n(t); else if (r.isURLSearchParams(t)) o = t.toString(); else {
                    var a = [];
                    r.forEach(t, (function (e, t) {
                        null != e && (r.isArray(e) ? t += "[]" : e = [e], r.forEach(e, (function (e) {
                            r.isDate(e) ? e = e.toISOString() : r.isObject(e) && (e = JSON.stringify(e)), a.push(i(t) + "=" + i(e))
                        })))
                    })), o = a.join("&")
                }
                if (o) {
                    var s = e.indexOf("#");
                    -1 !== s && (e = e.slice(0, s)), e += (-1 === e.indexOf("?") ? "?" : "&") + o
                }
                return e
            }
        }, 7303: e => {
            "use strict";
            e.exports = function (e, t) {
                return t ? e.replace(/\/+$/, "") + "/" + t.replace(/^\/+/, "") : e
            }
        }, 4372: (e, t, n) => {
            "use strict";
            var r = n(4867);
            e.exports = r.isStandardBrowserEnv() ? {
                write: function (e, t, n, i, o, a) {
                    var s = [];
                    s.push(e + "=" + encodeURIComponent(t)), r.isNumber(n) && s.push("expires=" + new Date(n).toGMTString()), r.isString(i) && s.push("path=" + i), r.isString(o) && s.push("domain=" + o), !0 === a && s.push("secure"), document.cookie = s.join("; ")
                }, read: function (e) {
                    var t = document.cookie.match(new RegExp("(^|;\\s*)(" + e + ")=([^;]*)"));
                    return t ? decodeURIComponent(t[3]) : null
                }, remove: function (e) {
                    this.write(e, "", Date.now() - 864e5)
                }
            } : {
                write: function () {
                }, read: function () {
                    return null
                }, remove: function () {
                }
            }
        }, 1793: e => {
            "use strict";
            e.exports = function (e) {
                return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(e)
            }
        }, 6268: e => {
            "use strict";
            e.exports = function (e) {
                return "object" == typeof e && !0 === e.isAxiosError
            }
        }, 7985: (e, t, n) => {
            "use strict";
            var r = n(4867);
            e.exports = r.isStandardBrowserEnv() ? function () {
                var e, t = /(msie|trident)/i.test(navigator.userAgent), n = document.createElement("a");

                function i(e) {
                    var r = e;
                    return t && (n.setAttribute("href", r), r = n.href), n.setAttribute("href", r), {
                        href: n.href,
                        protocol: n.protocol ? n.protocol.replace(/:$/, "") : "",
                        host: n.host,
                        search: n.search ? n.search.replace(/^\?/, "") : "",
                        hash: n.hash ? n.hash.replace(/^#/, "") : "",
                        hostname: n.hostname,
                        port: n.port,
                        pathname: "/" === n.pathname.charAt(0) ? n.pathname : "/" + n.pathname
                    }
                }

                return e = i(window.location.href), function (t) {
                    var n = r.isString(t) ? i(t) : t;
                    return n.protocol === e.protocol && n.host === e.host
                }
            }() : function () {
                return !0
            }
        }, 6016: (e, t, n) => {
            "use strict";
            var r = n(4867);
            e.exports = function (e, t) {
                r.forEach(e, (function (n, r) {
                    r !== t && r.toUpperCase() === t.toUpperCase() && (e[t] = n, delete e[r])
                }))
            }
        }, 4109: (e, t, n) => {
            "use strict";
            var r = n(4867),
                i = ["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"];
            e.exports = function (e) {
                var t, n, o, a = {};
                return e ? (r.forEach(e.split("\n"), (function (e) {
                    if (o = e.indexOf(":"), t = r.trim(e.substr(0, o)).toLowerCase(), n = r.trim(e.substr(o + 1)), t) {
                        if (a[t] && i.indexOf(t) >= 0) return;
                        a[t] = "set-cookie" === t ? (a[t] ? a[t] : []).concat([n]) : a[t] ? a[t] + ", " + n : n
                    }
                })), a) : a
            }
        }, 8713: e => {
            "use strict";
            e.exports = function (e) {
                return function (t) {
                    return e.apply(null, t)
                }
            }
        }, 4875: (e, t, n) => {
            "use strict";
            var r = n(8593), i = {};
            ["object", "boolean", "number", "function", "string", "symbol"].forEach((function (e, t) {
                i[e] = function (n) {
                    return typeof n === e || "a" + (t < 1 ? "n " : " ") + e
                }
            }));
            var o = {}, a = r.version.split(".");

            function s(e, t) {
                for (var n = t ? t.split(".") : a, r = e.split("."), i = 0; i < 3; i++) {
                    if (n[i] > r[i]) return !0;
                    if (n[i] < r[i]) return !1
                }
                return !1
            }

            i.transitional = function (e, t, n) {
                var i = t && s(t);

                function a(e, t) {
                    return "[Axios v" + r.version + "] Transitional option '" + e + "'" + t + (n ? ". " + n : "")
                }

                return function (n, r, s) {
                    if (!1 === e) throw new Error(a(r, " has been removed in " + t));
                    return i && !o[r] && (o[r] = !0, console.warn(a(r, " has been deprecated since v" + t + " and will be removed in the near future"))), !e || e(n, r, s)
                }
            }, e.exports = {
                isOlderVersion: s, assertOptions: function (e, t, n) {
                    if ("object" != typeof e) throw new TypeError("options must be an object");
                    for (var r = Object.keys(e), i = r.length; i-- > 0;) {
                        var o = r[i], a = t[o];
                        if (a) {
                            var s = e[o], u = void 0 === s || a(s, o, e);
                            if (!0 !== u) throw new TypeError("option " + o + " must be " + u)
                        } else if (!0 !== n) throw Error("Unknown option " + o)
                    }
                }, validators: i
            }
        }, 4867: (e, t, n) => {
            "use strict";
            var r = n(1849), i = Object.prototype.toString;

            function o(e) {
                return "[object Array]" === i.call(e)
            }

            function a(e) {
                return void 0 === e
            }

            function s(e) {
                return null !== e && "object" == typeof e
            }

            function u(e) {
                if ("[object Object]" !== i.call(e)) return !1;
                var t = Object.getPrototypeOf(e);
                return null === t || t === Object.prototype
            }

            function l(e) {
                return "[object Function]" === i.call(e)
            }

            function c(e, t) {
                if (null != e) if ("object" != typeof e && (e = [e]), o(e)) for (var n = 0, r = e.length; n < r; n++) t.call(null, e[n], n, e); else for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && t.call(null, e[i], i, e)
            }

            e.exports = {
                isArray: o, isArrayBuffer: function (e) {
                    return "[object ArrayBuffer]" === i.call(e)
                }, isBuffer: function (e) {
                    return null !== e && !a(e) && null !== e.constructor && !a(e.constructor) && "function" == typeof e.constructor.isBuffer && e.constructor.isBuffer(e)
                }, isFormData: function (e) {
                    return "undefined" != typeof FormData && e instanceof FormData
                }, isArrayBufferView: function (e) {
                    return "undefined" != typeof ArrayBuffer && ArrayBuffer.isView ? ArrayBuffer.isView(e) : e && e.buffer && e.buffer instanceof ArrayBuffer
                }, isString: function (e) {
                    return "string" == typeof e
                }, isNumber: function (e) {
                    return "number" == typeof e
                }, isObject: s, isPlainObject: u, isUndefined: a, isDate: function (e) {
                    return "[object Date]" === i.call(e)
                }, isFile: function (e) {
                    return "[object File]" === i.call(e)
                }, isBlob: function (e) {
                    return "[object Blob]" === i.call(e)
                }, isFunction: l, isStream: function (e) {
                    return s(e) && l(e.pipe)
                }, isURLSearchParams: function (e) {
                    return "undefined" != typeof URLSearchParams && e instanceof URLSearchParams
                }, isStandardBrowserEnv: function () {
                    return ("undefined" == typeof navigator || "ReactNative" !== navigator.product && "NativeScript" !== navigator.product && "NS" !== navigator.product) && "undefined" != typeof window && "undefined" != typeof document
                }, forEach: c, merge: function e() {
                    var t = {};

                    function n(n, r) {
                        u(t[r]) && u(n) ? t[r] = e(t[r], n) : u(n) ? t[r] = e({}, n) : o(n) ? t[r] = n.slice() : t[r] = n
                    }

                    for (var r = 0, i = arguments.length; r < i; r++) c(arguments[r], n);
                    return t
                }, extend: function (e, t, n) {
                    return c(t, (function (t, i) {
                        e[i] = n && "function" == typeof t ? r(t, n) : t
                    })), e
                }, trim: function (e) {
                    return e.trim ? e.trim() : e.replace(/^\s+|\s+$/g, "")
                }, stripBOM: function (e) {
                    return 65279 === e.charCodeAt(0) && (e = e.slice(1)), e
                }
            }
        }, 9755: function (e, t) {
            var n;
            !function (t, n) {
                "use strict";
                "object" == typeof e.exports ? e.exports = t.document ? n(t, !0) : function (e) {
                    if (!e.document) throw new Error("jQuery requires a window with a document");
                    return n(e)
                } : n(t)
            }("undefined" != typeof window ? window : this, (function (r, i) {
                "use strict";
                var o = [], a = Object.getPrototypeOf, s = o.slice, u = o.flat ? function (e) {
                        return o.flat.call(e)
                    } : function (e) {
                        return o.concat.apply([], e)
                    }, l = o.push, c = o.indexOf, d = {}, f = d.toString, h = d.hasOwnProperty, p = h.toString,
                    m = p.call(Object), g = {}, y = function (e) {
                        return "function" == typeof e && "number" != typeof e.nodeType && "function" != typeof e.item
                    }, v = function (e) {
                        return null != e && e === e.window
                    }, w = r.document, _ = {type: !0, src: !0, nonce: !0, noModule: !0};

                function b(e, t, n) {
                    var r, i, o = (n = n || w).createElement("script");
                    if (o.text = e, t) for (r in _) (i = t[r] || t.getAttribute && t.getAttribute(r)) && o.setAttribute(r, i);
                    n.head.appendChild(o).parentNode.removeChild(o)
                }

                function x(e) {
                    return null == e ? e + "" : "object" == typeof e || "function" == typeof e ? d[f.call(e)] || "object" : typeof e
                }

                var k = "3.6.4", S = function (e, t) {
                    return new S.fn.init(e, t)
                };

                function T(e) {
                    var t = !!e && "length" in e && e.length, n = x(e);
                    return !y(e) && !v(e) && ("array" === n || 0 === t || "number" == typeof t && t > 0 && t - 1 in e)
                }

                S.fn = S.prototype = {
                    jquery: k, constructor: S, length: 0, toArray: function () {
                        return s.call(this)
                    }, get: function (e) {
                        return null == e ? s.call(this) : e < 0 ? this[e + this.length] : this[e]
                    }, pushStack: function (e) {
                        var t = S.merge(this.constructor(), e);
                        return t.prevObject = this, t
                    }, each: function (e) {
                        return S.each(this, e)
                    }, map: function (e) {
                        return this.pushStack(S.map(this, (function (t, n) {
                            return e.call(t, n, t)
                        })))
                    }, slice: function () {
                        return this.pushStack(s.apply(this, arguments))
                    }, first: function () {
                        return this.eq(0)
                    }, last: function () {
                        return this.eq(-1)
                    }, even: function () {
                        return this.pushStack(S.grep(this, (function (e, t) {
                            return (t + 1) % 2
                        })))
                    }, odd: function () {
                        return this.pushStack(S.grep(this, (function (e, t) {
                            return t % 2
                        })))
                    }, eq: function (e) {
                        var t = this.length, n = +e + (e < 0 ? t : 0);
                        return this.pushStack(n >= 0 && n < t ? [this[n]] : [])
                    }, end: function () {
                        return this.prevObject || this.constructor()
                    }, push: l, sort: o.sort, splice: o.splice
                }, S.extend = S.fn.extend = function () {
                    var e, t, n, r, i, o, a = arguments[0] || {}, s = 1, u = arguments.length, l = !1;
                    for ("boolean" == typeof a && (l = a, a = arguments[s] || {}, s++), "object" == typeof a || y(a) || (a = {}), s === u && (a = this, s--); s < u; s++) if (null != (e = arguments[s])) for (t in e) r = e[t], "__proto__" !== t && a !== r && (l && r && (S.isPlainObject(r) || (i = Array.isArray(r))) ? (n = a[t], o = i && !Array.isArray(n) ? [] : i || S.isPlainObject(n) ? n : {}, i = !1, a[t] = S.extend(l, o, r)) : void 0 !== r && (a[t] = r));
                    return a
                }, S.extend({
                    expando: "jQuery" + (k + Math.random()).replace(/\D/g, ""), isReady: !0, error: function (e) {
                        throw new Error(e)
                    }, noop: function () {
                    }, isPlainObject: function (e) {
                        var t, n;
                        return !(!e || "[object Object]" !== f.call(e) || (t = a(e)) && ("function" != typeof (n = h.call(t, "constructor") && t.constructor) || p.call(n) !== m))
                    }, isEmptyObject: function (e) {
                        var t;
                        for (t in e) return !1;
                        return !0
                    }, globalEval: function (e, t, n) {
                        b(e, {nonce: t && t.nonce}, n)
                    }, each: function (e, t) {
                        var n, r = 0;
                        if (T(e)) for (n = e.length; r < n && !1 !== t.call(e[r], r, e[r]); r++) ; else for (r in e) if (!1 === t.call(e[r], r, e[r])) break;
                        return e
                    }, makeArray: function (e, t) {
                        var n = t || [];
                        return null != e && (T(Object(e)) ? S.merge(n, "string" == typeof e ? [e] : e) : l.call(n, e)), n
                    }, inArray: function (e, t, n) {
                        return null == t ? -1 : c.call(t, e, n)
                    }, merge: function (e, t) {
                        for (var n = +t.length, r = 0, i = e.length; r < n; r++) e[i++] = t[r];
                        return e.length = i, e
                    }, grep: function (e, t, n) {
                        for (var r = [], i = 0, o = e.length, a = !n; i < o; i++) !t(e[i], i) !== a && r.push(e[i]);
                        return r
                    }, map: function (e, t, n) {
                        var r, i, o = 0, a = [];
                        if (T(e)) for (r = e.length; o < r; o++) null != (i = t(e[o], o, n)) && a.push(i); else for (o in e) null != (i = t(e[o], o, n)) && a.push(i);
                        return u(a)
                    }, guid: 1, support: g
                }), "function" == typeof Symbol && (S.fn[Symbol.iterator] = o[Symbol.iterator]), S.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), (function (e, t) {
                    d["[object " + t + "]"] = t.toLowerCase()
                }));
                var D = function (e) {
                    var t, n, r, i, o, a, s, u, l, c, d, f, h, p, m, g, y, v, w, _ = "sizzle" + 1 * new Date,
                        b = e.document, x = 0, k = 0, S = ue(), T = ue(), D = ue(), C = ue(), M = function (e, t) {
                            return e === t && (d = !0), 0
                        }, N = {}.hasOwnProperty, O = [], E = O.pop, A = O.push, j = O.push, P = O.slice,
                        R = function (e, t) {
                            for (var n = 0, r = e.length; n < r; n++) if (e[n] === t) return n;
                            return -1
                        },
                        Y = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
                        L = "[\\x20\\t\\r\\n\\f]",
                        I = "(?:\\\\[\\da-fA-F]{1,6}" + L + "?|\\\\[^\\r\\n\\f]|[\\w-]|[^\0-\\x7f])+",
                        H = "\\[" + L + "*(" + I + ")(?:" + L + "*([*^$|!~]?=)" + L + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + I + "))|)" + L + "*\\]",
                        F = ":(" + I + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + H + ")*)|.*)\\)|)",
                        U = new RegExp(L + "+", "g"),
                        W = new RegExp("^" + L + "+|((?:^|[^\\\\])(?:\\\\.)*)" + L + "+$", "g"),
                        q = new RegExp("^" + L + "*," + L + "*"),
                        B = new RegExp("^" + L + "*([>+~]|" + L + ")" + L + "*"), G = new RegExp(L + "|>"),
                        V = new RegExp(F), $ = new RegExp("^" + I + "$"), z = {
                            ID: new RegExp("^#(" + I + ")"),
                            CLASS: new RegExp("^\\.(" + I + ")"),
                            TAG: new RegExp("^(" + I + "|[*])"),
                            ATTR: new RegExp("^" + H),
                            PSEUDO: new RegExp("^" + F),
                            CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + L + "*(even|odd|(([+-]|)(\\d*)n|)" + L + "*(?:([+-]|)" + L + "*(\\d+)|))" + L + "*\\)|)", "i"),
                            bool: new RegExp("^(?:" + Y + ")$", "i"),
                            needsContext: new RegExp("^" + L + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + L + "*((?:-\\d)?\\d*)" + L + "*\\)|)(?=[^-]|$)", "i")
                        }, J = /HTML$/i, Z = /^(?:input|select|textarea|button)$/i, X = /^h\d$/i,
                        Q = /^[^{]+\{\s*\[native \w/, K = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/, ee = /[+~]/,
                        te = new RegExp("\\\\[\\da-fA-F]{1,6}" + L + "?|\\\\([^\\r\\n\\f])", "g"),
                        ne = function (e, t) {
                            var n = "0x" + e.slice(1) - 65536;
                            return t || (n < 0 ? String.fromCharCode(n + 65536) : String.fromCharCode(n >> 10 | 55296, 1023 & n | 56320))
                        }, re = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g, ie = function (e, t) {
                            return t ? "\0" === e ? "�" : e.slice(0, -1) + "\\" + e.charCodeAt(e.length - 1).toString(16) + " " : "\\" + e
                        }, oe = function () {
                            f()
                        }, ae = _e((function (e) {
                            return !0 === e.disabled && "fieldset" === e.nodeName.toLowerCase()
                        }), {dir: "parentNode", next: "legend"});
                    try {
                        j.apply(O = P.call(b.childNodes), b.childNodes), O[b.childNodes.length].nodeType
                    } catch (e) {
                        j = {
                            apply: O.length ? function (e, t) {
                                A.apply(e, P.call(t))
                            } : function (e, t) {
                                for (var n = e.length, r = 0; e[n++] = t[r++];) ;
                                e.length = n - 1
                            }
                        }
                    }

                    function se(e, t, r, i) {
                        var o, s, l, c, d, p, y, v = t && t.ownerDocument, b = t ? t.nodeType : 9;
                        if (r = r || [], "string" != typeof e || !e || 1 !== b && 9 !== b && 11 !== b) return r;
                        if (!i && (f(t), t = t || h, m)) {
                            if (11 !== b && (d = K.exec(e))) if (o = d[1]) {
                                if (9 === b) {
                                    if (!(l = t.getElementById(o))) return r;
                                    if (l.id === o) return r.push(l), r
                                } else if (v && (l = v.getElementById(o)) && w(t, l) && l.id === o) return r.push(l), r
                            } else {
                                if (d[2]) return j.apply(r, t.getElementsByTagName(e)), r;
                                if ((o = d[3]) && n.getElementsByClassName && t.getElementsByClassName) return j.apply(r, t.getElementsByClassName(o)), r
                            }
                            if (n.qsa && !C[e + " "] && (!g || !g.test(e)) && (1 !== b || "object" !== t.nodeName.toLowerCase())) {
                                if (y = e, v = t, 1 === b && (G.test(e) || B.test(e))) {
                                    for ((v = ee.test(e) && ye(t.parentNode) || t) === t && n.scope || ((c = t.getAttribute("id")) ? c = c.replace(re, ie) : t.setAttribute("id", c = _)), s = (p = a(e)).length; s--;) p[s] = (c ? "#" + c : ":scope") + " " + we(p[s]);
                                    y = p.join(",")
                                }
                                try {
                                    return j.apply(r, v.querySelectorAll(y)), r
                                } catch (t) {
                                    C(e, !0)
                                } finally {
                                    c === _ && t.removeAttribute("id")
                                }
                            }
                        }
                        return u(e.replace(W, "$1"), t, r, i)
                    }

                    function ue() {
                        var e = [];
                        return function t(n, i) {
                            return e.push(n + " ") > r.cacheLength && delete t[e.shift()], t[n + " "] = i
                        }
                    }

                    function le(e) {
                        return e[_] = !0, e
                    }

                    function ce(e) {
                        var t = h.createElement("fieldset");
                        try {
                            return !!e(t)
                        } catch (e) {
                            return !1
                        } finally {
                            t.parentNode && t.parentNode.removeChild(t), t = null
                        }
                    }

                    function de(e, t) {
                        for (var n = e.split("|"), i = n.length; i--;) r.attrHandle[n[i]] = t
                    }

                    function fe(e, t) {
                        var n = t && e, r = n && 1 === e.nodeType && 1 === t.nodeType && e.sourceIndex - t.sourceIndex;
                        if (r) return r;
                        if (n) for (; n = n.nextSibling;) if (n === t) return -1;
                        return e ? 1 : -1
                    }

                    function he(e) {
                        return function (t) {
                            return "input" === t.nodeName.toLowerCase() && t.type === e
                        }
                    }

                    function pe(e) {
                        return function (t) {
                            var n = t.nodeName.toLowerCase();
                            return ("input" === n || "button" === n) && t.type === e
                        }
                    }

                    function me(e) {
                        return function (t) {
                            return "form" in t ? t.parentNode && !1 === t.disabled ? "label" in t ? "label" in t.parentNode ? t.parentNode.disabled === e : t.disabled === e : t.isDisabled === e || t.isDisabled !== !e && ae(t) === e : t.disabled === e : "label" in t && t.disabled === e
                        }
                    }

                    function ge(e) {
                        return le((function (t) {
                            return t = +t, le((function (n, r) {
                                for (var i, o = e([], n.length, t), a = o.length; a--;) n[i = o[a]] && (n[i] = !(r[i] = n[i]))
                            }))
                        }))
                    }

                    function ye(e) {
                        return e && void 0 !== e.getElementsByTagName && e
                    }

                    for (t in n = se.support = {}, o = se.isXML = function (e) {
                        var t = e && e.namespaceURI, n = e && (e.ownerDocument || e).documentElement;
                        return !J.test(t || n && n.nodeName || "HTML")
                    }, f = se.setDocument = function (e) {
                        var t, i, a = e ? e.ownerDocument || e : b;
                        return a != h && 9 === a.nodeType && a.documentElement ? (p = (h = a).documentElement, m = !o(h), b != h && (i = h.defaultView) && i.top !== i && (i.addEventListener ? i.addEventListener("unload", oe, !1) : i.attachEvent && i.attachEvent("onunload", oe)), n.scope = ce((function (e) {
                            return p.appendChild(e).appendChild(h.createElement("div")), void 0 !== e.querySelectorAll && !e.querySelectorAll(":scope fieldset div").length
                        })), n.cssHas = ce((function () {
                            try {
                                return h.querySelector(":has(*,:jqfake)"), !1
                            } catch (e) {
                                return !0
                            }
                        })), n.attributes = ce((function (e) {
                            return e.className = "i", !e.getAttribute("className")
                        })), n.getElementsByTagName = ce((function (e) {
                            return e.appendChild(h.createComment("")), !e.getElementsByTagName("*").length
                        })), n.getElementsByClassName = Q.test(h.getElementsByClassName), n.getById = ce((function (e) {
                            return p.appendChild(e).id = _, !h.getElementsByName || !h.getElementsByName(_).length
                        })), n.getById ? (r.filter.ID = function (e) {
                            var t = e.replace(te, ne);
                            return function (e) {
                                return e.getAttribute("id") === t
                            }
                        }, r.find.ID = function (e, t) {
                            if (void 0 !== t.getElementById && m) {
                                var n = t.getElementById(e);
                                return n ? [n] : []
                            }
                        }) : (r.filter.ID = function (e) {
                            var t = e.replace(te, ne);
                            return function (e) {
                                var n = void 0 !== e.getAttributeNode && e.getAttributeNode("id");
                                return n && n.value === t
                            }
                        }, r.find.ID = function (e, t) {
                            if (void 0 !== t.getElementById && m) {
                                var n, r, i, o = t.getElementById(e);
                                if (o) {
                                    if ((n = o.getAttributeNode("id")) && n.value === e) return [o];
                                    for (i = t.getElementsByName(e), r = 0; o = i[r++];) if ((n = o.getAttributeNode("id")) && n.value === e) return [o]
                                }
                                return []
                            }
                        }), r.find.TAG = n.getElementsByTagName ? function (e, t) {
                            return void 0 !== t.getElementsByTagName ? t.getElementsByTagName(e) : n.qsa ? t.querySelectorAll(e) : void 0
                        } : function (e, t) {
                            var n, r = [], i = 0, o = t.getElementsByTagName(e);
                            if ("*" === e) {
                                for (; n = o[i++];) 1 === n.nodeType && r.push(n);
                                return r
                            }
                            return o
                        }, r.find.CLASS = n.getElementsByClassName && function (e, t) {
                            if (void 0 !== t.getElementsByClassName && m) return t.getElementsByClassName(e)
                        }, y = [], g = [], (n.qsa = Q.test(h.querySelectorAll)) && (ce((function (e) {
                            var t;
                            p.appendChild(e).innerHTML = "<a id='" + _ + "'></a><select id='" + _ + "-\r\\' msallowcapture=''><option selected=''></option></select>", e.querySelectorAll("[msallowcapture^='']").length && g.push("[*^$]=" + L + "*(?:''|\"\")"), e.querySelectorAll("[selected]").length || g.push("\\[" + L + "*(?:value|" + Y + ")"), e.querySelectorAll("[id~=" + _ + "-]").length || g.push("~="), (t = h.createElement("input")).setAttribute("name", ""), e.appendChild(t), e.querySelectorAll("[name='']").length || g.push("\\[" + L + "*name" + L + "*=" + L + "*(?:''|\"\")"), e.querySelectorAll(":checked").length || g.push(":checked"), e.querySelectorAll("a#" + _ + "+*").length || g.push(".#.+[+~]"), e.querySelectorAll("\\\f"), g.push("[\\r\\n\\f]")
                        })), ce((function (e) {
                            e.innerHTML = "<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
                            var t = h.createElement("input");
                            t.setAttribute("type", "hidden"), e.appendChild(t).setAttribute("name", "D"), e.querySelectorAll("[name=d]").length && g.push("name" + L + "*[*^$|!~]?="), 2 !== e.querySelectorAll(":enabled").length && g.push(":enabled", ":disabled"), p.appendChild(e).disabled = !0, 2 !== e.querySelectorAll(":disabled").length && g.push(":enabled", ":disabled"), e.querySelectorAll("*,:x"), g.push(",.*:")
                        }))), (n.matchesSelector = Q.test(v = p.matches || p.webkitMatchesSelector || p.mozMatchesSelector || p.oMatchesSelector || p.msMatchesSelector)) && ce((function (e) {
                            n.disconnectedMatch = v.call(e, "*"), v.call(e, "[s!='']:x"), y.push("!=", F)
                        })), n.cssHas || g.push(":has"), g = g.length && new RegExp(g.join("|")), y = y.length && new RegExp(y.join("|")), t = Q.test(p.compareDocumentPosition), w = t || Q.test(p.contains) ? function (e, t) {
                            var n = 9 === e.nodeType && e.documentElement || e, r = t && t.parentNode;
                            return e === r || !(!r || 1 !== r.nodeType || !(n.contains ? n.contains(r) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(r)))
                        } : function (e, t) {
                            if (t) for (; t = t.parentNode;) if (t === e) return !0;
                            return !1
                        }, M = t ? function (e, t) {
                            if (e === t) return d = !0, 0;
                            var r = !e.compareDocumentPosition - !t.compareDocumentPosition;
                            return r || (1 & (r = (e.ownerDocument || e) == (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1) || !n.sortDetached && t.compareDocumentPosition(e) === r ? e == h || e.ownerDocument == b && w(b, e) ? -1 : t == h || t.ownerDocument == b && w(b, t) ? 1 : c ? R(c, e) - R(c, t) : 0 : 4 & r ? -1 : 1)
                        } : function (e, t) {
                            if (e === t) return d = !0, 0;
                            var n, r = 0, i = e.parentNode, o = t.parentNode, a = [e], s = [t];
                            if (!i || !o) return e == h ? -1 : t == h ? 1 : i ? -1 : o ? 1 : c ? R(c, e) - R(c, t) : 0;
                            if (i === o) return fe(e, t);
                            for (n = e; n = n.parentNode;) a.unshift(n);
                            for (n = t; n = n.parentNode;) s.unshift(n);
                            for (; a[r] === s[r];) r++;
                            return r ? fe(a[r], s[r]) : a[r] == b ? -1 : s[r] == b ? 1 : 0
                        }, h) : h
                    }, se.matches = function (e, t) {
                        return se(e, null, null, t)
                    }, se.matchesSelector = function (e, t) {
                        if (f(e), n.matchesSelector && m && !C[t + " "] && (!y || !y.test(t)) && (!g || !g.test(t))) try {
                            var r = v.call(e, t);
                            if (r || n.disconnectedMatch || e.document && 11 !== e.document.nodeType) return r
                        } catch (e) {
                            C(t, !0)
                        }
                        return se(t, h, null, [e]).length > 0
                    }, se.contains = function (e, t) {
                        return (e.ownerDocument || e) != h && f(e), w(e, t)
                    }, se.attr = function (e, t) {
                        (e.ownerDocument || e) != h && f(e);
                        var i = r.attrHandle[t.toLowerCase()],
                            o = i && N.call(r.attrHandle, t.toLowerCase()) ? i(e, t, !m) : void 0;
                        return void 0 !== o ? o : n.attributes || !m ? e.getAttribute(t) : (o = e.getAttributeNode(t)) && o.specified ? o.value : null
                    }, se.escape = function (e) {
                        return (e + "").replace(re, ie)
                    }, se.error = function (e) {
                        throw new Error("Syntax error, unrecognized expression: " + e)
                    }, se.uniqueSort = function (e) {
                        var t, r = [], i = 0, o = 0;
                        if (d = !n.detectDuplicates, c = !n.sortStable && e.slice(0), e.sort(M), d) {
                            for (; t = e[o++];) t === e[o] && (i = r.push(o));
                            for (; i--;) e.splice(r[i], 1)
                        }
                        return c = null, e
                    }, i = se.getText = function (e) {
                        var t, n = "", r = 0, o = e.nodeType;
                        if (o) {
                            if (1 === o || 9 === o || 11 === o) {
                                if ("string" == typeof e.textContent) return e.textContent;
                                for (e = e.firstChild; e; e = e.nextSibling) n += i(e)
                            } else if (3 === o || 4 === o) return e.nodeValue
                        } else for (; t = e[r++];) n += i(t);
                        return n
                    }, r = se.selectors = {
                        cacheLength: 50,
                        createPseudo: le,
                        match: z,
                        attrHandle: {},
                        find: {},
                        relative: {
                            ">": {dir: "parentNode", first: !0},
                            " ": {dir: "parentNode"},
                            "+": {dir: "previousSibling", first: !0},
                            "~": {dir: "previousSibling"}
                        },
                        preFilter: {
                            ATTR: function (e) {
                                return e[1] = e[1].replace(te, ne), e[3] = (e[3] || e[4] || e[5] || "").replace(te, ne), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4)
                            }, CHILD: function (e) {
                                return e[1] = e[1].toLowerCase(), "nth" === e[1].slice(0, 3) ? (e[3] || se.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && se.error(e[0]), e
                            }, PSEUDO: function (e) {
                                var t, n = !e[6] && e[2];
                                return z.CHILD.test(e[0]) ? null : (e[3] ? e[2] = e[4] || e[5] || "" : n && V.test(n) && (t = a(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
                            }
                        },
                        filter: {
                            TAG: function (e) {
                                var t = e.replace(te, ne).toLowerCase();
                                return "*" === e ? function () {
                                    return !0
                                } : function (e) {
                                    return e.nodeName && e.nodeName.toLowerCase() === t
                                }
                            }, CLASS: function (e) {
                                var t = S[e + " "];
                                return t || (t = new RegExp("(^|" + L + ")" + e + "(" + L + "|$)")) && S(e, (function (e) {
                                    return t.test("string" == typeof e.className && e.className || void 0 !== e.getAttribute && e.getAttribute("class") || "")
                                }))
                            }, ATTR: function (e, t, n) {
                                return function (r) {
                                    var i = se.attr(r, e);
                                    return null == i ? "!=" === t : !t || (i += "", "=" === t ? i === n : "!=" === t ? i !== n : "^=" === t ? n && 0 === i.indexOf(n) : "*=" === t ? n && i.indexOf(n) > -1 : "$=" === t ? n && i.slice(-n.length) === n : "~=" === t ? (" " + i.replace(U, " ") + " ").indexOf(n) > -1 : "|=" === t && (i === n || i.slice(0, n.length + 1) === n + "-"))
                                }
                            }, CHILD: function (e, t, n, r, i) {
                                var o = "nth" !== e.slice(0, 3), a = "last" !== e.slice(-4), s = "of-type" === t;
                                return 1 === r && 0 === i ? function (e) {
                                    return !!e.parentNode
                                } : function (t, n, u) {
                                    var l, c, d, f, h, p, m = o !== a ? "nextSibling" : "previousSibling",
                                        g = t.parentNode, y = s && t.nodeName.toLowerCase(), v = !u && !s, w = !1;
                                    if (g) {
                                        if (o) {
                                            for (; m;) {
                                                for (f = t; f = f[m];) if (s ? f.nodeName.toLowerCase() === y : 1 === f.nodeType) return !1;
                                                p = m = "only" === e && !p && "nextSibling"
                                            }
                                            return !0
                                        }
                                        if (p = [a ? g.firstChild : g.lastChild], a && v) {
                                            for (w = (h = (l = (c = (d = (f = g)[_] || (f[_] = {}))[f.uniqueID] || (d[f.uniqueID] = {}))[e] || [])[0] === x && l[1]) && l[2], f = h && g.childNodes[h]; f = ++h && f && f[m] || (w = h = 0) || p.pop();) if (1 === f.nodeType && ++w && f === t) {
                                                c[e] = [x, h, w];
                                                break
                                            }
                                        } else if (v && (w = h = (l = (c = (d = (f = t)[_] || (f[_] = {}))[f.uniqueID] || (d[f.uniqueID] = {}))[e] || [])[0] === x && l[1]), !1 === w) for (; (f = ++h && f && f[m] || (w = h = 0) || p.pop()) && ((s ? f.nodeName.toLowerCase() !== y : 1 !== f.nodeType) || !++w || (v && ((c = (d = f[_] || (f[_] = {}))[f.uniqueID] || (d[f.uniqueID] = {}))[e] = [x, w]), f !== t));) ;
                                        return (w -= i) === r || w % r == 0 && w / r >= 0
                                    }
                                }
                            }, PSEUDO: function (e, t) {
                                var n,
                                    i = r.pseudos[e] || r.setFilters[e.toLowerCase()] || se.error("unsupported pseudo: " + e);
                                return i[_] ? i(t) : i.length > 1 ? (n = [e, e, "", t], r.setFilters.hasOwnProperty(e.toLowerCase()) ? le((function (e, n) {
                                    for (var r, o = i(e, t), a = o.length; a--;) e[r = R(e, o[a])] = !(n[r] = o[a])
                                })) : function (e) {
                                    return i(e, 0, n)
                                }) : i
                            }
                        },
                        pseudos: {
                            not: le((function (e) {
                                var t = [], n = [], r = s(e.replace(W, "$1"));
                                return r[_] ? le((function (e, t, n, i) {
                                    for (var o, a = r(e, null, i, []), s = e.length; s--;) (o = a[s]) && (e[s] = !(t[s] = o))
                                })) : function (e, i, o) {
                                    return t[0] = e, r(t, null, o, n), t[0] = null, !n.pop()
                                }
                            })), has: le((function (e) {
                                return function (t) {
                                    return se(e, t).length > 0
                                }
                            })), contains: le((function (e) {
                                return e = e.replace(te, ne), function (t) {
                                    return (t.textContent || i(t)).indexOf(e) > -1
                                }
                            })), lang: le((function (e) {
                                return $.test(e || "") || se.error("unsupported lang: " + e), e = e.replace(te, ne).toLowerCase(), function (t) {
                                    var n;
                                    do {
                                        if (n = m ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang")) return (n = n.toLowerCase()) === e || 0 === n.indexOf(e + "-")
                                    } while ((t = t.parentNode) && 1 === t.nodeType);
                                    return !1
                                }
                            })), target: function (t) {
                                var n = e.location && e.location.hash;
                                return n && n.slice(1) === t.id
                            }, root: function (e) {
                                return e === p
                            }, focus: function (e) {
                                return e === h.activeElement && (!h.hasFocus || h.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
                            }, enabled: me(!1), disabled: me(!0), checked: function (e) {
                                var t = e.nodeName.toLowerCase();
                                return "input" === t && !!e.checked || "option" === t && !!e.selected
                            }, selected: function (e) {
                                return e.parentNode && e.parentNode.selectedIndex, !0 === e.selected
                            }, empty: function (e) {
                                for (e = e.firstChild; e; e = e.nextSibling) if (e.nodeType < 6) return !1;
                                return !0
                            }, parent: function (e) {
                                return !r.pseudos.empty(e)
                            }, header: function (e) {
                                return X.test(e.nodeName)
                            }, input: function (e) {
                                return Z.test(e.nodeName)
                            }, button: function (e) {
                                var t = e.nodeName.toLowerCase();
                                return "input" === t && "button" === e.type || "button" === t
                            }, text: function (e) {
                                var t;
                                return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase())
                            }, first: ge((function () {
                                return [0]
                            })), last: ge((function (e, t) {
                                return [t - 1]
                            })), eq: ge((function (e, t, n) {
                                return [n < 0 ? n + t : n]
                            })), even: ge((function (e, t) {
                                for (var n = 0; n < t; n += 2) e.push(n);
                                return e
                            })), odd: ge((function (e, t) {
                                for (var n = 1; n < t; n += 2) e.push(n);
                                return e
                            })), lt: ge((function (e, t, n) {
                                for (var r = n < 0 ? n + t : n > t ? t : n; --r >= 0;) e.push(r);
                                return e
                            })), gt: ge((function (e, t, n) {
                                for (var r = n < 0 ? n + t : n; ++r < t;) e.push(r);
                                return e
                            }))
                        }
                    }, r.pseudos.nth = r.pseudos.eq, {
                        radio: !0,
                        checkbox: !0,
                        file: !0,
                        password: !0,
                        image: !0
                    }) r.pseudos[t] = he(t);
                    for (t in {submit: !0, reset: !0}) r.pseudos[t] = pe(t);

                    function ve() {
                    }

                    function we(e) {
                        for (var t = 0, n = e.length, r = ""; t < n; t++) r += e[t].value;
                        return r
                    }

                    function _e(e, t, n) {
                        var r = t.dir, i = t.next, o = i || r, a = n && "parentNode" === o, s = k++;
                        return t.first ? function (t, n, i) {
                            for (; t = t[r];) if (1 === t.nodeType || a) return e(t, n, i);
                            return !1
                        } : function (t, n, u) {
                            var l, c, d, f = [x, s];
                            if (u) {
                                for (; t = t[r];) if ((1 === t.nodeType || a) && e(t, n, u)) return !0
                            } else for (; t = t[r];) if (1 === t.nodeType || a) if (c = (d = t[_] || (t[_] = {}))[t.uniqueID] || (d[t.uniqueID] = {}), i && i === t.nodeName.toLowerCase()) t = t[r] || t; else {
                                if ((l = c[o]) && l[0] === x && l[1] === s) return f[2] = l[2];
                                if (c[o] = f, f[2] = e(t, n, u)) return !0
                            }
                            return !1
                        }
                    }

                    function be(e) {
                        return e.length > 1 ? function (t, n, r) {
                            for (var i = e.length; i--;) if (!e[i](t, n, r)) return !1;
                            return !0
                        } : e[0]
                    }

                    function xe(e, t, n, r, i) {
                        for (var o, a = [], s = 0, u = e.length, l = null != t; s < u; s++) (o = e[s]) && (n && !n(o, r, i) || (a.push(o), l && t.push(s)));
                        return a
                    }

                    function ke(e, t, n, r, i, o) {
                        return r && !r[_] && (r = ke(r)), i && !i[_] && (i = ke(i, o)), le((function (o, a, s, u) {
                            var l, c, d, f = [], h = [], p = a.length, m = o || function (e, t, n) {
                                    for (var r = 0, i = t.length; r < i; r++) se(e, t[r], n);
                                    return n
                                }(t || "*", s.nodeType ? [s] : s, []), g = !e || !o && t ? m : xe(m, f, e, s, u),
                                y = n ? i || (o ? e : p || r) ? [] : a : g;
                            if (n && n(g, y, s, u), r) for (l = xe(y, h), r(l, [], s, u), c = l.length; c--;) (d = l[c]) && (y[h[c]] = !(g[h[c]] = d));
                            if (o) {
                                if (i || e) {
                                    if (i) {
                                        for (l = [], c = y.length; c--;) (d = y[c]) && l.push(g[c] = d);
                                        i(null, y = [], l, u)
                                    }
                                    for (c = y.length; c--;) (d = y[c]) && (l = i ? R(o, d) : f[c]) > -1 && (o[l] = !(a[l] = d))
                                }
                            } else y = xe(y === a ? y.splice(p, y.length) : y), i ? i(null, a, y, u) : j.apply(a, y)
                        }))
                    }

                    function Se(e) {
                        for (var t, n, i, o = e.length, a = r.relative[e[0].type], s = a || r.relative[" "], u = a ? 1 : 0, c = _e((function (e) {
                            return e === t
                        }), s, !0), d = _e((function (e) {
                            return R(t, e) > -1
                        }), s, !0), f = [function (e, n, r) {
                            var i = !a && (r || n !== l) || ((t = n).nodeType ? c(e, n, r) : d(e, n, r));
                            return t = null, i
                        }]; u < o; u++) if (n = r.relative[e[u].type]) f = [_e(be(f), n)]; else {
                            if ((n = r.filter[e[u].type].apply(null, e[u].matches))[_]) {
                                for (i = ++u; i < o && !r.relative[e[i].type]; i++) ;
                                return ke(u > 1 && be(f), u > 1 && we(e.slice(0, u - 1).concat({value: " " === e[u - 2].type ? "*" : ""})).replace(W, "$1"), n, u < i && Se(e.slice(u, i)), i < o && Se(e = e.slice(i)), i < o && we(e))
                            }
                            f.push(n)
                        }
                        return be(f)
                    }

                    return ve.prototype = r.filters = r.pseudos, r.setFilters = new ve, a = se.tokenize = function (e, t) {
                        var n, i, o, a, s, u, l, c = T[e + " "];
                        if (c) return t ? 0 : c.slice(0);
                        for (s = e, u = [], l = r.preFilter; s;) {
                            for (a in n && !(i = q.exec(s)) || (i && (s = s.slice(i[0].length) || s), u.push(o = [])), n = !1, (i = B.exec(s)) && (n = i.shift(), o.push({
                                value: n,
                                type: i[0].replace(W, " ")
                            }), s = s.slice(n.length)), r.filter) !(i = z[a].exec(s)) || l[a] && !(i = l[a](i)) || (n = i.shift(), o.push({
                                value: n,
                                type: a,
                                matches: i
                            }), s = s.slice(n.length));
                            if (!n) break
                        }
                        return t ? s.length : s ? se.error(e) : T(e, u).slice(0)
                    }, s = se.compile = function (e, t) {
                        var n, i = [], o = [], s = D[e + " "];
                        if (!s) {
                            for (t || (t = a(e)), n = t.length; n--;) (s = Se(t[n]))[_] ? i.push(s) : o.push(s);
                            s = D(e, function (e, t) {
                                var n = t.length > 0, i = e.length > 0, o = function (o, a, s, u, c) {
                                    var d, p, g, y = 0, v = "0", w = o && [], _ = [], b = l,
                                        k = o || i && r.find.TAG("*", c), S = x += null == b ? 1 : Math.random() || .1,
                                        T = k.length;
                                    for (c && (l = a == h || a || c); v !== T && null != (d = k[v]); v++) {
                                        if (i && d) {
                                            for (p = 0, a || d.ownerDocument == h || (f(d), s = !m); g = e[p++];) if (g(d, a || h, s)) {
                                                u.push(d);
                                                break
                                            }
                                            c && (x = S)
                                        }
                                        n && ((d = !g && d) && y--, o && w.push(d))
                                    }
                                    if (y += v, n && v !== y) {
                                        for (p = 0; g = t[p++];) g(w, _, a, s);
                                        if (o) {
                                            if (y > 0) for (; v--;) w[v] || _[v] || (_[v] = E.call(u));
                                            _ = xe(_)
                                        }
                                        j.apply(u, _), c && !o && _.length > 0 && y + t.length > 1 && se.uniqueSort(u)
                                    }
                                    return c && (x = S, l = b), w
                                };
                                return n ? le(o) : o
                            }(o, i)), s.selector = e
                        }
                        return s
                    }, u = se.select = function (e, t, n, i) {
                        var o, u, l, c, d, f = "function" == typeof e && e, h = !i && a(e = f.selector || e);
                        if (n = n || [], 1 === h.length) {
                            if ((u = h[0] = h[0].slice(0)).length > 2 && "ID" === (l = u[0]).type && 9 === t.nodeType && m && r.relative[u[1].type]) {
                                if (!(t = (r.find.ID(l.matches[0].replace(te, ne), t) || [])[0])) return n;
                                f && (t = t.parentNode), e = e.slice(u.shift().value.length)
                            }
                            for (o = z.needsContext.test(e) ? 0 : u.length; o-- && (l = u[o], !r.relative[c = l.type]);) if ((d = r.find[c]) && (i = d(l.matches[0].replace(te, ne), ee.test(u[0].type) && ye(t.parentNode) || t))) {
                                if (u.splice(o, 1), !(e = i.length && we(u))) return j.apply(n, i), n;
                                break
                            }
                        }
                        return (f || s(e, h))(i, t, !m, n, !t || ee.test(e) && ye(t.parentNode) || t), n
                    }, n.sortStable = _.split("").sort(M).join("") === _, n.detectDuplicates = !!d, f(), n.sortDetached = ce((function (e) {
                        return 1 & e.compareDocumentPosition(h.createElement("fieldset"))
                    })), ce((function (e) {
                        return e.innerHTML = "<a href='#'></a>", "#" === e.firstChild.getAttribute("href")
                    })) || de("type|href|height|width", (function (e, t, n) {
                        if (!n) return e.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2)
                    })), n.attributes && ce((function (e) {
                        return e.innerHTML = "<input/>", e.firstChild.setAttribute("value", ""), "" === e.firstChild.getAttribute("value")
                    })) || de("value", (function (e, t, n) {
                        if (!n && "input" === e.nodeName.toLowerCase()) return e.defaultValue
                    })), ce((function (e) {
                        return null == e.getAttribute("disabled")
                    })) || de(Y, (function (e, t, n) {
                        var r;
                        if (!n) return !0 === e[t] ? t.toLowerCase() : (r = e.getAttributeNode(t)) && r.specified ? r.value : null
                    })), se
                }(r);
                S.find = D, S.expr = D.selectors, S.expr[":"] = S.expr.pseudos, S.uniqueSort = S.unique = D.uniqueSort, S.text = D.getText, S.isXMLDoc = D.isXML, S.contains = D.contains, S.escapeSelector = D.escape;
                var C = function (e, t, n) {
                    for (var r = [], i = void 0 !== n; (e = e[t]) && 9 !== e.nodeType;) if (1 === e.nodeType) {
                        if (i && S(e).is(n)) break;
                        r.push(e)
                    }
                    return r
                }, M = function (e, t) {
                    for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
                    return n
                }, N = S.expr.match.needsContext;

                function O(e, t) {
                    return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
                }

                var E = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;

                function A(e, t, n) {
                    return y(t) ? S.grep(e, (function (e, r) {
                        return !!t.call(e, r, e) !== n
                    })) : t.nodeType ? S.grep(e, (function (e) {
                        return e === t !== n
                    })) : "string" != typeof t ? S.grep(e, (function (e) {
                        return c.call(t, e) > -1 !== n
                    })) : S.filter(t, e, n)
                }

                S.filter = function (e, t, n) {
                    var r = t[0];
                    return n && (e = ":not(" + e + ")"), 1 === t.length && 1 === r.nodeType ? S.find.matchesSelector(r, e) ? [r] : [] : S.find.matches(e, S.grep(t, (function (e) {
                        return 1 === e.nodeType
                    })))
                }, S.fn.extend({
                    find: function (e) {
                        var t, n, r = this.length, i = this;
                        if ("string" != typeof e) return this.pushStack(S(e).filter((function () {
                            for (t = 0; t < r; t++) if (S.contains(i[t], this)) return !0
                        })));
                        for (n = this.pushStack([]), t = 0; t < r; t++) S.find(e, i[t], n);
                        return r > 1 ? S.uniqueSort(n) : n
                    }, filter: function (e) {
                        return this.pushStack(A(this, e || [], !1))
                    }, not: function (e) {
                        return this.pushStack(A(this, e || [], !0))
                    }, is: function (e) {
                        return !!A(this, "string" == typeof e && N.test(e) ? S(e) : e || [], !1).length
                    }
                });
                var j, P = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/;
                (S.fn.init = function (e, t, n) {
                    var r, i;
                    if (!e) return this;
                    if (n = n || j, "string" == typeof e) {
                        if (!(r = "<" === e[0] && ">" === e[e.length - 1] && e.length >= 3 ? [null, e, null] : P.exec(e)) || !r[1] && t) return !t || t.jquery ? (t || n).find(e) : this.constructor(t).find(e);
                        if (r[1]) {
                            if (t = t instanceof S ? t[0] : t, S.merge(this, S.parseHTML(r[1], t && t.nodeType ? t.ownerDocument || t : w, !0)), E.test(r[1]) && S.isPlainObject(t)) for (r in t) y(this[r]) ? this[r](t[r]) : this.attr(r, t[r]);
                            return this
                        }
                        return (i = w.getElementById(r[2])) && (this[0] = i, this.length = 1), this
                    }
                    return e.nodeType ? (this[0] = e, this.length = 1, this) : y(e) ? void 0 !== n.ready ? n.ready(e) : e(S) : S.makeArray(e, this)
                }).prototype = S.fn, j = S(w);
                var R = /^(?:parents|prev(?:Until|All))/, Y = {children: !0, contents: !0, next: !0, prev: !0};

                function L(e, t) {
                    for (; (e = e[t]) && 1 !== e.nodeType;) ;
                    return e
                }

                S.fn.extend({
                    has: function (e) {
                        var t = S(e, this), n = t.length;
                        return this.filter((function () {
                            for (var e = 0; e < n; e++) if (S.contains(this, t[e])) return !0
                        }))
                    }, closest: function (e, t) {
                        var n, r = 0, i = this.length, o = [], a = "string" != typeof e && S(e);
                        if (!N.test(e)) for (; r < i; r++) for (n = this[r]; n && n !== t; n = n.parentNode) if (n.nodeType < 11 && (a ? a.index(n) > -1 : 1 === n.nodeType && S.find.matchesSelector(n, e))) {
                            o.push(n);
                            break
                        }
                        return this.pushStack(o.length > 1 ? S.uniqueSort(o) : o)
                    }, index: function (e) {
                        return e ? "string" == typeof e ? c.call(S(e), this[0]) : c.call(this, e.jquery ? e[0] : e) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
                    }, add: function (e, t) {
                        return this.pushStack(S.uniqueSort(S.merge(this.get(), S(e, t))))
                    }, addBack: function (e) {
                        return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
                    }
                }), S.each({
                    parent: function (e) {
                        var t = e.parentNode;
                        return t && 11 !== t.nodeType ? t : null
                    }, parents: function (e) {
                        return C(e, "parentNode")
                    }, parentsUntil: function (e, t, n) {
                        return C(e, "parentNode", n)
                    }, next: function (e) {
                        return L(e, "nextSibling")
                    }, prev: function (e) {
                        return L(e, "previousSibling")
                    }, nextAll: function (e) {
                        return C(e, "nextSibling")
                    }, prevAll: function (e) {
                        return C(e, "previousSibling")
                    }, nextUntil: function (e, t, n) {
                        return C(e, "nextSibling", n)
                    }, prevUntil: function (e, t, n) {
                        return C(e, "previousSibling", n)
                    }, siblings: function (e) {
                        return M((e.parentNode || {}).firstChild, e)
                    }, children: function (e) {
                        return M(e.firstChild)
                    }, contents: function (e) {
                        return null != e.contentDocument && a(e.contentDocument) ? e.contentDocument : (O(e, "template") && (e = e.content || e), S.merge([], e.childNodes))
                    }
                }, (function (e, t) {
                    S.fn[e] = function (n, r) {
                        var i = S.map(this, t, n);
                        return "Until" !== e.slice(-5) && (r = n), r && "string" == typeof r && (i = S.filter(r, i)), this.length > 1 && (Y[e] || S.uniqueSort(i), R.test(e) && i.reverse()), this.pushStack(i)
                    }
                }));
                var I = /[^\x20\t\r\n\f]+/g;

                function H(e) {
                    return e
                }

                function F(e) {
                    throw e
                }

                function U(e, t, n, r) {
                    var i;
                    try {
                        e && y(i = e.promise) ? i.call(e).done(t).fail(n) : e && y(i = e.then) ? i.call(e, t, n) : t.apply(void 0, [e].slice(r))
                    } catch (e) {
                        n.apply(void 0, [e])
                    }
                }

                S.Callbacks = function (e) {
                    e = "string" == typeof e ? function (e) {
                        var t = {};
                        return S.each(e.match(I) || [], (function (e, n) {
                            t[n] = !0
                        })), t
                    }(e) : S.extend({}, e);
                    var t, n, r, i, o = [], a = [], s = -1, u = function () {
                        for (i = i || e.once, r = t = !0; a.length; s = -1) for (n = a.shift(); ++s < o.length;) !1 === o[s].apply(n[0], n[1]) && e.stopOnFalse && (s = o.length, n = !1);
                        e.memory || (n = !1), t = !1, i && (o = n ? [] : "")
                    }, l = {
                        add: function () {
                            return o && (n && !t && (s = o.length - 1, a.push(n)), function t(n) {
                                S.each(n, (function (n, r) {
                                    y(r) ? e.unique && l.has(r) || o.push(r) : r && r.length && "string" !== x(r) && t(r)
                                }))
                            }(arguments), n && !t && u()), this
                        }, remove: function () {
                            return S.each(arguments, (function (e, t) {
                                for (var n; (n = S.inArray(t, o, n)) > -1;) o.splice(n, 1), n <= s && s--
                            })), this
                        }, has: function (e) {
                            return e ? S.inArray(e, o) > -1 : o.length > 0
                        }, empty: function () {
                            return o && (o = []), this
                        }, disable: function () {
                            return i = a = [], o = n = "", this
                        }, disabled: function () {
                            return !o
                        }, lock: function () {
                            return i = a = [], n || t || (o = n = ""), this
                        }, locked: function () {
                            return !!i
                        }, fireWith: function (e, n) {
                            return i || (n = [e, (n = n || []).slice ? n.slice() : n], a.push(n), t || u()), this
                        }, fire: function () {
                            return l.fireWith(this, arguments), this
                        }, fired: function () {
                            return !!r
                        }
                    };
                    return l
                }, S.extend({
                    Deferred: function (e) {
                        var t = [["notify", "progress", S.Callbacks("memory"), S.Callbacks("memory"), 2], ["resolve", "done", S.Callbacks("once memory"), S.Callbacks("once memory"), 0, "resolved"], ["reject", "fail", S.Callbacks("once memory"), S.Callbacks("once memory"), 1, "rejected"]],
                            n = "pending", i = {
                                state: function () {
                                    return n
                                }, always: function () {
                                    return o.done(arguments).fail(arguments), this
                                }, catch: function (e) {
                                    return i.then(null, e)
                                }, pipe: function () {
                                    var e = arguments;
                                    return S.Deferred((function (n) {
                                        S.each(t, (function (t, r) {
                                            var i = y(e[r[4]]) && e[r[4]];
                                            o[r[1]]((function () {
                                                var e = i && i.apply(this, arguments);
                                                e && y(e.promise) ? e.promise().progress(n.notify).done(n.resolve).fail(n.reject) : n[r[0] + "With"](this, i ? [e] : arguments)
                                            }))
                                        })), e = null
                                    })).promise()
                                }, then: function (e, n, i) {
                                    var o = 0;

                                    function a(e, t, n, i) {
                                        return function () {
                                            var s = this, u = arguments, l = function () {
                                                var r, l;
                                                if (!(e < o)) {
                                                    if ((r = n.apply(s, u)) === t.promise()) throw new TypeError("Thenable self-resolution");
                                                    l = r && ("object" == typeof r || "function" == typeof r) && r.then, y(l) ? i ? l.call(r, a(o, t, H, i), a(o, t, F, i)) : (o++, l.call(r, a(o, t, H, i), a(o, t, F, i), a(o, t, H, t.notifyWith))) : (n !== H && (s = void 0, u = [r]), (i || t.resolveWith)(s, u))
                                                }
                                            }, c = i ? l : function () {
                                                try {
                                                    l()
                                                } catch (r) {
                                                    S.Deferred.exceptionHook && S.Deferred.exceptionHook(r, c.stackTrace), e + 1 >= o && (n !== F && (s = void 0, u = [r]), t.rejectWith(s, u))
                                                }
                                            };
                                            e ? c() : (S.Deferred.getStackHook && (c.stackTrace = S.Deferred.getStackHook()), r.setTimeout(c))
                                        }
                                    }

                                    return S.Deferred((function (r) {
                                        t[0][3].add(a(0, r, y(i) ? i : H, r.notifyWith)), t[1][3].add(a(0, r, y(e) ? e : H)), t[2][3].add(a(0, r, y(n) ? n : F))
                                    })).promise()
                                }, promise: function (e) {
                                    return null != e ? S.extend(e, i) : i
                                }
                            }, o = {};
                        return S.each(t, (function (e, r) {
                            var a = r[2], s = r[5];
                            i[r[1]] = a.add, s && a.add((function () {
                                n = s
                            }), t[3 - e][2].disable, t[3 - e][3].disable, t[0][2].lock, t[0][3].lock), a.add(r[3].fire), o[r[0]] = function () {
                                return o[r[0] + "With"](this === o ? void 0 : this, arguments), this
                            }, o[r[0] + "With"] = a.fireWith
                        })), i.promise(o), e && e.call(o, o), o
                    }, when: function (e) {
                        var t = arguments.length, n = t, r = Array(n), i = s.call(arguments), o = S.Deferred(),
                            a = function (e) {
                                return function (n) {
                                    r[e] = this, i[e] = arguments.length > 1 ? s.call(arguments) : n, --t || o.resolveWith(r, i)
                                }
                            };
                        if (t <= 1 && (U(e, o.done(a(n)).resolve, o.reject, !t), "pending" === o.state() || y(i[n] && i[n].then))) return o.then();
                        for (; n--;) U(i[n], a(n), o.reject);
                        return o.promise()
                    }
                });
                var W = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
                S.Deferred.exceptionHook = function (e, t) {
                    r.console && r.console.warn && e && W.test(e.name) && r.console.warn("jQuery.Deferred exception: " + e.message, e.stack, t)
                }, S.readyException = function (e) {
                    r.setTimeout((function () {
                        throw e
                    }))
                };
                var q = S.Deferred();

                function B() {
                    w.removeEventListener("DOMContentLoaded", B), r.removeEventListener("load", B), S.ready()
                }

                S.fn.ready = function (e) {
                    return q.then(e).catch((function (e) {
                        S.readyException(e)
                    })), this
                }, S.extend({
                    isReady: !1, readyWait: 1, ready: function (e) {
                        (!0 === e ? --S.readyWait : S.isReady) || (S.isReady = !0, !0 !== e && --S.readyWait > 0 || q.resolveWith(w, [S]))
                    }
                }), S.ready.then = q.then, "complete" === w.readyState || "loading" !== w.readyState && !w.documentElement.doScroll ? r.setTimeout(S.ready) : (w.addEventListener("DOMContentLoaded", B), r.addEventListener("load", B));
                var G = function (e, t, n, r, i, o, a) {
                    var s = 0, u = e.length, l = null == n;
                    if ("object" === x(n)) for (s in i = !0, n) G(e, t, s, n[s], !0, o, a); else if (void 0 !== r && (i = !0, y(r) || (a = !0), l && (a ? (t.call(e, r), t = null) : (l = t, t = function (e, t, n) {
                        return l.call(S(e), n)
                    })), t)) for (; s < u; s++) t(e[s], n, a ? r : r.call(e[s], s, t(e[s], n)));
                    return i ? e : l ? t.call(e) : u ? t(e[0], n) : o
                }, V = /^-ms-/, $ = /-([a-z])/g;

                function z(e, t) {
                    return t.toUpperCase()
                }

                function J(e) {
                    return e.replace(V, "ms-").replace($, z)
                }

                var Z = function (e) {
                    return 1 === e.nodeType || 9 === e.nodeType || !+e.nodeType
                };

                function X() {
                    this.expando = S.expando + X.uid++
                }

                X.uid = 1, X.prototype = {
                    cache: function (e) {
                        var t = e[this.expando];
                        return t || (t = {}, Z(e) && (e.nodeType ? e[this.expando] = t : Object.defineProperty(e, this.expando, {
                            value: t,
                            configurable: !0
                        }))), t
                    }, set: function (e, t, n) {
                        var r, i = this.cache(e);
                        if ("string" == typeof t) i[J(t)] = n; else for (r in t) i[J(r)] = t[r];
                        return i
                    }, get: function (e, t) {
                        return void 0 === t ? this.cache(e) : e[this.expando] && e[this.expando][J(t)]
                    }, access: function (e, t, n) {
                        return void 0 === t || t && "string" == typeof t && void 0 === n ? this.get(e, t) : (this.set(e, t, n), void 0 !== n ? n : t)
                    }, remove: function (e, t) {
                        var n, r = e[this.expando];
                        if (void 0 !== r) {
                            if (void 0 !== t) {
                                n = (t = Array.isArray(t) ? t.map(J) : (t = J(t)) in r ? [t] : t.match(I) || []).length;
                                for (; n--;) delete r[t[n]]
                            }
                            (void 0 === t || S.isEmptyObject(r)) && (e.nodeType ? e[this.expando] = void 0 : delete e[this.expando])
                        }
                    }, hasData: function (e) {
                        var t = e[this.expando];
                        return void 0 !== t && !S.isEmptyObject(t)
                    }
                };
                var Q = new X, K = new X, ee = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/, te = /[A-Z]/g;

                function ne(e, t, n) {
                    var r;
                    if (void 0 === n && 1 === e.nodeType) if (r = "data-" + t.replace(te, "-$&").toLowerCase(), "string" == typeof (n = e.getAttribute(r))) {
                        try {
                            n = function (e) {
                                return "true" === e || "false" !== e && ("null" === e ? null : e === +e + "" ? +e : ee.test(e) ? JSON.parse(e) : e)
                            }(n)
                        } catch (e) {
                        }
                        K.set(e, t, n)
                    } else n = void 0;
                    return n
                }

                S.extend({
                    hasData: function (e) {
                        return K.hasData(e) || Q.hasData(e)
                    }, data: function (e, t, n) {
                        return K.access(e, t, n)
                    }, removeData: function (e, t) {
                        K.remove(e, t)
                    }, _data: function (e, t, n) {
                        return Q.access(e, t, n)
                    }, _removeData: function (e, t) {
                        Q.remove(e, t)
                    }
                }), S.fn.extend({
                    data: function (e, t) {
                        var n, r, i, o = this[0], a = o && o.attributes;
                        if (void 0 === e) {
                            if (this.length && (i = K.get(o), 1 === o.nodeType && !Q.get(o, "hasDataAttrs"))) {
                                for (n = a.length; n--;) a[n] && 0 === (r = a[n].name).indexOf("data-") && (r = J(r.slice(5)), ne(o, r, i[r]));
                                Q.set(o, "hasDataAttrs", !0)
                            }
                            return i
                        }
                        return "object" == typeof e ? this.each((function () {
                            K.set(this, e)
                        })) : G(this, (function (t) {
                            var n;
                            if (o && void 0 === t) return void 0 !== (n = K.get(o, e)) || void 0 !== (n = ne(o, e)) ? n : void 0;
                            this.each((function () {
                                K.set(this, e, t)
                            }))
                        }), null, t, arguments.length > 1, null, !0)
                    }, removeData: function (e) {
                        return this.each((function () {
                            K.remove(this, e)
                        }))
                    }
                }), S.extend({
                    queue: function (e, t, n) {
                        var r;
                        if (e) return t = (t || "fx") + "queue", r = Q.get(e, t), n && (!r || Array.isArray(n) ? r = Q.access(e, t, S.makeArray(n)) : r.push(n)), r || []
                    }, dequeue: function (e, t) {
                        t = t || "fx";
                        var n = S.queue(e, t), r = n.length, i = n.shift(), o = S._queueHooks(e, t);
                        "inprogress" === i && (i = n.shift(), r--), i && ("fx" === t && n.unshift("inprogress"), delete o.stop, i.call(e, (function () {
                            S.dequeue(e, t)
                        }), o)), !r && o && o.empty.fire()
                    }, _queueHooks: function (e, t) {
                        var n = t + "queueHooks";
                        return Q.get(e, n) || Q.access(e, n, {
                            empty: S.Callbacks("once memory").add((function () {
                                Q.remove(e, [t + "queue", n])
                            }))
                        })
                    }
                }), S.fn.extend({
                    queue: function (e, t) {
                        var n = 2;
                        return "string" != typeof e && (t = e, e = "fx", n--), arguments.length < n ? S.queue(this[0], e) : void 0 === t ? this : this.each((function () {
                            var n = S.queue(this, e, t);
                            S._queueHooks(this, e), "fx" === e && "inprogress" !== n[0] && S.dequeue(this, e)
                        }))
                    }, dequeue: function (e) {
                        return this.each((function () {
                            S.dequeue(this, e)
                        }))
                    }, clearQueue: function (e) {
                        return this.queue(e || "fx", [])
                    }, promise: function (e, t) {
                        var n, r = 1, i = S.Deferred(), o = this, a = this.length, s = function () {
                            --r || i.resolveWith(o, [o])
                        };
                        for ("string" != typeof e && (t = e, e = void 0), e = e || "fx"; a--;) (n = Q.get(o[a], e + "queueHooks")) && n.empty && (r++, n.empty.add(s));
                        return s(), i.promise(t)
                    }
                });
                var re = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
                    ie = new RegExp("^(?:([+-])=|)(" + re + ")([a-z%]*)$", "i"),
                    oe = ["Top", "Right", "Bottom", "Left"], ae = w.documentElement, se = function (e) {
                        return S.contains(e.ownerDocument, e)
                    }, ue = {composed: !0};
                ae.getRootNode && (se = function (e) {
                    return S.contains(e.ownerDocument, e) || e.getRootNode(ue) === e.ownerDocument
                });
                var le = function (e, t) {
                    return "none" === (e = t || e).style.display || "" === e.style.display && se(e) && "none" === S.css(e, "display")
                };

                function ce(e, t, n, r) {
                    var i, o, a = 20, s = r ? function () {
                            return r.cur()
                        } : function () {
                            return S.css(e, t, "")
                        }, u = s(), l = n && n[3] || (S.cssNumber[t] ? "" : "px"),
                        c = e.nodeType && (S.cssNumber[t] || "px" !== l && +u) && ie.exec(S.css(e, t));
                    if (c && c[3] !== l) {
                        for (u /= 2, l = l || c[3], c = +u || 1; a--;) S.style(e, t, c + l), (1 - o) * (1 - (o = s() / u || .5)) <= 0 && (a = 0), c /= o;
                        c *= 2, S.style(e, t, c + l), n = n || []
                    }
                    return n && (c = +c || +u || 0, i = n[1] ? c + (n[1] + 1) * n[2] : +n[2], r && (r.unit = l, r.start = c, r.end = i)), i
                }

                var de = {};

                function fe(e) {
                    var t, n = e.ownerDocument, r = e.nodeName, i = de[r];
                    return i || (t = n.body.appendChild(n.createElement(r)), i = S.css(t, "display"), t.parentNode.removeChild(t), "none" === i && (i = "block"), de[r] = i, i)
                }

                function he(e, t) {
                    for (var n, r, i = [], o = 0, a = e.length; o < a; o++) (r = e[o]).style && (n = r.style.display, t ? ("none" === n && (i[o] = Q.get(r, "display") || null, i[o] || (r.style.display = "")), "" === r.style.display && le(r) && (i[o] = fe(r))) : "none" !== n && (i[o] = "none", Q.set(r, "display", n)));
                    for (o = 0; o < a; o++) null != i[o] && (e[o].style.display = i[o]);
                    return e
                }

                S.fn.extend({
                    show: function () {
                        return he(this, !0)
                    }, hide: function () {
                        return he(this)
                    }, toggle: function (e) {
                        return "boolean" == typeof e ? e ? this.show() : this.hide() : this.each((function () {
                            le(this) ? S(this).show() : S(this).hide()
                        }))
                    }
                });
                var pe, me, ge = /^(?:checkbox|radio)$/i, ye = /<([a-z][^\/\0>\x20\t\r\n\f]*)/i,
                    ve = /^$|^module$|\/(?:java|ecma)script/i;
                pe = w.createDocumentFragment().appendChild(w.createElement("div")), (me = w.createElement("input")).setAttribute("type", "radio"), me.setAttribute("checked", "checked"), me.setAttribute("name", "t"), pe.appendChild(me), g.checkClone = pe.cloneNode(!0).cloneNode(!0).lastChild.checked, pe.innerHTML = "<textarea>x</textarea>", g.noCloneChecked = !!pe.cloneNode(!0).lastChild.defaultValue, pe.innerHTML = "<option></option>", g.option = !!pe.lastChild;
                var we = {
                    thead: [1, "<table>", "</table>"],
                    col: [2, "<table><colgroup>", "</colgroup></table>"],
                    tr: [2, "<table><tbody>", "</tbody></table>"],
                    td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
                    _default: [0, "", ""]
                };

                function _e(e, t) {
                    var n;
                    return n = void 0 !== e.getElementsByTagName ? e.getElementsByTagName(t || "*") : void 0 !== e.querySelectorAll ? e.querySelectorAll(t || "*") : [], void 0 === t || t && O(e, t) ? S.merge([e], n) : n
                }

                function be(e, t) {
                    for (var n = 0, r = e.length; n < r; n++) Q.set(e[n], "globalEval", !t || Q.get(t[n], "globalEval"))
                }

                we.tbody = we.tfoot = we.colgroup = we.caption = we.thead, we.th = we.td, g.option || (we.optgroup = we.option = [1, "<select multiple='multiple'>", "</select>"]);
                var xe = /<|&#?\w+;/;

                function ke(e, t, n, r, i) {
                    for (var o, a, s, u, l, c, d = t.createDocumentFragment(), f = [], h = 0, p = e.length; h < p; h++) if ((o = e[h]) || 0 === o) if ("object" === x(o)) S.merge(f, o.nodeType ? [o] : o); else if (xe.test(o)) {
                        for (a = a || d.appendChild(t.createElement("div")), s = (ye.exec(o) || ["", ""])[1].toLowerCase(), u = we[s] || we._default, a.innerHTML = u[1] + S.htmlPrefilter(o) + u[2], c = u[0]; c--;) a = a.lastChild;
                        S.merge(f, a.childNodes), (a = d.firstChild).textContent = ""
                    } else f.push(t.createTextNode(o));
                    for (d.textContent = "", h = 0; o = f[h++];) if (r && S.inArray(o, r) > -1) i && i.push(o); else if (l = se(o), a = _e(d.appendChild(o), "script"), l && be(a), n) for (c = 0; o = a[c++];) ve.test(o.type || "") && n.push(o);
                    return d
                }

                var Se = /^([^.]*)(?:\.(.+)|)/;

                function Te() {
                    return !0
                }

                function De() {
                    return !1
                }

                function Ce(e, t) {
                    return e === function () {
                        try {
                            return w.activeElement
                        } catch (e) {
                        }
                    }() == ("focus" === t)
                }

                function Me(e, t, n, r, i, o) {
                    var a, s;
                    if ("object" == typeof t) {
                        for (s in "string" != typeof n && (r = r || n, n = void 0), t) Me(e, s, n, r, t[s], o);
                        return e
                    }
                    if (null == r && null == i ? (i = n, r = n = void 0) : null == i && ("string" == typeof n ? (i = r, r = void 0) : (i = r, r = n, n = void 0)), !1 === i) i = De; else if (!i) return e;
                    return 1 === o && (a = i, i = function (e) {
                        return S().off(e), a.apply(this, arguments)
                    }, i.guid = a.guid || (a.guid = S.guid++)), e.each((function () {
                        S.event.add(this, t, i, r, n)
                    }))
                }

                function Ne(e, t, n) {
                    n ? (Q.set(e, t, !1), S.event.add(e, t, {
                        namespace: !1, handler: function (e) {
                            var r, i, o = Q.get(this, t);
                            if (1 & e.isTrigger && this[t]) {
                                if (o.length) (S.event.special[t] || {}).delegateType && e.stopPropagation(); else if (o = s.call(arguments), Q.set(this, t, o), r = n(this, t), this[t](), o !== (i = Q.get(this, t)) || r ? Q.set(this, t, !1) : i = {}, o !== i) return e.stopImmediatePropagation(), e.preventDefault(), i && i.value
                            } else o.length && (Q.set(this, t, {value: S.event.trigger(S.extend(o[0], S.Event.prototype), o.slice(1), this)}), e.stopImmediatePropagation())
                        }
                    })) : void 0 === Q.get(e, t) && S.event.add(e, t, Te)
                }

                S.event = {
                    global: {}, add: function (e, t, n, r, i) {
                        var o, a, s, u, l, c, d, f, h, p, m, g = Q.get(e);
                        if (Z(e)) for (n.handler && (n = (o = n).handler, i = o.selector), i && S.find.matchesSelector(ae, i), n.guid || (n.guid = S.guid++), (u = g.events) || (u = g.events = Object.create(null)), (a = g.handle) || (a = g.handle = function (t) {
                            return void 0 !== S && S.event.triggered !== t.type ? S.event.dispatch.apply(e, arguments) : void 0
                        }), l = (t = (t || "").match(I) || [""]).length; l--;) h = m = (s = Se.exec(t[l]) || [])[1], p = (s[2] || "").split(".").sort(), h && (d = S.event.special[h] || {}, h = (i ? d.delegateType : d.bindType) || h, d = S.event.special[h] || {}, c = S.extend({
                            type: h,
                            origType: m,
                            data: r,
                            handler: n,
                            guid: n.guid,
                            selector: i,
                            needsContext: i && S.expr.match.needsContext.test(i),
                            namespace: p.join(".")
                        }, o), (f = u[h]) || ((f = u[h] = []).delegateCount = 0, d.setup && !1 !== d.setup.call(e, r, p, a) || e.addEventListener && e.addEventListener(h, a)), d.add && (d.add.call(e, c), c.handler.guid || (c.handler.guid = n.guid)), i ? f.splice(f.delegateCount++, 0, c) : f.push(c), S.event.global[h] = !0)
                    }, remove: function (e, t, n, r, i) {
                        var o, a, s, u, l, c, d, f, h, p, m, g = Q.hasData(e) && Q.get(e);
                        if (g && (u = g.events)) {
                            for (l = (t = (t || "").match(I) || [""]).length; l--;) if (h = m = (s = Se.exec(t[l]) || [])[1], p = (s[2] || "").split(".").sort(), h) {
                                for (d = S.event.special[h] || {}, f = u[h = (r ? d.delegateType : d.bindType) || h] || [], s = s[2] && new RegExp("(^|\\.)" + p.join("\\.(?:.*\\.|)") + "(\\.|$)"), a = o = f.length; o--;) c = f[o], !i && m !== c.origType || n && n.guid !== c.guid || s && !s.test(c.namespace) || r && r !== c.selector && ("**" !== r || !c.selector) || (f.splice(o, 1), c.selector && f.delegateCount--, d.remove && d.remove.call(e, c));
                                a && !f.length && (d.teardown && !1 !== d.teardown.call(e, p, g.handle) || S.removeEvent(e, h, g.handle), delete u[h])
                            } else for (h in u) S.event.remove(e, h + t[l], n, r, !0);
                            S.isEmptyObject(u) && Q.remove(e, "handle events")
                        }
                    }, dispatch: function (e) {
                        var t, n, r, i, o, a, s = new Array(arguments.length), u = S.event.fix(e),
                            l = (Q.get(this, "events") || Object.create(null))[u.type] || [],
                            c = S.event.special[u.type] || {};
                        for (s[0] = u, t = 1; t < arguments.length; t++) s[t] = arguments[t];
                        if (u.delegateTarget = this, !c.preDispatch || !1 !== c.preDispatch.call(this, u)) {
                            for (a = S.event.handlers.call(this, u, l), t = 0; (i = a[t++]) && !u.isPropagationStopped();) for (u.currentTarget = i.elem, n = 0; (o = i.handlers[n++]) && !u.isImmediatePropagationStopped();) u.rnamespace && !1 !== o.namespace && !u.rnamespace.test(o.namespace) || (u.handleObj = o, u.data = o.data, void 0 !== (r = ((S.event.special[o.origType] || {}).handle || o.handler).apply(i.elem, s)) && !1 === (u.result = r) && (u.preventDefault(), u.stopPropagation()));
                            return c.postDispatch && c.postDispatch.call(this, u), u.result
                        }
                    }, handlers: function (e, t) {
                        var n, r, i, o, a, s = [], u = t.delegateCount, l = e.target;
                        if (u && l.nodeType && !("click" === e.type && e.button >= 1)) for (; l !== this; l = l.parentNode || this) if (1 === l.nodeType && ("click" !== e.type || !0 !== l.disabled)) {
                            for (o = [], a = {}, n = 0; n < u; n++) void 0 === a[i = (r = t[n]).selector + " "] && (a[i] = r.needsContext ? S(i, this).index(l) > -1 : S.find(i, this, null, [l]).length), a[i] && o.push(r);
                            o.length && s.push({elem: l, handlers: o})
                        }
                        return l = this, u < t.length && s.push({elem: l, handlers: t.slice(u)}), s
                    }, addProp: function (e, t) {
                        Object.defineProperty(S.Event.prototype, e, {
                            enumerable: !0,
                            configurable: !0,
                            get: y(t) ? function () {
                                if (this.originalEvent) return t(this.originalEvent)
                            } : function () {
                                if (this.originalEvent) return this.originalEvent[e]
                            },
                            set: function (t) {
                                Object.defineProperty(this, e, {
                                    enumerable: !0,
                                    configurable: !0,
                                    writable: !0,
                                    value: t
                                })
                            }
                        })
                    }, fix: function (e) {
                        return e[S.expando] ? e : new S.Event(e)
                    }, special: {
                        load: {noBubble: !0}, click: {
                            setup: function (e) {
                                var t = this || e;
                                return ge.test(t.type) && t.click && O(t, "input") && Ne(t, "click", Te), !1
                            }, trigger: function (e) {
                                var t = this || e;
                                return ge.test(t.type) && t.click && O(t, "input") && Ne(t, "click"), !0
                            }, _default: function (e) {
                                var t = e.target;
                                return ge.test(t.type) && t.click && O(t, "input") && Q.get(t, "click") || O(t, "a")
                            }
                        }, beforeunload: {
                            postDispatch: function (e) {
                                void 0 !== e.result && e.originalEvent && (e.originalEvent.returnValue = e.result)
                            }
                        }
                    }
                }, S.removeEvent = function (e, t, n) {
                    e.removeEventListener && e.removeEventListener(t, n)
                }, S.Event = function (e, t) {
                    if (!(this instanceof S.Event)) return new S.Event(e, t);
                    e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || void 0 === e.defaultPrevented && !1 === e.returnValue ? Te : De, this.target = e.target && 3 === e.target.nodeType ? e.target.parentNode : e.target, this.currentTarget = e.currentTarget, this.relatedTarget = e.relatedTarget) : this.type = e, t && S.extend(this, t), this.timeStamp = e && e.timeStamp || Date.now(), this[S.expando] = !0
                }, S.Event.prototype = {
                    constructor: S.Event,
                    isDefaultPrevented: De,
                    isPropagationStopped: De,
                    isImmediatePropagationStopped: De,
                    isSimulated: !1,
                    preventDefault: function () {
                        var e = this.originalEvent;
                        this.isDefaultPrevented = Te, e && !this.isSimulated && e.preventDefault()
                    },
                    stopPropagation: function () {
                        var e = this.originalEvent;
                        this.isPropagationStopped = Te, e && !this.isSimulated && e.stopPropagation()
                    },
                    stopImmediatePropagation: function () {
                        var e = this.originalEvent;
                        this.isImmediatePropagationStopped = Te, e && !this.isSimulated && e.stopImmediatePropagation(), this.stopPropagation()
                    }
                }, S.each({
                    altKey: !0,
                    bubbles: !0,
                    cancelable: !0,
                    changedTouches: !0,
                    ctrlKey: !0,
                    detail: !0,
                    eventPhase: !0,
                    metaKey: !0,
                    pageX: !0,
                    pageY: !0,
                    shiftKey: !0,
                    view: !0,
                    char: !0,
                    code: !0,
                    charCode: !0,
                    key: !0,
                    keyCode: !0,
                    button: !0,
                    buttons: !0,
                    clientX: !0,
                    clientY: !0,
                    offsetX: !0,
                    offsetY: !0,
                    pointerId: !0,
                    pointerType: !0,
                    screenX: !0,
                    screenY: !0,
                    targetTouches: !0,
                    toElement: !0,
                    touches: !0,
                    which: !0
                }, S.event.addProp), S.each({focus: "focusin", blur: "focusout"}, (function (e, t) {
                    S.event.special[e] = {
                        setup: function () {
                            return Ne(this, e, Ce), !1
                        }, trigger: function () {
                            return Ne(this, e), !0
                        }, _default: function (t) {
                            return Q.get(t.target, e)
                        }, delegateType: t
                    }
                })), S.each({
                    mouseenter: "mouseover",
                    mouseleave: "mouseout",
                    pointerenter: "pointerover",
                    pointerleave: "pointerout"
                }, (function (e, t) {
                    S.event.special[e] = {
                        delegateType: t, bindType: t, handle: function (e) {
                            var n, r = e.relatedTarget, i = e.handleObj;
                            return r && (r === this || S.contains(this, r)) || (e.type = i.origType, n = i.handler.apply(this, arguments), e.type = t), n
                        }
                    }
                })), S.fn.extend({
                    on: function (e, t, n, r) {
                        return Me(this, e, t, n, r)
                    }, one: function (e, t, n, r) {
                        return Me(this, e, t, n, r, 1)
                    }, off: function (e, t, n) {
                        var r, i;
                        if (e && e.preventDefault && e.handleObj) return r = e.handleObj, S(e.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace : r.origType, r.selector, r.handler), this;
                        if ("object" == typeof e) {
                            for (i in e) this.off(i, t, e[i]);
                            return this
                        }
                        return !1 !== t && "function" != typeof t || (n = t, t = void 0), !1 === n && (n = De), this.each((function () {
                            S.event.remove(this, e, n, t)
                        }))
                    }
                });
                var Oe = /<script|<style|<link/i, Ee = /checked\s*(?:[^=]|=\s*.checked.)/i,
                    Ae = /^\s*<!\[CDATA\[|\]\]>\s*$/g;

                function je(e, t) {
                    return O(e, "table") && O(11 !== t.nodeType ? t : t.firstChild, "tr") && S(e).children("tbody")[0] || e
                }

                function Pe(e) {
                    return e.type = (null !== e.getAttribute("type")) + "/" + e.type, e
                }

                function Re(e) {
                    return "true/" === (e.type || "").slice(0, 5) ? e.type = e.type.slice(5) : e.removeAttribute("type"), e
                }

                function Ye(e, t) {
                    var n, r, i, o, a, s;
                    if (1 === t.nodeType) {
                        if (Q.hasData(e) && (s = Q.get(e).events)) for (i in Q.remove(t, "handle events"), s) for (n = 0, r = s[i].length; n < r; n++) S.event.add(t, i, s[i][n]);
                        K.hasData(e) && (o = K.access(e), a = S.extend({}, o), K.set(t, a))
                    }
                }

                function Le(e, t) {
                    var n = t.nodeName.toLowerCase();
                    "input" === n && ge.test(e.type) ? t.checked = e.checked : "input" !== n && "textarea" !== n || (t.defaultValue = e.defaultValue)
                }

                function Ie(e, t, n, r) {
                    t = u(t);
                    var i, o, a, s, l, c, d = 0, f = e.length, h = f - 1, p = t[0], m = y(p);
                    if (m || f > 1 && "string" == typeof p && !g.checkClone && Ee.test(p)) return e.each((function (i) {
                        var o = e.eq(i);
                        m && (t[0] = p.call(this, i, o.html())), Ie(o, t, n, r)
                    }));
                    if (f && (o = (i = ke(t, e[0].ownerDocument, !1, e, r)).firstChild, 1 === i.childNodes.length && (i = o), o || r)) {
                        for (s = (a = S.map(_e(i, "script"), Pe)).length; d < f; d++) l = i, d !== h && (l = S.clone(l, !0, !0), s && S.merge(a, _e(l, "script"))), n.call(e[d], l, d);
                        if (s) for (c = a[a.length - 1].ownerDocument, S.map(a, Re), d = 0; d < s; d++) l = a[d], ve.test(l.type || "") && !Q.access(l, "globalEval") && S.contains(c, l) && (l.src && "module" !== (l.type || "").toLowerCase() ? S._evalUrl && !l.noModule && S._evalUrl(l.src, {nonce: l.nonce || l.getAttribute("nonce")}, c) : b(l.textContent.replace(Ae, ""), l, c))
                    }
                    return e
                }

                function He(e, t, n) {
                    for (var r, i = t ? S.filter(t, e) : e, o = 0; null != (r = i[o]); o++) n || 1 !== r.nodeType || S.cleanData(_e(r)), r.parentNode && (n && se(r) && be(_e(r, "script")), r.parentNode.removeChild(r));
                    return e
                }

                S.extend({
                    htmlPrefilter: function (e) {
                        return e
                    }, clone: function (e, t, n) {
                        var r, i, o, a, s = e.cloneNode(!0), u = se(e);
                        if (!(g.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || S.isXMLDoc(e))) for (a = _e(s), r = 0, i = (o = _e(e)).length; r < i; r++) Le(o[r], a[r]);
                        if (t) if (n) for (o = o || _e(e), a = a || _e(s), r = 0, i = o.length; r < i; r++) Ye(o[r], a[r]); else Ye(e, s);
                        return (a = _e(s, "script")).length > 0 && be(a, !u && _e(e, "script")), s
                    }, cleanData: function (e) {
                        for (var t, n, r, i = S.event.special, o = 0; void 0 !== (n = e[o]); o++) if (Z(n)) {
                            if (t = n[Q.expando]) {
                                if (t.events) for (r in t.events) i[r] ? S.event.remove(n, r) : S.removeEvent(n, r, t.handle);
                                n[Q.expando] = void 0
                            }
                            n[K.expando] && (n[K.expando] = void 0)
                        }
                    }
                }), S.fn.extend({
                    detach: function (e) {
                        return He(this, e, !0)
                    }, remove: function (e) {
                        return He(this, e)
                    }, text: function (e) {
                        return G(this, (function (e) {
                            return void 0 === e ? S.text(this) : this.empty().each((function () {
                                1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || (this.textContent = e)
                            }))
                        }), null, e, arguments.length)
                    }, append: function () {
                        return Ie(this, arguments, (function (e) {
                            1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || je(this, e).appendChild(e)
                        }))
                    }, prepend: function () {
                        return Ie(this, arguments, (function (e) {
                            if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                                var t = je(this, e);
                                t.insertBefore(e, t.firstChild)
                            }
                        }))
                    }, before: function () {
                        return Ie(this, arguments, (function (e) {
                            this.parentNode && this.parentNode.insertBefore(e, this)
                        }))
                    }, after: function () {
                        return Ie(this, arguments, (function (e) {
                            this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
                        }))
                    }, empty: function () {
                        for (var e, t = 0; null != (e = this[t]); t++) 1 === e.nodeType && (S.cleanData(_e(e, !1)), e.textContent = "");
                        return this
                    }, clone: function (e, t) {
                        return e = null != e && e, t = null == t ? e : t, this.map((function () {
                            return S.clone(this, e, t)
                        }))
                    }, html: function (e) {
                        return G(this, (function (e) {
                            var t = this[0] || {}, n = 0, r = this.length;
                            if (void 0 === e && 1 === t.nodeType) return t.innerHTML;
                            if ("string" == typeof e && !Oe.test(e) && !we[(ye.exec(e) || ["", ""])[1].toLowerCase()]) {
                                e = S.htmlPrefilter(e);
                                try {
                                    for (; n < r; n++) 1 === (t = this[n] || {}).nodeType && (S.cleanData(_e(t, !1)), t.innerHTML = e);
                                    t = 0
                                } catch (e) {
                                }
                            }
                            t && this.empty().append(e)
                        }), null, e, arguments.length)
                    }, replaceWith: function () {
                        var e = [];
                        return Ie(this, arguments, (function (t) {
                            var n = this.parentNode;
                            S.inArray(this, e) < 0 && (S.cleanData(_e(this)), n && n.replaceChild(t, this))
                        }), e)
                    }
                }), S.each({
                    appendTo: "append",
                    prependTo: "prepend",
                    insertBefore: "before",
                    insertAfter: "after",
                    replaceAll: "replaceWith"
                }, (function (e, t) {
                    S.fn[e] = function (e) {
                        for (var n, r = [], i = S(e), o = i.length - 1, a = 0; a <= o; a++) n = a === o ? this : this.clone(!0), S(i[a])[t](n), l.apply(r, n.get());
                        return this.pushStack(r)
                    }
                }));
                var Fe = new RegExp("^(" + re + ")(?!px)[a-z%]+$", "i"), Ue = /^--/, We = function (e) {
                        var t = e.ownerDocument.defaultView;
                        return t && t.opener || (t = r), t.getComputedStyle(e)
                    }, qe = function (e, t, n) {
                        var r, i, o = {};
                        for (i in t) o[i] = e.style[i], e.style[i] = t[i];
                        for (i in r = n.call(e), t) e.style[i] = o[i];
                        return r
                    }, Be = new RegExp(oe.join("|"), "i"), Ge = "[\\x20\\t\\r\\n\\f]",
                    Ve = new RegExp("^" + Ge + "+|((?:^|[^\\\\])(?:\\\\.)*)" + Ge + "+$", "g");

                function $e(e, t, n) {
                    var r, i, o, a, s = Ue.test(t), u = e.style;
                    return (n = n || We(e)) && (a = n.getPropertyValue(t) || n[t], s && a && (a = a.replace(Ve, "$1") || void 0), "" !== a || se(e) || (a = S.style(e, t)), !g.pixelBoxStyles() && Fe.test(a) && Be.test(t) && (r = u.width, i = u.minWidth, o = u.maxWidth, u.minWidth = u.maxWidth = u.width = a, a = n.width, u.width = r, u.minWidth = i, u.maxWidth = o)), void 0 !== a ? a + "" : a
                }

                function ze(e, t) {
                    return {
                        get: function () {
                            if (!e()) return (this.get = t).apply(this, arguments);
                            delete this.get
                        }
                    }
                }

                !function () {
                    function e() {
                        if (c) {
                            l.style.cssText = "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0", c.style.cssText = "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%", ae.appendChild(l).appendChild(c);
                            var e = r.getComputedStyle(c);
                            n = "1%" !== e.top, u = 12 === t(e.marginLeft), c.style.right = "60%", a = 36 === t(e.right), i = 36 === t(e.width), c.style.position = "absolute", o = 12 === t(c.offsetWidth / 3), ae.removeChild(l), c = null
                        }
                    }

                    function t(e) {
                        return Math.round(parseFloat(e))
                    }

                    var n, i, o, a, s, u, l = w.createElement("div"), c = w.createElement("div");
                    c.style && (c.style.backgroundClip = "content-box", c.cloneNode(!0).style.backgroundClip = "", g.clearCloneStyle = "content-box" === c.style.backgroundClip, S.extend(g, {
                        boxSizingReliable: function () {
                            return e(), i
                        }, pixelBoxStyles: function () {
                            return e(), a
                        }, pixelPosition: function () {
                            return e(), n
                        }, reliableMarginLeft: function () {
                            return e(), u
                        }, scrollboxSize: function () {
                            return e(), o
                        }, reliableTrDimensions: function () {
                            var e, t, n, i;
                            return null == s && (e = w.createElement("table"), t = w.createElement("tr"), n = w.createElement("div"), e.style.cssText = "position:absolute;left:-11111px;border-collapse:separate", t.style.cssText = "border:1px solid", t.style.height = "1px", n.style.height = "9px", n.style.display = "block", ae.appendChild(e).appendChild(t).appendChild(n), i = r.getComputedStyle(t), s = parseInt(i.height, 10) + parseInt(i.borderTopWidth, 10) + parseInt(i.borderBottomWidth, 10) === t.offsetHeight, ae.removeChild(e)), s
                        }
                    }))
                }();
                var Je = ["Webkit", "Moz", "ms"], Ze = w.createElement("div").style, Xe = {};

                function Qe(e) {
                    return S.cssProps[e] || Xe[e] || (e in Ze ? e : Xe[e] = function (e) {
                        for (var t = e[0].toUpperCase() + e.slice(1), n = Je.length; n--;) if ((e = Je[n] + t) in Ze) return e
                    }(e) || e)
                }

                var Ke = /^(none|table(?!-c[ea]).+)/,
                    et = {position: "absolute", visibility: "hidden", display: "block"},
                    tt = {letterSpacing: "0", fontWeight: "400"};

                function nt(e, t, n) {
                    var r = ie.exec(t);
                    return r ? Math.max(0, r[2] - (n || 0)) + (r[3] || "px") : t
                }

                function rt(e, t, n, r, i, o) {
                    var a = "width" === t ? 1 : 0, s = 0, u = 0;
                    if (n === (r ? "border" : "content")) return 0;
                    for (; a < 4; a += 2) "margin" === n && (u += S.css(e, n + oe[a], !0, i)), r ? ("content" === n && (u -= S.css(e, "padding" + oe[a], !0, i)), "margin" !== n && (u -= S.css(e, "border" + oe[a] + "Width", !0, i))) : (u += S.css(e, "padding" + oe[a], !0, i), "padding" !== n ? u += S.css(e, "border" + oe[a] + "Width", !0, i) : s += S.css(e, "border" + oe[a] + "Width", !0, i));
                    return !r && o >= 0 && (u += Math.max(0, Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - o - u - s - .5)) || 0), u
                }

                function it(e, t, n) {
                    var r = We(e), i = (!g.boxSizingReliable() || n) && "border-box" === S.css(e, "boxSizing", !1, r),
                        o = i, a = $e(e, t, r), s = "offset" + t[0].toUpperCase() + t.slice(1);
                    if (Fe.test(a)) {
                        if (!n) return a;
                        a = "auto"
                    }
                    return (!g.boxSizingReliable() && i || !g.reliableTrDimensions() && O(e, "tr") || "auto" === a || !parseFloat(a) && "inline" === S.css(e, "display", !1, r)) && e.getClientRects().length && (i = "border-box" === S.css(e, "boxSizing", !1, r), (o = s in e) && (a = e[s])), (a = parseFloat(a) || 0) + rt(e, t, n || (i ? "border" : "content"), o, r, a) + "px"
                }

                function ot(e, t, n, r, i) {
                    return new ot.prototype.init(e, t, n, r, i)
                }

                S.extend({
                    cssHooks: {
                        opacity: {
                            get: function (e, t) {
                                if (t) {
                                    var n = $e(e, "opacity");
                                    return "" === n ? "1" : n
                                }
                            }
                        }
                    },
                    cssNumber: {
                        animationIterationCount: !0,
                        columnCount: !0,
                        fillOpacity: !0,
                        flexGrow: !0,
                        flexShrink: !0,
                        fontWeight: !0,
                        gridArea: !0,
                        gridColumn: !0,
                        gridColumnEnd: !0,
                        gridColumnStart: !0,
                        gridRow: !0,
                        gridRowEnd: !0,
                        gridRowStart: !0,
                        lineHeight: !0,
                        opacity: !0,
                        order: !0,
                        orphans: !0,
                        widows: !0,
                        zIndex: !0,
                        zoom: !0
                    },
                    cssProps: {},
                    style: function (e, t, n, r) {
                        if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                            var i, o, a, s = J(t), u = Ue.test(t), l = e.style;
                            if (u || (t = Qe(s)), a = S.cssHooks[t] || S.cssHooks[s], void 0 === n) return a && "get" in a && void 0 !== (i = a.get(e, !1, r)) ? i : l[t];
                            "string" == (o = typeof n) && (i = ie.exec(n)) && i[1] && (n = ce(e, t, i), o = "number"), null != n && n == n && ("number" !== o || u || (n += i && i[3] || (S.cssNumber[s] ? "" : "px")), g.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (l[t] = "inherit"), a && "set" in a && void 0 === (n = a.set(e, n, r)) || (u ? l.setProperty(t, n) : l[t] = n))
                        }
                    },
                    css: function (e, t, n, r) {
                        var i, o, a, s = J(t);
                        return Ue.test(t) || (t = Qe(s)), (a = S.cssHooks[t] || S.cssHooks[s]) && "get" in a && (i = a.get(e, !0, n)), void 0 === i && (i = $e(e, t, r)), "normal" === i && t in tt && (i = tt[t]), "" === n || n ? (o = parseFloat(i), !0 === n || isFinite(o) ? o || 0 : i) : i
                    }
                }), S.each(["height", "width"], (function (e, t) {
                    S.cssHooks[t] = {
                        get: function (e, n, r) {
                            if (n) return !Ke.test(S.css(e, "display")) || e.getClientRects().length && e.getBoundingClientRect().width ? it(e, t, r) : qe(e, et, (function () {
                                return it(e, t, r)
                            }))
                        }, set: function (e, n, r) {
                            var i, o = We(e), a = !g.scrollboxSize() && "absolute" === o.position,
                                s = (a || r) && "border-box" === S.css(e, "boxSizing", !1, o),
                                u = r ? rt(e, t, r, s, o) : 0;
                            return s && a && (u -= Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - parseFloat(o[t]) - rt(e, t, "border", !1, o) - .5)), u && (i = ie.exec(n)) && "px" !== (i[3] || "px") && (e.style[t] = n, n = S.css(e, t)), nt(0, n, u)
                        }
                    }
                })), S.cssHooks.marginLeft = ze(g.reliableMarginLeft, (function (e, t) {
                    if (t) return (parseFloat($e(e, "marginLeft")) || e.getBoundingClientRect().left - qe(e, {marginLeft: 0}, (function () {
                        return e.getBoundingClientRect().left
                    }))) + "px"
                })), S.each({margin: "", padding: "", border: "Width"}, (function (e, t) {
                    S.cssHooks[e + t] = {
                        expand: function (n) {
                            for (var r = 0, i = {}, o = "string" == typeof n ? n.split(" ") : [n]; r < 4; r++) i[e + oe[r] + t] = o[r] || o[r - 2] || o[0];
                            return i
                        }
                    }, "margin" !== e && (S.cssHooks[e + t].set = nt)
                })), S.fn.extend({
                    css: function (e, t) {
                        return G(this, (function (e, t, n) {
                            var r, i, o = {}, a = 0;
                            if (Array.isArray(t)) {
                                for (r = We(e), i = t.length; a < i; a++) o[t[a]] = S.css(e, t[a], !1, r);
                                return o
                            }
                            return void 0 !== n ? S.style(e, t, n) : S.css(e, t)
                        }), e, t, arguments.length > 1)
                    }
                }), S.Tween = ot, ot.prototype = {
                    constructor: ot, init: function (e, t, n, r, i, o) {
                        this.elem = e, this.prop = n, this.easing = i || S.easing._default, this.options = t, this.start = this.now = this.cur(), this.end = r, this.unit = o || (S.cssNumber[n] ? "" : "px")
                    }, cur: function () {
                        var e = ot.propHooks[this.prop];
                        return e && e.get ? e.get(this) : ot.propHooks._default.get(this)
                    }, run: function (e) {
                        var t, n = ot.propHooks[this.prop];
                        return this.options.duration ? this.pos = t = S.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : ot.propHooks._default.set(this), this
                    }
                }, ot.prototype.init.prototype = ot.prototype, ot.propHooks = {
                    _default: {
                        get: function (e) {
                            var t;
                            return 1 !== e.elem.nodeType || null != e.elem[e.prop] && null == e.elem.style[e.prop] ? e.elem[e.prop] : (t = S.css(e.elem, e.prop, "")) && "auto" !== t ? t : 0
                        }, set: function (e) {
                            S.fx.step[e.prop] ? S.fx.step[e.prop](e) : 1 !== e.elem.nodeType || !S.cssHooks[e.prop] && null == e.elem.style[Qe(e.prop)] ? e.elem[e.prop] = e.now : S.style(e.elem, e.prop, e.now + e.unit)
                        }
                    }
                }, ot.propHooks.scrollTop = ot.propHooks.scrollLeft = {
                    set: function (e) {
                        e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
                    }
                }, S.easing = {
                    linear: function (e) {
                        return e
                    }, swing: function (e) {
                        return .5 - Math.cos(e * Math.PI) / 2
                    }, _default: "swing"
                }, S.fx = ot.prototype.init, S.fx.step = {};
                var at, st, ut = /^(?:toggle|show|hide)$/, lt = /queueHooks$/;

                function ct() {
                    st && (!1 === w.hidden && r.requestAnimationFrame ? r.requestAnimationFrame(ct) : r.setTimeout(ct, S.fx.interval), S.fx.tick())
                }

                function dt() {
                    return r.setTimeout((function () {
                        at = void 0
                    })), at = Date.now()
                }

                function ft(e, t) {
                    var n, r = 0, i = {height: e};
                    for (t = t ? 1 : 0; r < 4; r += 2 - t) i["margin" + (n = oe[r])] = i["padding" + n] = e;
                    return t && (i.opacity = i.width = e), i
                }

                function ht(e, t, n) {
                    for (var r, i = (pt.tweeners[t] || []).concat(pt.tweeners["*"]), o = 0, a = i.length; o < a; o++) if (r = i[o].call(n, t, e)) return r
                }

                function pt(e, t, n) {
                    var r, i, o = 0, a = pt.prefilters.length, s = S.Deferred().always((function () {
                        delete u.elem
                    })), u = function () {
                        if (i) return !1;
                        for (var t = at || dt(), n = Math.max(0, l.startTime + l.duration - t), r = 1 - (n / l.duration || 0), o = 0, a = l.tweens.length; o < a; o++) l.tweens[o].run(r);
                        return s.notifyWith(e, [l, r, n]), r < 1 && a ? n : (a || s.notifyWith(e, [l, 1, 0]), s.resolveWith(e, [l]), !1)
                    }, l = s.promise({
                        elem: e,
                        props: S.extend({}, t),
                        opts: S.extend(!0, {specialEasing: {}, easing: S.easing._default}, n),
                        originalProperties: t,
                        originalOptions: n,
                        startTime: at || dt(),
                        duration: n.duration,
                        tweens: [],
                        createTween: function (t, n) {
                            var r = S.Tween(e, l.opts, t, n, l.opts.specialEasing[t] || l.opts.easing);
                            return l.tweens.push(r), r
                        },
                        stop: function (t) {
                            var n = 0, r = t ? l.tweens.length : 0;
                            if (i) return this;
                            for (i = !0; n < r; n++) l.tweens[n].run(1);
                            return t ? (s.notifyWith(e, [l, 1, 0]), s.resolveWith(e, [l, t])) : s.rejectWith(e, [l, t]), this
                        }
                    }), c = l.props;
                    for (function (e, t) {
                        var n, r, i, o, a;
                        for (n in e) if (i = t[r = J(n)], o = e[n], Array.isArray(o) && (i = o[1], o = e[n] = o[0]), n !== r && (e[r] = o, delete e[n]), (a = S.cssHooks[r]) && "expand" in a) for (n in o = a.expand(o), delete e[r], o) n in e || (e[n] = o[n], t[n] = i); else t[r] = i
                    }(c, l.opts.specialEasing); o < a; o++) if (r = pt.prefilters[o].call(l, e, c, l.opts)) return y(r.stop) && (S._queueHooks(l.elem, l.opts.queue).stop = r.stop.bind(r)), r;
                    return S.map(c, ht, l), y(l.opts.start) && l.opts.start.call(e, l), l.progress(l.opts.progress).done(l.opts.done, l.opts.complete).fail(l.opts.fail).always(l.opts.always), S.fx.timer(S.extend(u, {
                        elem: e,
                        anim: l,
                        queue: l.opts.queue
                    })), l
                }

                S.Animation = S.extend(pt, {
                    tweeners: {
                        "*": [function (e, t) {
                            var n = this.createTween(e, t);
                            return ce(n.elem, e, ie.exec(t), n), n
                        }]
                    }, tweener: function (e, t) {
                        y(e) ? (t = e, e = ["*"]) : e = e.match(I);
                        for (var n, r = 0, i = e.length; r < i; r++) n = e[r], pt.tweeners[n] = pt.tweeners[n] || [], pt.tweeners[n].unshift(t)
                    }, prefilters: [function (e, t, n) {
                        var r, i, o, a, s, u, l, c, d = "width" in t || "height" in t, f = this, h = {}, p = e.style,
                            m = e.nodeType && le(e), g = Q.get(e, "fxshow");
                        for (r in n.queue || (null == (a = S._queueHooks(e, "fx")).unqueued && (a.unqueued = 0, s = a.empty.fire, a.empty.fire = function () {
                            a.unqueued || s()
                        }), a.unqueued++, f.always((function () {
                            f.always((function () {
                                a.unqueued--, S.queue(e, "fx").length || a.empty.fire()
                            }))
                        }))), t) if (i = t[r], ut.test(i)) {
                            if (delete t[r], o = o || "toggle" === i, i === (m ? "hide" : "show")) {
                                if ("show" !== i || !g || void 0 === g[r]) continue;
                                m = !0
                            }
                            h[r] = g && g[r] || S.style(e, r)
                        }
                        if ((u = !S.isEmptyObject(t)) || !S.isEmptyObject(h)) for (r in d && 1 === e.nodeType && (n.overflow = [p.overflow, p.overflowX, p.overflowY], null == (l = g && g.display) && (l = Q.get(e, "display")), "none" === (c = S.css(e, "display")) && (l ? c = l : (he([e], !0), l = e.style.display || l, c = S.css(e, "display"), he([e]))), ("inline" === c || "inline-block" === c && null != l) && "none" === S.css(e, "float") && (u || (f.done((function () {
                            p.display = l
                        })), null == l && (c = p.display, l = "none" === c ? "" : c)), p.display = "inline-block")), n.overflow && (p.overflow = "hidden", f.always((function () {
                            p.overflow = n.overflow[0], p.overflowX = n.overflow[1], p.overflowY = n.overflow[2]
                        }))), u = !1, h) u || (g ? "hidden" in g && (m = g.hidden) : g = Q.access(e, "fxshow", {display: l}), o && (g.hidden = !m), m && he([e], !0), f.done((function () {
                            for (r in m || he([e]), Q.remove(e, "fxshow"), h) S.style(e, r, h[r])
                        }))), u = ht(m ? g[r] : 0, r, f), r in g || (g[r] = u.start, m && (u.end = u.start, u.start = 0))
                    }], prefilter: function (e, t) {
                        t ? pt.prefilters.unshift(e) : pt.prefilters.push(e)
                    }
                }), S.speed = function (e, t, n) {
                    var r = e && "object" == typeof e ? S.extend({}, e) : {
                        complete: n || !n && t || y(e) && e,
                        duration: e,
                        easing: n && t || t && !y(t) && t
                    };
                    return S.fx.off ? r.duration = 0 : "number" != typeof r.duration && (r.duration in S.fx.speeds ? r.duration = S.fx.speeds[r.duration] : r.duration = S.fx.speeds._default), null != r.queue && !0 !== r.queue || (r.queue = "fx"), r.old = r.complete, r.complete = function () {
                        y(r.old) && r.old.call(this), r.queue && S.dequeue(this, r.queue)
                    }, r
                }, S.fn.extend({
                    fadeTo: function (e, t, n, r) {
                        return this.filter(le).css("opacity", 0).show().end().animate({opacity: t}, e, n, r)
                    }, animate: function (e, t, n, r) {
                        var i = S.isEmptyObject(e), o = S.speed(t, n, r), a = function () {
                            var t = pt(this, S.extend({}, e), o);
                            (i || Q.get(this, "finish")) && t.stop(!0)
                        };
                        return a.finish = a, i || !1 === o.queue ? this.each(a) : this.queue(o.queue, a)
                    }, stop: function (e, t, n) {
                        var r = function (e) {
                            var t = e.stop;
                            delete e.stop, t(n)
                        };
                        return "string" != typeof e && (n = t, t = e, e = void 0), t && this.queue(e || "fx", []), this.each((function () {
                            var t = !0, i = null != e && e + "queueHooks", o = S.timers, a = Q.get(this);
                            if (i) a[i] && a[i].stop && r(a[i]); else for (i in a) a[i] && a[i].stop && lt.test(i) && r(a[i]);
                            for (i = o.length; i--;) o[i].elem !== this || null != e && o[i].queue !== e || (o[i].anim.stop(n), t = !1, o.splice(i, 1));
                            !t && n || S.dequeue(this, e)
                        }))
                    }, finish: function (e) {
                        return !1 !== e && (e = e || "fx"), this.each((function () {
                            var t, n = Q.get(this), r = n[e + "queue"], i = n[e + "queueHooks"], o = S.timers,
                                a = r ? r.length : 0;
                            for (n.finish = !0, S.queue(this, e, []), i && i.stop && i.stop.call(this, !0), t = o.length; t--;) o[t].elem === this && o[t].queue === e && (o[t].anim.stop(!0), o.splice(t, 1));
                            for (t = 0; t < a; t++) r[t] && r[t].finish && r[t].finish.call(this);
                            delete n.finish
                        }))
                    }
                }), S.each(["toggle", "show", "hide"], (function (e, t) {
                    var n = S.fn[t];
                    S.fn[t] = function (e, r, i) {
                        return null == e || "boolean" == typeof e ? n.apply(this, arguments) : this.animate(ft(t, !0), e, r, i)
                    }
                })), S.each({
                    slideDown: ft("show"),
                    slideUp: ft("hide"),
                    slideToggle: ft("toggle"),
                    fadeIn: {opacity: "show"},
                    fadeOut: {opacity: "hide"},
                    fadeToggle: {opacity: "toggle"}
                }, (function (e, t) {
                    S.fn[e] = function (e, n, r) {
                        return this.animate(t, e, n, r)
                    }
                })), S.timers = [], S.fx.tick = function () {
                    var e, t = 0, n = S.timers;
                    for (at = Date.now(); t < n.length; t++) (e = n[t])() || n[t] !== e || n.splice(t--, 1);
                    n.length || S.fx.stop(), at = void 0
                }, S.fx.timer = function (e) {
                    S.timers.push(e), S.fx.start()
                }, S.fx.interval = 13, S.fx.start = function () {
                    st || (st = !0, ct())
                }, S.fx.stop = function () {
                    st = null
                }, S.fx.speeds = {slow: 600, fast: 200, _default: 400}, S.fn.delay = function (e, t) {
                    return e = S.fx && S.fx.speeds[e] || e, t = t || "fx", this.queue(t, (function (t, n) {
                        var i = r.setTimeout(t, e);
                        n.stop = function () {
                            r.clearTimeout(i)
                        }
                    }))
                }, function () {
                    var e = w.createElement("input"),
                        t = w.createElement("select").appendChild(w.createElement("option"));
                    e.type = "checkbox", g.checkOn = "" !== e.value, g.optSelected = t.selected, (e = w.createElement("input")).value = "t", e.type = "radio", g.radioValue = "t" === e.value
                }();
                var mt, gt = S.expr.attrHandle;
                S.fn.extend({
                    attr: function (e, t) {
                        return G(this, S.attr, e, t, arguments.length > 1)
                    }, removeAttr: function (e) {
                        return this.each((function () {
                            S.removeAttr(this, e)
                        }))
                    }
                }), S.extend({
                    attr: function (e, t, n) {
                        var r, i, o = e.nodeType;
                        if (3 !== o && 8 !== o && 2 !== o) return void 0 === e.getAttribute ? S.prop(e, t, n) : (1 === o && S.isXMLDoc(e) || (i = S.attrHooks[t.toLowerCase()] || (S.expr.match.bool.test(t) ? mt : void 0)), void 0 !== n ? null === n ? void S.removeAttr(e, t) : i && "set" in i && void 0 !== (r = i.set(e, n, t)) ? r : (e.setAttribute(t, n + ""), n) : i && "get" in i && null !== (r = i.get(e, t)) ? r : null == (r = S.find.attr(e, t)) ? void 0 : r)
                    }, attrHooks: {
                        type: {
                            set: function (e, t) {
                                if (!g.radioValue && "radio" === t && O(e, "input")) {
                                    var n = e.value;
                                    return e.setAttribute("type", t), n && (e.value = n), t
                                }
                            }
                        }
                    }, removeAttr: function (e, t) {
                        var n, r = 0, i = t && t.match(I);
                        if (i && 1 === e.nodeType) for (; n = i[r++];) e.removeAttribute(n)
                    }
                }), mt = {
                    set: function (e, t, n) {
                        return !1 === t ? S.removeAttr(e, n) : e.setAttribute(n, n), n
                    }
                }, S.each(S.expr.match.bool.source.match(/\w+/g), (function (e, t) {
                    var n = gt[t] || S.find.attr;
                    gt[t] = function (e, t, r) {
                        var i, o, a = t.toLowerCase();
                        return r || (o = gt[a], gt[a] = i, i = null != n(e, t, r) ? a : null, gt[a] = o), i
                    }
                }));
                var yt = /^(?:input|select|textarea|button)$/i, vt = /^(?:a|area)$/i;

                function wt(e) {
                    return (e.match(I) || []).join(" ")
                }

                function _t(e) {
                    return e.getAttribute && e.getAttribute("class") || ""
                }

                function bt(e) {
                    return Array.isArray(e) ? e : "string" == typeof e && e.match(I) || []
                }

                S.fn.extend({
                    prop: function (e, t) {
                        return G(this, S.prop, e, t, arguments.length > 1)
                    }, removeProp: function (e) {
                        return this.each((function () {
                            delete this[S.propFix[e] || e]
                        }))
                    }
                }), S.extend({
                    prop: function (e, t, n) {
                        var r, i, o = e.nodeType;
                        if (3 !== o && 8 !== o && 2 !== o) return 1 === o && S.isXMLDoc(e) || (t = S.propFix[t] || t, i = S.propHooks[t]), void 0 !== n ? i && "set" in i && void 0 !== (r = i.set(e, n, t)) ? r : e[t] = n : i && "get" in i && null !== (r = i.get(e, t)) ? r : e[t]
                    }, propHooks: {
                        tabIndex: {
                            get: function (e) {
                                var t = S.find.attr(e, "tabindex");
                                return t ? parseInt(t, 10) : yt.test(e.nodeName) || vt.test(e.nodeName) && e.href ? 0 : -1
                            }
                        }
                    }, propFix: {for: "htmlFor", class: "className"}
                }), g.optSelected || (S.propHooks.selected = {
                    get: function (e) {
                        var t = e.parentNode;
                        return t && t.parentNode && t.parentNode.selectedIndex, null
                    }, set: function (e) {
                        var t = e.parentNode;
                        t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex)
                    }
                }), S.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], (function () {
                    S.propFix[this.toLowerCase()] = this
                })), S.fn.extend({
                    addClass: function (e) {
                        var t, n, r, i, o, a;
                        return y(e) ? this.each((function (t) {
                            S(this).addClass(e.call(this, t, _t(this)))
                        })) : (t = bt(e)).length ? this.each((function () {
                            if (r = _t(this), n = 1 === this.nodeType && " " + wt(r) + " ") {
                                for (o = 0; o < t.length; o++) i = t[o], n.indexOf(" " + i + " ") < 0 && (n += i + " ");
                                a = wt(n), r !== a && this.setAttribute("class", a)
                            }
                        })) : this
                    }, removeClass: function (e) {
                        var t, n, r, i, o, a;
                        return y(e) ? this.each((function (t) {
                            S(this).removeClass(e.call(this, t, _t(this)))
                        })) : arguments.length ? (t = bt(e)).length ? this.each((function () {
                            if (r = _t(this), n = 1 === this.nodeType && " " + wt(r) + " ") {
                                for (o = 0; o < t.length; o++) for (i = t[o]; n.indexOf(" " + i + " ") > -1;) n = n.replace(" " + i + " ", " ");
                                a = wt(n), r !== a && this.setAttribute("class", a)
                            }
                        })) : this : this.attr("class", "")
                    }, toggleClass: function (e, t) {
                        var n, r, i, o, a = typeof e, s = "string" === a || Array.isArray(e);
                        return y(e) ? this.each((function (n) {
                            S(this).toggleClass(e.call(this, n, _t(this), t), t)
                        })) : "boolean" == typeof t && s ? t ? this.addClass(e) : this.removeClass(e) : (n = bt(e), this.each((function () {
                            if (s) for (o = S(this), i = 0; i < n.length; i++) r = n[i], o.hasClass(r) ? o.removeClass(r) : o.addClass(r); else void 0 !== e && "boolean" !== a || ((r = _t(this)) && Q.set(this, "__className__", r), this.setAttribute && this.setAttribute("class", r || !1 === e ? "" : Q.get(this, "__className__") || ""))
                        })))
                    }, hasClass: function (e) {
                        var t, n, r = 0;
                        for (t = " " + e + " "; n = this[r++];) if (1 === n.nodeType && (" " + wt(_t(n)) + " ").indexOf(t) > -1) return !0;
                        return !1
                    }
                });
                var xt = /\r/g;
                S.fn.extend({
                    val: function (e) {
                        var t, n, r, i = this[0];
                        return arguments.length ? (r = y(e), this.each((function (n) {
                            var i;
                            1 === this.nodeType && (null == (i = r ? e.call(this, n, S(this).val()) : e) ? i = "" : "number" == typeof i ? i += "" : Array.isArray(i) && (i = S.map(i, (function (e) {
                                return null == e ? "" : e + ""
                            }))), (t = S.valHooks[this.type] || S.valHooks[this.nodeName.toLowerCase()]) && "set" in t && void 0 !== t.set(this, i, "value") || (this.value = i))
                        }))) : i ? (t = S.valHooks[i.type] || S.valHooks[i.nodeName.toLowerCase()]) && "get" in t && void 0 !== (n = t.get(i, "value")) ? n : "string" == typeof (n = i.value) ? n.replace(xt, "") : null == n ? "" : n : void 0
                    }
                }), S.extend({
                    valHooks: {
                        option: {
                            get: function (e) {
                                var t = S.find.attr(e, "value");
                                return null != t ? t : wt(S.text(e))
                            }
                        }, select: {
                            get: function (e) {
                                var t, n, r, i = e.options, o = e.selectedIndex, a = "select-one" === e.type,
                                    s = a ? null : [], u = a ? o + 1 : i.length;
                                for (r = o < 0 ? u : a ? o : 0; r < u; r++) if (((n = i[r]).selected || r === o) && !n.disabled && (!n.parentNode.disabled || !O(n.parentNode, "optgroup"))) {
                                    if (t = S(n).val(), a) return t;
                                    s.push(t)
                                }
                                return s
                            }, set: function (e, t) {
                                for (var n, r, i = e.options, o = S.makeArray(t), a = i.length; a--;) ((r = i[a]).selected = S.inArray(S.valHooks.option.get(r), o) > -1) && (n = !0);
                                return n || (e.selectedIndex = -1), o
                            }
                        }
                    }
                }), S.each(["radio", "checkbox"], (function () {
                    S.valHooks[this] = {
                        set: function (e, t) {
                            if (Array.isArray(t)) return e.checked = S.inArray(S(e).val(), t) > -1
                        }
                    }, g.checkOn || (S.valHooks[this].get = function (e) {
                        return null === e.getAttribute("value") ? "on" : e.value
                    })
                })), g.focusin = "onfocusin" in r;
                var kt = /^(?:focusinfocus|focusoutblur)$/, St = function (e) {
                    e.stopPropagation()
                };
                S.extend(S.event, {
                    trigger: function (e, t, n, i) {
                        var o, a, s, u, l, c, d, f, p = [n || w], m = h.call(e, "type") ? e.type : e,
                            g = h.call(e, "namespace") ? e.namespace.split(".") : [];
                        if (a = f = s = n = n || w, 3 !== n.nodeType && 8 !== n.nodeType && !kt.test(m + S.event.triggered) && (m.indexOf(".") > -1 && (g = m.split("."), m = g.shift(), g.sort()), l = m.indexOf(":") < 0 && "on" + m, (e = e[S.expando] ? e : new S.Event(m, "object" == typeof e && e)).isTrigger = i ? 2 : 3, e.namespace = g.join("."), e.rnamespace = e.namespace ? new RegExp("(^|\\.)" + g.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, e.result = void 0, e.target || (e.target = n), t = null == t ? [e] : S.makeArray(t, [e]), d = S.event.special[m] || {}, i || !d.trigger || !1 !== d.trigger.apply(n, t))) {
                            if (!i && !d.noBubble && !v(n)) {
                                for (u = d.delegateType || m, kt.test(u + m) || (a = a.parentNode); a; a = a.parentNode) p.push(a), s = a;
                                s === (n.ownerDocument || w) && p.push(s.defaultView || s.parentWindow || r)
                            }
                            for (o = 0; (a = p[o++]) && !e.isPropagationStopped();) f = a, e.type = o > 1 ? u : d.bindType || m, (c = (Q.get(a, "events") || Object.create(null))[e.type] && Q.get(a, "handle")) && c.apply(a, t), (c = l && a[l]) && c.apply && Z(a) && (e.result = c.apply(a, t), !1 === e.result && e.preventDefault());
                            return e.type = m, i || e.isDefaultPrevented() || d._default && !1 !== d._default.apply(p.pop(), t) || !Z(n) || l && y(n[m]) && !v(n) && ((s = n[l]) && (n[l] = null), S.event.triggered = m, e.isPropagationStopped() && f.addEventListener(m, St), n[m](), e.isPropagationStopped() && f.removeEventListener(m, St), S.event.triggered = void 0, s && (n[l] = s)), e.result
                        }
                    }, simulate: function (e, t, n) {
                        var r = S.extend(new S.Event, n, {type: e, isSimulated: !0});
                        S.event.trigger(r, null, t)
                    }
                }), S.fn.extend({
                    trigger: function (e, t) {
                        return this.each((function () {
                            S.event.trigger(e, t, this)
                        }))
                    }, triggerHandler: function (e, t) {
                        var n = this[0];
                        if (n) return S.event.trigger(e, t, n, !0)
                    }
                }), g.focusin || S.each({focus: "focusin", blur: "focusout"}, (function (e, t) {
                    var n = function (e) {
                        S.event.simulate(t, e.target, S.event.fix(e))
                    };
                    S.event.special[t] = {
                        setup: function () {
                            var r = this.ownerDocument || this.document || this, i = Q.access(r, t);
                            i || r.addEventListener(e, n, !0), Q.access(r, t, (i || 0) + 1)
                        }, teardown: function () {
                            var r = this.ownerDocument || this.document || this, i = Q.access(r, t) - 1;
                            i ? Q.access(r, t, i) : (r.removeEventListener(e, n, !0), Q.remove(r, t))
                        }
                    }
                }));
                var Tt = r.location, Dt = {guid: Date.now()}, Ct = /\?/;
                S.parseXML = function (e) {
                    var t, n;
                    if (!e || "string" != typeof e) return null;
                    try {
                        t = (new r.DOMParser).parseFromString(e, "text/xml")
                    } catch (e) {
                    }
                    return n = t && t.getElementsByTagName("parsererror")[0], t && !n || S.error("Invalid XML: " + (n ? S.map(n.childNodes, (function (e) {
                        return e.textContent
                    })).join("\n") : e)), t
                };
                var Mt = /\[\]$/, Nt = /\r?\n/g, Ot = /^(?:submit|button|image|reset|file)$/i,
                    Et = /^(?:input|select|textarea|keygen)/i;

                function At(e, t, n, r) {
                    var i;
                    if (Array.isArray(t)) S.each(t, (function (t, i) {
                        n || Mt.test(e) ? r(e, i) : At(e + "[" + ("object" == typeof i && null != i ? t : "") + "]", i, n, r)
                    })); else if (n || "object" !== x(t)) r(e, t); else for (i in t) At(e + "[" + i + "]", t[i], n, r)
                }

                S.param = function (e, t) {
                    var n, r = [], i = function (e, t) {
                        var n = y(t) ? t() : t;
                        r[r.length] = encodeURIComponent(e) + "=" + encodeURIComponent(null == n ? "" : n)
                    };
                    if (null == e) return "";
                    if (Array.isArray(e) || e.jquery && !S.isPlainObject(e)) S.each(e, (function () {
                        i(this.name, this.value)
                    })); else for (n in e) At(n, e[n], t, i);
                    return r.join("&")
                }, S.fn.extend({
                    serialize: function () {
                        return S.param(this.serializeArray())
                    }, serializeArray: function () {
                        return this.map((function () {
                            var e = S.prop(this, "elements");
                            return e ? S.makeArray(e) : this
                        })).filter((function () {
                            var e = this.type;
                            return this.name && !S(this).is(":disabled") && Et.test(this.nodeName) && !Ot.test(e) && (this.checked || !ge.test(e))
                        })).map((function (e, t) {
                            var n = S(this).val();
                            return null == n ? null : Array.isArray(n) ? S.map(n, (function (e) {
                                return {name: t.name, value: e.replace(Nt, "\r\n")}
                            })) : {name: t.name, value: n.replace(Nt, "\r\n")}
                        })).get()
                    }
                });
                var jt = /%20/g, Pt = /#.*$/, Rt = /([?&])_=[^&]*/, Yt = /^(.*?):[ \t]*([^\r\n]*)$/gm,
                    Lt = /^(?:GET|HEAD)$/, It = /^\/\//, Ht = {}, Ft = {}, Ut = "*/".concat("*"),
                    Wt = w.createElement("a");

                function qt(e) {
                    return function (t, n) {
                        "string" != typeof t && (n = t, t = "*");
                        var r, i = 0, o = t.toLowerCase().match(I) || [];
                        if (y(n)) for (; r = o[i++];) "+" === r[0] ? (r = r.slice(1) || "*", (e[r] = e[r] || []).unshift(n)) : (e[r] = e[r] || []).push(n)
                    }
                }

                function Bt(e, t, n, r) {
                    var i = {}, o = e === Ft;

                    function a(s) {
                        var u;
                        return i[s] = !0, S.each(e[s] || [], (function (e, s) {
                            var l = s(t, n, r);
                            return "string" != typeof l || o || i[l] ? o ? !(u = l) : void 0 : (t.dataTypes.unshift(l), a(l), !1)
                        })), u
                    }

                    return a(t.dataTypes[0]) || !i["*"] && a("*")
                }

                function Gt(e, t) {
                    var n, r, i = S.ajaxSettings.flatOptions || {};
                    for (n in t) void 0 !== t[n] && ((i[n] ? e : r || (r = {}))[n] = t[n]);
                    return r && S.extend(!0, e, r), e
                }

                Wt.href = Tt.href, S.extend({
                    active: 0,
                    lastModified: {},
                    etag: {},
                    ajaxSettings: {
                        url: Tt.href,
                        type: "GET",
                        isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(Tt.protocol),
                        global: !0,
                        processData: !0,
                        async: !0,
                        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                        accepts: {
                            "*": Ut,
                            text: "text/plain",
                            html: "text/html",
                            xml: "application/xml, text/xml",
                            json: "application/json, text/javascript"
                        },
                        contents: {xml: /\bxml\b/, html: /\bhtml/, json: /\bjson\b/},
                        responseFields: {xml: "responseXML", text: "responseText", json: "responseJSON"},
                        converters: {
                            "* text": String,
                            "text html": !0,
                            "text json": JSON.parse,
                            "text xml": S.parseXML
                        },
                        flatOptions: {url: !0, context: !0}
                    },
                    ajaxSetup: function (e, t) {
                        return t ? Gt(Gt(e, S.ajaxSettings), t) : Gt(S.ajaxSettings, e)
                    },
                    ajaxPrefilter: qt(Ht),
                    ajaxTransport: qt(Ft),
                    ajax: function (e, t) {
                        "object" == typeof e && (t = e, e = void 0), t = t || {};
                        var n, i, o, a, s, u, l, c, d, f, h = S.ajaxSetup({}, t), p = h.context || h,
                            m = h.context && (p.nodeType || p.jquery) ? S(p) : S.event, g = S.Deferred(),
                            y = S.Callbacks("once memory"), v = h.statusCode || {}, _ = {}, b = {}, x = "canceled",
                            k = {
                                readyState: 0, getResponseHeader: function (e) {
                                    var t;
                                    if (l) {
                                        if (!a) for (a = {}; t = Yt.exec(o);) a[t[1].toLowerCase() + " "] = (a[t[1].toLowerCase() + " "] || []).concat(t[2]);
                                        t = a[e.toLowerCase() + " "]
                                    }
                                    return null == t ? null : t.join(", ")
                                }, getAllResponseHeaders: function () {
                                    return l ? o : null
                                }, setRequestHeader: function (e, t) {
                                    return null == l && (e = b[e.toLowerCase()] = b[e.toLowerCase()] || e, _[e] = t), this
                                }, overrideMimeType: function (e) {
                                    return null == l && (h.mimeType = e), this
                                }, statusCode: function (e) {
                                    var t;
                                    if (e) if (l) k.always(e[k.status]); else for (t in e) v[t] = [v[t], e[t]];
                                    return this
                                }, abort: function (e) {
                                    var t = e || x;
                                    return n && n.abort(t), T(0, t), this
                                }
                            };
                        if (g.promise(k), h.url = ((e || h.url || Tt.href) + "").replace(It, Tt.protocol + "//"), h.type = t.method || t.type || h.method || h.type, h.dataTypes = (h.dataType || "*").toLowerCase().match(I) || [""], null == h.crossDomain) {
                            u = w.createElement("a");
                            try {
                                u.href = h.url, u.href = u.href, h.crossDomain = Wt.protocol + "//" + Wt.host != u.protocol + "//" + u.host
                            } catch (e) {
                                h.crossDomain = !0
                            }
                        }
                        if (h.data && h.processData && "string" != typeof h.data && (h.data = S.param(h.data, h.traditional)), Bt(Ht, h, t, k), l) return k;
                        for (d in (c = S.event && h.global) && 0 == S.active++ && S.event.trigger("ajaxStart"), h.type = h.type.toUpperCase(), h.hasContent = !Lt.test(h.type), i = h.url.replace(Pt, ""), h.hasContent ? h.data && h.processData && 0 === (h.contentType || "").indexOf("application/x-www-form-urlencoded") && (h.data = h.data.replace(jt, "+")) : (f = h.url.slice(i.length), h.data && (h.processData || "string" == typeof h.data) && (i += (Ct.test(i) ? "&" : "?") + h.data, delete h.data), !1 === h.cache && (i = i.replace(Rt, "$1"), f = (Ct.test(i) ? "&" : "?") + "_=" + Dt.guid++ + f), h.url = i + f), h.ifModified && (S.lastModified[i] && k.setRequestHeader("If-Modified-Since", S.lastModified[i]), S.etag[i] && k.setRequestHeader("If-None-Match", S.etag[i])), (h.data && h.hasContent && !1 !== h.contentType || t.contentType) && k.setRequestHeader("Content-Type", h.contentType), k.setRequestHeader("Accept", h.dataTypes[0] && h.accepts[h.dataTypes[0]] ? h.accepts[h.dataTypes[0]] + ("*" !== h.dataTypes[0] ? ", " + Ut + "; q=0.01" : "") : h.accepts["*"]), h.headers) k.setRequestHeader(d, h.headers[d]);
                        if (h.beforeSend && (!1 === h.beforeSend.call(p, k, h) || l)) return k.abort();
                        if (x = "abort", y.add(h.complete), k.done(h.success), k.fail(h.error), n = Bt(Ft, h, t, k)) {
                            if (k.readyState = 1, c && m.trigger("ajaxSend", [k, h]), l) return k;
                            h.async && h.timeout > 0 && (s = r.setTimeout((function () {
                                k.abort("timeout")
                            }), h.timeout));
                            try {
                                l = !1, n.send(_, T)
                            } catch (e) {
                                if (l) throw e;
                                T(-1, e)
                            }
                        } else T(-1, "No Transport");

                        function T(e, t, a, u) {
                            var d, f, w, _, b, x = t;
                            l || (l = !0, s && r.clearTimeout(s), n = void 0, o = u || "", k.readyState = e > 0 ? 4 : 0, d = e >= 200 && e < 300 || 304 === e, a && (_ = function (e, t, n) {
                                for (var r, i, o, a, s = e.contents, u = e.dataTypes; "*" === u[0];) u.shift(), void 0 === r && (r = e.mimeType || t.getResponseHeader("Content-Type"));
                                if (r) for (i in s) if (s[i] && s[i].test(r)) {
                                    u.unshift(i);
                                    break
                                }
                                if (u[0] in n) o = u[0]; else {
                                    for (i in n) {
                                        if (!u[0] || e.converters[i + " " + u[0]]) {
                                            o = i;
                                            break
                                        }
                                        a || (a = i)
                                    }
                                    o = o || a
                                }
                                if (o) return o !== u[0] && u.unshift(o), n[o]
                            }(h, k, a)), !d && S.inArray("script", h.dataTypes) > -1 && S.inArray("json", h.dataTypes) < 0 && (h.converters["text script"] = function () {
                            }), _ = function (e, t, n, r) {
                                var i, o, a, s, u, l = {}, c = e.dataTypes.slice();
                                if (c[1]) for (a in e.converters) l[a.toLowerCase()] = e.converters[a];
                                for (o = c.shift(); o;) if (e.responseFields[o] && (n[e.responseFields[o]] = t), !u && r && e.dataFilter && (t = e.dataFilter(t, e.dataType)), u = o, o = c.shift()) if ("*" === o) o = u; else if ("*" !== u && u !== o) {
                                    if (!(a = l[u + " " + o] || l["* " + o])) for (i in l) if ((s = i.split(" "))[1] === o && (a = l[u + " " + s[0]] || l["* " + s[0]])) {
                                        !0 === a ? a = l[i] : !0 !== l[i] && (o = s[0], c.unshift(s[1]));
                                        break
                                    }
                                    if (!0 !== a) if (a && e.throws) t = a(t); else try {
                                        t = a(t)
                                    } catch (e) {
                                        return {
                                            state: "parsererror",
                                            error: a ? e : "No conversion from " + u + " to " + o
                                        }
                                    }
                                }
                                return {state: "success", data: t}
                            }(h, _, k, d), d ? (h.ifModified && ((b = k.getResponseHeader("Last-Modified")) && (S.lastModified[i] = b), (b = k.getResponseHeader("etag")) && (S.etag[i] = b)), 204 === e || "HEAD" === h.type ? x = "nocontent" : 304 === e ? x = "notmodified" : (x = _.state, f = _.data, d = !(w = _.error))) : (w = x, !e && x || (x = "error", e < 0 && (e = 0))), k.status = e, k.statusText = (t || x) + "", d ? g.resolveWith(p, [f, x, k]) : g.rejectWith(p, [k, x, w]), k.statusCode(v), v = void 0, c && m.trigger(d ? "ajaxSuccess" : "ajaxError", [k, h, d ? f : w]), y.fireWith(p, [k, x]), c && (m.trigger("ajaxComplete", [k, h]), --S.active || S.event.trigger("ajaxStop")))
                        }

                        return k
                    },
                    getJSON: function (e, t, n) {
                        return S.get(e, t, n, "json")
                    },
                    getScript: function (e, t) {
                        return S.get(e, void 0, t, "script")
                    }
                }), S.each(["get", "post"], (function (e, t) {
                    S[t] = function (e, n, r, i) {
                        return y(n) && (i = i || r, r = n, n = void 0), S.ajax(S.extend({
                            url: e,
                            type: t,
                            dataType: i,
                            data: n,
                            success: r
                        }, S.isPlainObject(e) && e))
                    }
                })), S.ajaxPrefilter((function (e) {
                    var t;
                    for (t in e.headers) "content-type" === t.toLowerCase() && (e.contentType = e.headers[t] || "")
                })), S._evalUrl = function (e, t, n) {
                    return S.ajax({
                        url: e,
                        type: "GET",
                        dataType: "script",
                        cache: !0,
                        async: !1,
                        global: !1,
                        converters: {
                            "text script": function () {
                            }
                        },
                        dataFilter: function (e) {
                            S.globalEval(e, t, n)
                        }
                    })
                }, S.fn.extend({
                    wrapAll: function (e) {
                        var t;
                        return this[0] && (y(e) && (e = e.call(this[0])), t = S(e, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && t.insertBefore(this[0]), t.map((function () {
                            for (var e = this; e.firstElementChild;) e = e.firstElementChild;
                            return e
                        })).append(this)), this
                    }, wrapInner: function (e) {
                        return y(e) ? this.each((function (t) {
                            S(this).wrapInner(e.call(this, t))
                        })) : this.each((function () {
                            var t = S(this), n = t.contents();
                            n.length ? n.wrapAll(e) : t.append(e)
                        }))
                    }, wrap: function (e) {
                        var t = y(e);
                        return this.each((function (n) {
                            S(this).wrapAll(t ? e.call(this, n) : e)
                        }))
                    }, unwrap: function (e) {
                        return this.parent(e).not("body").each((function () {
                            S(this).replaceWith(this.childNodes)
                        })), this
                    }
                }), S.expr.pseudos.hidden = function (e) {
                    return !S.expr.pseudos.visible(e)
                }, S.expr.pseudos.visible = function (e) {
                    return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)
                }, S.ajaxSettings.xhr = function () {
                    try {
                        return new r.XMLHttpRequest
                    } catch (e) {
                    }
                };
                var Vt = {0: 200, 1223: 204}, $t = S.ajaxSettings.xhr();
                g.cors = !!$t && "withCredentials" in $t, g.ajax = $t = !!$t, S.ajaxTransport((function (e) {
                    var t, n;
                    if (g.cors || $t && !e.crossDomain) return {
                        send: function (i, o) {
                            var a, s = e.xhr();
                            if (s.open(e.type, e.url, e.async, e.username, e.password), e.xhrFields) for (a in e.xhrFields) s[a] = e.xhrFields[a];
                            for (a in e.mimeType && s.overrideMimeType && s.overrideMimeType(e.mimeType), e.crossDomain || i["X-Requested-With"] || (i["X-Requested-With"] = "XMLHttpRequest"), i) s.setRequestHeader(a, i[a]);
                            t = function (e) {
                                return function () {
                                    t && (t = n = s.onload = s.onerror = s.onabort = s.ontimeout = s.onreadystatechange = null, "abort" === e ? s.abort() : "error" === e ? "number" != typeof s.status ? o(0, "error") : o(s.status, s.statusText) : o(Vt[s.status] || s.status, s.statusText, "text" !== (s.responseType || "text") || "string" != typeof s.responseText ? {binary: s.response} : {text: s.responseText}, s.getAllResponseHeaders()))
                                }
                            }, s.onload = t(), n = s.onerror = s.ontimeout = t("error"), void 0 !== s.onabort ? s.onabort = n : s.onreadystatechange = function () {
                                4 === s.readyState && r.setTimeout((function () {
                                    t && n()
                                }))
                            }, t = t("abort");
                            try {
                                s.send(e.hasContent && e.data || null)
                            } catch (e) {
                                if (t) throw e
                            }
                        }, abort: function () {
                            t && t()
                        }
                    }
                })), S.ajaxPrefilter((function (e) {
                    e.crossDomain && (e.contents.script = !1)
                })), S.ajaxSetup({
                    accepts: {script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},
                    contents: {script: /\b(?:java|ecma)script\b/},
                    converters: {
                        "text script": function (e) {
                            return S.globalEval(e), e
                        }
                    }
                }), S.ajaxPrefilter("script", (function (e) {
                    void 0 === e.cache && (e.cache = !1), e.crossDomain && (e.type = "GET")
                })), S.ajaxTransport("script", (function (e) {
                    var t, n;
                    if (e.crossDomain || e.scriptAttrs) return {
                        send: function (r, i) {
                            t = S("<script>").attr(e.scriptAttrs || {}).prop({
                                charset: e.scriptCharset,
                                src: e.url
                            }).on("load error", n = function (e) {
                                t.remove(), n = null, e && i("error" === e.type ? 404 : 200, e.type)
                            }), w.head.appendChild(t[0])
                        }, abort: function () {
                            n && n()
                        }
                    }
                }));
                var zt, Jt = [], Zt = /(=)\?(?=&|$)|\?\?/;
                S.ajaxSetup({
                    jsonp: "callback", jsonpCallback: function () {
                        var e = Jt.pop() || S.expando + "_" + Dt.guid++;
                        return this[e] = !0, e
                    }
                }), S.ajaxPrefilter("json jsonp", (function (e, t, n) {
                    var i, o, a,
                        s = !1 !== e.jsonp && (Zt.test(e.url) ? "url" : "string" == typeof e.data && 0 === (e.contentType || "").indexOf("application/x-www-form-urlencoded") && Zt.test(e.data) && "data");
                    if (s || "jsonp" === e.dataTypes[0]) return i = e.jsonpCallback = y(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback, s ? e[s] = e[s].replace(Zt, "$1" + i) : !1 !== e.jsonp && (e.url += (Ct.test(e.url) ? "&" : "?") + e.jsonp + "=" + i), e.converters["script json"] = function () {
                        return a || S.error(i + " was not called"), a[0]
                    }, e.dataTypes[0] = "json", o = r[i], r[i] = function () {
                        a = arguments
                    }, n.always((function () {
                        void 0 === o ? S(r).removeProp(i) : r[i] = o, e[i] && (e.jsonpCallback = t.jsonpCallback, Jt.push(i)), a && y(o) && o(a[0]), a = o = void 0
                    })), "script"
                })), g.createHTMLDocument = ((zt = w.implementation.createHTMLDocument("").body).innerHTML = "<form></form><form></form>", 2 === zt.childNodes.length), S.parseHTML = function (e, t, n) {
                    return "string" != typeof e ? [] : ("boolean" == typeof t && (n = t, t = !1), t || (g.createHTMLDocument ? ((r = (t = w.implementation.createHTMLDocument("")).createElement("base")).href = w.location.href, t.head.appendChild(r)) : t = w), o = !n && [], (i = E.exec(e)) ? [t.createElement(i[1])] : (i = ke([e], t, o), o && o.length && S(o).remove(), S.merge([], i.childNodes)));
                    var r, i, o
                }, S.fn.load = function (e, t, n) {
                    var r, i, o, a = this, s = e.indexOf(" ");
                    return s > -1 && (r = wt(e.slice(s)), e = e.slice(0, s)), y(t) ? (n = t, t = void 0) : t && "object" == typeof t && (i = "POST"), a.length > 0 && S.ajax({
                        url: e,
                        type: i || "GET",
                        dataType: "html",
                        data: t
                    }).done((function (e) {
                        o = arguments, a.html(r ? S("<div>").append(S.parseHTML(e)).find(r) : e)
                    })).always(n && function (e, t) {
                        a.each((function () {
                            n.apply(this, o || [e.responseText, t, e])
                        }))
                    }), this
                }, S.expr.pseudos.animated = function (e) {
                    return S.grep(S.timers, (function (t) {
                        return e === t.elem
                    })).length
                }, S.offset = {
                    setOffset: function (e, t, n) {
                        var r, i, o, a, s, u, l = S.css(e, "position"), c = S(e), d = {};
                        "static" === l && (e.style.position = "relative"), s = c.offset(), o = S.css(e, "top"), u = S.css(e, "left"), ("absolute" === l || "fixed" === l) && (o + u).indexOf("auto") > -1 ? (a = (r = c.position()).top, i = r.left) : (a = parseFloat(o) || 0, i = parseFloat(u) || 0), y(t) && (t = t.call(e, n, S.extend({}, s))), null != t.top && (d.top = t.top - s.top + a), null != t.left && (d.left = t.left - s.left + i), "using" in t ? t.using.call(e, d) : c.css(d)
                    }
                }, S.fn.extend({
                    offset: function (e) {
                        if (arguments.length) return void 0 === e ? this : this.each((function (t) {
                            S.offset.setOffset(this, e, t)
                        }));
                        var t, n, r = this[0];
                        return r ? r.getClientRects().length ? (t = r.getBoundingClientRect(), n = r.ownerDocument.defaultView, {
                            top: t.top + n.pageYOffset,
                            left: t.left + n.pageXOffset
                        }) : {top: 0, left: 0} : void 0
                    }, position: function () {
                        if (this[0]) {
                            var e, t, n, r = this[0], i = {top: 0, left: 0};
                            if ("fixed" === S.css(r, "position")) t = r.getBoundingClientRect(); else {
                                for (t = this.offset(), n = r.ownerDocument, e = r.offsetParent || n.documentElement; e && (e === n.body || e === n.documentElement) && "static" === S.css(e, "position");) e = e.parentNode;
                                e && e !== r && 1 === e.nodeType && ((i = S(e).offset()).top += S.css(e, "borderTopWidth", !0), i.left += S.css(e, "borderLeftWidth", !0))
                            }
                            return {
                                top: t.top - i.top - S.css(r, "marginTop", !0),
                                left: t.left - i.left - S.css(r, "marginLeft", !0)
                            }
                        }
                    }, offsetParent: function () {
                        return this.map((function () {
                            for (var e = this.offsetParent; e && "static" === S.css(e, "position");) e = e.offsetParent;
                            return e || ae
                        }))
                    }
                }), S.each({scrollLeft: "pageXOffset", scrollTop: "pageYOffset"}, (function (e, t) {
                    var n = "pageYOffset" === t;
                    S.fn[e] = function (r) {
                        return G(this, (function (e, r, i) {
                            var o;
                            if (v(e) ? o = e : 9 === e.nodeType && (o = e.defaultView), void 0 === i) return o ? o[t] : e[r];
                            o ? o.scrollTo(n ? o.pageXOffset : i, n ? i : o.pageYOffset) : e[r] = i
                        }), e, r, arguments.length)
                    }
                })), S.each(["top", "left"], (function (e, t) {
                    S.cssHooks[t] = ze(g.pixelPosition, (function (e, n) {
                        if (n) return n = $e(e, t), Fe.test(n) ? S(e).position()[t] + "px" : n
                    }))
                })), S.each({Height: "height", Width: "width"}, (function (e, t) {
                    S.each({padding: "inner" + e, content: t, "": "outer" + e}, (function (n, r) {
                        S.fn[r] = function (i, o) {
                            var a = arguments.length && (n || "boolean" != typeof i),
                                s = n || (!0 === i || !0 === o ? "margin" : "border");
                            return G(this, (function (t, n, i) {
                                var o;
                                return v(t) ? 0 === r.indexOf("outer") ? t["inner" + e] : t.document.documentElement["client" + e] : 9 === t.nodeType ? (o = t.documentElement, Math.max(t.body["scroll" + e], o["scroll" + e], t.body["offset" + e], o["offset" + e], o["client" + e])) : void 0 === i ? S.css(t, n, s) : S.style(t, n, i, s)
                            }), t, a ? i : void 0, a)
                        }
                    }))
                })), S.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], (function (e, t) {
                    S.fn[t] = function (e) {
                        return this.on(t, e)
                    }
                })), S.fn.extend({
                    bind: function (e, t, n) {
                        return this.on(e, null, t, n)
                    }, unbind: function (e, t) {
                        return this.off(e, null, t)
                    }, delegate: function (e, t, n, r) {
                        return this.on(t, e, n, r)
                    }, undelegate: function (e, t, n) {
                        return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
                    }, hover: function (e, t) {
                        return this.mouseenter(e).mouseleave(t || e)
                    }
                }), S.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), (function (e, t) {
                    S.fn[t] = function (e, n) {
                        return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
                    }
                }));
                var Xt = /^[\s\uFEFF\xA0]+|([^\s\uFEFF\xA0])[\s\uFEFF\xA0]+$/g;
                S.proxy = function (e, t) {
                    var n, r, i;
                    if ("string" == typeof t && (n = e[t], t = e, e = n), y(e)) return r = s.call(arguments, 2), i = function () {
                        return e.apply(t || this, r.concat(s.call(arguments)))
                    }, i.guid = e.guid = e.guid || S.guid++, i
                }, S.holdReady = function (e) {
                    e ? S.readyWait++ : S.ready(!0)
                }, S.isArray = Array.isArray, S.parseJSON = JSON.parse, S.nodeName = O, S.isFunction = y, S.isWindow = v, S.camelCase = J, S.type = x, S.now = Date.now, S.isNumeric = function (e) {
                    var t = S.type(e);
                    return ("number" === t || "string" === t) && !isNaN(e - parseFloat(e))
                }, S.trim = function (e) {
                    return null == e ? "" : (e + "").replace(Xt, "$1")
                }, void 0 === (n = function () {
                    return S
                }.apply(t, [])) || (e.exports = n);
                var Qt = r.jQuery, Kt = r.$;
                return S.noConflict = function (e) {
                    return r.$ === S && (r.$ = Kt), e && r.jQuery === S && (r.jQuery = Qt), S
                }, void 0 === i && (r.jQuery = r.$ = S), S
            }))
        }, 381: function (e, t, n) {
            (e = n.nmd(e)).exports = function () {
                "use strict";
                var t, n;

                function r() {
                    return t.apply(null, arguments)
                }

                function i(e) {
                    return e instanceof Array || "[object Array]" === Object.prototype.toString.call(e)
                }

                function o(e) {
                    return null != e && "[object Object]" === Object.prototype.toString.call(e)
                }

                function a(e, t) {
                    return Object.prototype.hasOwnProperty.call(e, t)
                }

                function s(e) {
                    if (Object.getOwnPropertyNames) return 0 === Object.getOwnPropertyNames(e).length;
                    var t;
                    for (t in e) if (a(e, t)) return !1;
                    return !0
                }

                function u(e) {
                    return void 0 === e
                }

                function l(e) {
                    return "number" == typeof e || "[object Number]" === Object.prototype.toString.call(e)
                }

                function c(e) {
                    return e instanceof Date || "[object Date]" === Object.prototype.toString.call(e)
                }

                function d(e, t) {
                    var n, r = [], i = e.length;
                    for (n = 0; n < i; ++n) r.push(t(e[n], n));
                    return r
                }

                function f(e, t) {
                    for (var n in t) a(t, n) && (e[n] = t[n]);
                    return a(t, "toString") && (e.toString = t.toString), a(t, "valueOf") && (e.valueOf = t.valueOf), e
                }

                function h(e, t, n, r) {
                    return jt(e, t, n, r, !0).utc()
                }

                function p(e) {
                    return null == e._pf && (e._pf = {
                        empty: !1,
                        unusedTokens: [],
                        unusedInput: [],
                        overflow: -2,
                        charsLeftOver: 0,
                        nullInput: !1,
                        invalidEra: null,
                        invalidMonth: null,
                        invalidFormat: !1,
                        userInvalidated: !1,
                        iso: !1,
                        parsedDateParts: [],
                        era: null,
                        meridiem: null,
                        rfc2822: !1,
                        weekdayMismatch: !1
                    }), e._pf
                }

                function m(e) {
                    if (null == e._isValid) {
                        var t = p(e), r = n.call(t.parsedDateParts, (function (e) {
                                return null != e
                            })),
                            i = !isNaN(e._d.getTime()) && t.overflow < 0 && !t.empty && !t.invalidEra && !t.invalidMonth && !t.invalidWeekday && !t.weekdayMismatch && !t.nullInput && !t.invalidFormat && !t.userInvalidated && (!t.meridiem || t.meridiem && r);
                        if (e._strict && (i = i && 0 === t.charsLeftOver && 0 === t.unusedTokens.length && void 0 === t.bigHour), null != Object.isFrozen && Object.isFrozen(e)) return i;
                        e._isValid = i
                    }
                    return e._isValid
                }

                function g(e) {
                    var t = h(NaN);
                    return null != e ? f(p(t), e) : p(t).userInvalidated = !0, t
                }

                n = Array.prototype.some ? Array.prototype.some : function (e) {
                    var t, n = Object(this), r = n.length >>> 0;
                    for (t = 0; t < r; t++) if (t in n && e.call(this, n[t], t, n)) return !0;
                    return !1
                };
                var y = r.momentProperties = [], v = !1;

                function w(e, t) {
                    var n, r, i, o = y.length;
                    if (u(t._isAMomentObject) || (e._isAMomentObject = t._isAMomentObject), u(t._i) || (e._i = t._i), u(t._f) || (e._f = t._f), u(t._l) || (e._l = t._l), u(t._strict) || (e._strict = t._strict), u(t._tzm) || (e._tzm = t._tzm), u(t._isUTC) || (e._isUTC = t._isUTC), u(t._offset) || (e._offset = t._offset), u(t._pf) || (e._pf = p(t)), u(t._locale) || (e._locale = t._locale), o > 0) for (n = 0; n < o; n++) u(i = t[r = y[n]]) || (e[r] = i);
                    return e
                }

                function _(e) {
                    w(this, e), this._d = new Date(null != e._d ? e._d.getTime() : NaN), this.isValid() || (this._d = new Date(NaN)), !1 === v && (v = !0, r.updateOffset(this), v = !1)
                }

                function b(e) {
                    return e instanceof _ || null != e && null != e._isAMomentObject
                }

                function x(e) {
                    !1 === r.suppressDeprecationWarnings && "undefined" != typeof console && console.warn && console.warn("Deprecation warning: " + e)
                }

                function k(e, t) {
                    var n = !0;
                    return f((function () {
                        if (null != r.deprecationHandler && r.deprecationHandler(null, e), n) {
                            var i, o, s, u = [], l = arguments.length;
                            for (o = 0; o < l; o++) {
                                if (i = "", "object" == typeof arguments[o]) {
                                    for (s in i += "\n[" + o + "] ", arguments[0]) a(arguments[0], s) && (i += s + ": " + arguments[0][s] + ", ");
                                    i = i.slice(0, -2)
                                } else i = arguments[o];
                                u.push(i)
                            }
                            x(e + "\nArguments: " + Array.prototype.slice.call(u).join("") + "\n" + (new Error).stack), n = !1
                        }
                        return t.apply(this, arguments)
                    }), t)
                }

                var S, T = {};

                function D(e, t) {
                    null != r.deprecationHandler && r.deprecationHandler(e, t), T[e] || (x(t), T[e] = !0)
                }

                function C(e) {
                    return "undefined" != typeof Function && e instanceof Function || "[object Function]" === Object.prototype.toString.call(e)
                }

                function M(e, t) {
                    var n, r = f({}, e);
                    for (n in t) a(t, n) && (o(e[n]) && o(t[n]) ? (r[n] = {}, f(r[n], e[n]), f(r[n], t[n])) : null != t[n] ? r[n] = t[n] : delete r[n]);
                    for (n in e) a(e, n) && !a(t, n) && o(e[n]) && (r[n] = f({}, r[n]));
                    return r
                }

                function N(e) {
                    null != e && this.set(e)
                }

                r.suppressDeprecationWarnings = !1, r.deprecationHandler = null, S = Object.keys ? Object.keys : function (e) {
                    var t, n = [];
                    for (t in e) a(e, t) && n.push(t);
                    return n
                };

                function O(e, t, n) {
                    var r = "" + Math.abs(e), i = t - r.length;
                    return (e >= 0 ? n ? "+" : "" : "-") + Math.pow(10, Math.max(0, i)).toString().substr(1) + r
                }

                var E = /(\[[^\[]*\])|(\\)?([Hh]mm(ss)?|Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Qo?|N{1,5}|YYYYYY|YYYYY|YYYY|YY|y{2,4}|yo?|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|kk?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g,
                    A = /(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g, j = {}, P = {};

                function R(e, t, n, r) {
                    var i = r;
                    "string" == typeof r && (i = function () {
                        return this[r]()
                    }), e && (P[e] = i), t && (P[t[0]] = function () {
                        return O(i.apply(this, arguments), t[1], t[2])
                    }), n && (P[n] = function () {
                        return this.localeData().ordinal(i.apply(this, arguments), e)
                    })
                }

                function Y(e, t) {
                    return e.isValid() ? (t = L(t, e.localeData()), j[t] = j[t] || function (e) {
                        var t, n, r, i = e.match(E);
                        for (t = 0, n = i.length; t < n; t++) P[i[t]] ? i[t] = P[i[t]] : i[t] = (r = i[t]).match(/\[[\s\S]/) ? r.replace(/^\[|\]$/g, "") : r.replace(/\\/g, "");
                        return function (t) {
                            var r, o = "";
                            for (r = 0; r < n; r++) o += C(i[r]) ? i[r].call(t, e) : i[r];
                            return o
                        }
                    }(t), j[t](e)) : e.localeData().invalidDate()
                }

                function L(e, t) {
                    var n = 5;

                    function r(e) {
                        return t.longDateFormat(e) || e
                    }

                    for (A.lastIndex = 0; n >= 0 && A.test(e);) e = e.replace(A, r), A.lastIndex = 0, n -= 1;
                    return e
                }

                var I = {};

                function H(e, t) {
                    var n = e.toLowerCase();
                    I[n] = I[n + "s"] = I[t] = e
                }

                function F(e) {
                    return "string" == typeof e ? I[e] || I[e.toLowerCase()] : void 0
                }

                function U(e) {
                    var t, n, r = {};
                    for (n in e) a(e, n) && (t = F(n)) && (r[t] = e[n]);
                    return r
                }

                var W = {};

                function q(e, t) {
                    W[e] = t
                }

                function B(e) {
                    return e % 4 == 0 && e % 100 != 0 || e % 400 == 0
                }

                function G(e) {
                    return e < 0 ? Math.ceil(e) || 0 : Math.floor(e)
                }

                function V(e) {
                    var t = +e, n = 0;
                    return 0 !== t && isFinite(t) && (n = G(t)), n
                }

                function $(e, t) {
                    return function (n) {
                        return null != n ? (J(this, e, n), r.updateOffset(this, t), this) : z(this, e)
                    }
                }

                function z(e, t) {
                    return e.isValid() ? e._d["get" + (e._isUTC ? "UTC" : "") + t]() : NaN
                }

                function J(e, t, n) {
                    e.isValid() && !isNaN(n) && ("FullYear" === t && B(e.year()) && 1 === e.month() && 29 === e.date() ? (n = V(n), e._d["set" + (e._isUTC ? "UTC" : "") + t](n, e.month(), Oe(n, e.month()))) : e._d["set" + (e._isUTC ? "UTC" : "") + t](n))
                }

                var Z, X = /\d/, Q = /\d\d/, K = /\d{3}/, ee = /\d{4}/, te = /[+-]?\d{6}/, ne = /\d\d?/,
                    re = /\d\d\d\d?/, ie = /\d\d\d\d\d\d?/, oe = /\d{1,3}/, ae = /\d{1,4}/, se = /[+-]?\d{1,6}/,
                    ue = /\d+/, le = /[+-]?\d+/, ce = /Z|[+-]\d\d:?\d\d/gi, de = /Z|[+-]\d\d(?::?\d\d)?/gi,
                    fe = /[0-9]{0,256}['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFF07\uFF10-\uFFEF]{1,256}|[\u0600-\u06FF\/]{1,256}(\s*?[\u0600-\u06FF]{1,256}){1,2}/i;

                function he(e, t, n) {
                    Z[e] = C(t) ? t : function (e, r) {
                        return e && n ? n : t
                    }
                }

                function pe(e, t) {
                    return a(Z, e) ? Z[e](t._strict, t._locale) : new RegExp(me(e.replace("\\", "").replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g, (function (e, t, n, r, i) {
                        return t || n || r || i
                    }))))
                }

                function me(e) {
                    return e.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")
                }

                Z = {};
                var ge = {};

                function ye(e, t) {
                    var n, r, i = t;
                    for ("string" == typeof e && (e = [e]), l(t) && (i = function (e, n) {
                        n[t] = V(e)
                    }), r = e.length, n = 0; n < r; n++) ge[e[n]] = i
                }

                function ve(e, t) {
                    ye(e, (function (e, n, r, i) {
                        r._w = r._w || {}, t(e, r._w, r, i)
                    }))
                }

                function we(e, t, n) {
                    null != t && a(ge, e) && ge[e](t, n._a, n, e)
                }

                var _e, be = 0, xe = 1, ke = 2, Se = 3, Te = 4, De = 5, Ce = 6, Me = 7, Ne = 8;

                function Oe(e, t) {
                    if (isNaN(e) || isNaN(t)) return NaN;
                    var n, r = (t % (n = 12) + n) % n;
                    return e += (t - r) / 12, 1 === r ? B(e) ? 29 : 28 : 31 - r % 7 % 2
                }

                _e = Array.prototype.indexOf ? Array.prototype.indexOf : function (e) {
                    var t;
                    for (t = 0; t < this.length; ++t) if (this[t] === e) return t;
                    return -1
                }, R("M", ["MM", 2], "Mo", (function () {
                    return this.month() + 1
                })), R("MMM", 0, 0, (function (e) {
                    return this.localeData().monthsShort(this, e)
                })), R("MMMM", 0, 0, (function (e) {
                    return this.localeData().months(this, e)
                })), H("month", "M"), q("month", 8), he("M", ne), he("MM", ne, Q), he("MMM", (function (e, t) {
                    return t.monthsShortRegex(e)
                })), he("MMMM", (function (e, t) {
                    return t.monthsRegex(e)
                })), ye(["M", "MM"], (function (e, t) {
                    t[xe] = V(e) - 1
                })), ye(["MMM", "MMMM"], (function (e, t, n, r) {
                    var i = n._locale.monthsParse(e, r, n._strict);
                    null != i ? t[xe] = i : p(n).invalidMonth = e
                }));
                var Ee = "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
                    Ae = "Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),
                    je = /D[oD]?(\[[^\[\]]*\]|\s)+MMMM?/, Pe = fe, Re = fe;

                function Ye(e, t, n) {
                    var r, i, o, a = e.toLocaleLowerCase();
                    if (!this._monthsParse) for (this._monthsParse = [], this._longMonthsParse = [], this._shortMonthsParse = [], r = 0; r < 12; ++r) o = h([2e3, r]), this._shortMonthsParse[r] = this.monthsShort(o, "").toLocaleLowerCase(), this._longMonthsParse[r] = this.months(o, "").toLocaleLowerCase();
                    return n ? "MMM" === t ? -1 !== (i = _e.call(this._shortMonthsParse, a)) ? i : null : -1 !== (i = _e.call(this._longMonthsParse, a)) ? i : null : "MMM" === t ? -1 !== (i = _e.call(this._shortMonthsParse, a)) || -1 !== (i = _e.call(this._longMonthsParse, a)) ? i : null : -1 !== (i = _e.call(this._longMonthsParse, a)) || -1 !== (i = _e.call(this._shortMonthsParse, a)) ? i : null
                }

                function Le(e, t) {
                    var n;
                    if (!e.isValid()) return e;
                    if ("string" == typeof t) if (/^\d+$/.test(t)) t = V(t); else if (!l(t = e.localeData().monthsParse(t))) return e;
                    return n = Math.min(e.date(), Oe(e.year(), t)), e._d["set" + (e._isUTC ? "UTC" : "") + "Month"](t, n), e
                }

                function Ie(e) {
                    return null != e ? (Le(this, e), r.updateOffset(this, !0), this) : z(this, "Month")
                }

                function He() {
                    function e(e, t) {
                        return t.length - e.length
                    }

                    var t, n, r = [], i = [], o = [];
                    for (t = 0; t < 12; t++) n = h([2e3, t]), r.push(this.monthsShort(n, "")), i.push(this.months(n, "")), o.push(this.months(n, "")), o.push(this.monthsShort(n, ""));
                    for (r.sort(e), i.sort(e), o.sort(e), t = 0; t < 12; t++) r[t] = me(r[t]), i[t] = me(i[t]);
                    for (t = 0; t < 24; t++) o[t] = me(o[t]);
                    this._monthsRegex = new RegExp("^(" + o.join("|") + ")", "i"), this._monthsShortRegex = this._monthsRegex, this._monthsStrictRegex = new RegExp("^(" + i.join("|") + ")", "i"), this._monthsShortStrictRegex = new RegExp("^(" + r.join("|") + ")", "i")
                }

                function Fe(e) {
                    return B(e) ? 366 : 365
                }

                R("Y", 0, 0, (function () {
                    var e = this.year();
                    return e <= 9999 ? O(e, 4) : "+" + e
                })), R(0, ["YY", 2], 0, (function () {
                    return this.year() % 100
                })), R(0, ["YYYY", 4], 0, "year"), R(0, ["YYYYY", 5], 0, "year"), R(0, ["YYYYYY", 6, !0], 0, "year"), H("year", "y"), q("year", 1), he("Y", le), he("YY", ne, Q), he("YYYY", ae, ee), he("YYYYY", se, te), he("YYYYYY", se, te), ye(["YYYYY", "YYYYYY"], be), ye("YYYY", (function (e, t) {
                    t[be] = 2 === e.length ? r.parseTwoDigitYear(e) : V(e)
                })), ye("YY", (function (e, t) {
                    t[be] = r.parseTwoDigitYear(e)
                })), ye("Y", (function (e, t) {
                    t[be] = parseInt(e, 10)
                })), r.parseTwoDigitYear = function (e) {
                    return V(e) + (V(e) > 68 ? 1900 : 2e3)
                };
                var Ue = $("FullYear", !0);

                function We(e, t, n, r, i, o, a) {
                    var s;
                    return e < 100 && e >= 0 ? (s = new Date(e + 400, t, n, r, i, o, a), isFinite(s.getFullYear()) && s.setFullYear(e)) : s = new Date(e, t, n, r, i, o, a), s
                }

                function qe(e) {
                    var t, n;
                    return e < 100 && e >= 0 ? ((n = Array.prototype.slice.call(arguments))[0] = e + 400, t = new Date(Date.UTC.apply(null, n)), isFinite(t.getUTCFullYear()) && t.setUTCFullYear(e)) : t = new Date(Date.UTC.apply(null, arguments)), t
                }

                function Be(e, t, n) {
                    var r = 7 + t - n;
                    return -(7 + qe(e, 0, r).getUTCDay() - t) % 7 + r - 1
                }

                function Ge(e, t, n, r, i) {
                    var o, a, s = 1 + 7 * (t - 1) + (7 + n - r) % 7 + Be(e, r, i);
                    return s <= 0 ? a = Fe(o = e - 1) + s : s > Fe(e) ? (o = e + 1, a = s - Fe(e)) : (o = e, a = s), {
                        year: o,
                        dayOfYear: a
                    }
                }

                function Ve(e, t, n) {
                    var r, i, o = Be(e.year(), t, n), a = Math.floor((e.dayOfYear() - o - 1) / 7) + 1;
                    return a < 1 ? r = a + $e(i = e.year() - 1, t, n) : a > $e(e.year(), t, n) ? (r = a - $e(e.year(), t, n), i = e.year() + 1) : (i = e.year(), r = a), {
                        week: r,
                        year: i
                    }
                }

                function $e(e, t, n) {
                    var r = Be(e, t, n), i = Be(e + 1, t, n);
                    return (Fe(e) - r + i) / 7
                }

                R("w", ["ww", 2], "wo", "week"), R("W", ["WW", 2], "Wo", "isoWeek"), H("week", "w"), H("isoWeek", "W"), q("week", 5), q("isoWeek", 5), he("w", ne), he("ww", ne, Q), he("W", ne), he("WW", ne, Q), ve(["w", "ww", "W", "WW"], (function (e, t, n, r) {
                    t[r.substr(0, 1)] = V(e)
                }));

                function ze(e, t) {
                    return e.slice(t, 7).concat(e.slice(0, t))
                }

                R("d", 0, "do", "day"), R("dd", 0, 0, (function (e) {
                    return this.localeData().weekdaysMin(this, e)
                })), R("ddd", 0, 0, (function (e) {
                    return this.localeData().weekdaysShort(this, e)
                })), R("dddd", 0, 0, (function (e) {
                    return this.localeData().weekdays(this, e)
                })), R("e", 0, 0, "weekday"), R("E", 0, 0, "isoWeekday"), H("day", "d"), H("weekday", "e"), H("isoWeekday", "E"), q("day", 11), q("weekday", 11), q("isoWeekday", 11), he("d", ne), he("e", ne), he("E", ne), he("dd", (function (e, t) {
                    return t.weekdaysMinRegex(e)
                })), he("ddd", (function (e, t) {
                    return t.weekdaysShortRegex(e)
                })), he("dddd", (function (e, t) {
                    return t.weekdaysRegex(e)
                })), ve(["dd", "ddd", "dddd"], (function (e, t, n, r) {
                    var i = n._locale.weekdaysParse(e, r, n._strict);
                    null != i ? t.d = i : p(n).invalidWeekday = e
                })), ve(["d", "e", "E"], (function (e, t, n, r) {
                    t[r] = V(e)
                }));
                var Je = "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
                    Ze = "Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"), Xe = "Su_Mo_Tu_We_Th_Fr_Sa".split("_"), Qe = fe,
                    Ke = fe, et = fe;

                function tt(e, t, n) {
                    var r, i, o, a = e.toLocaleLowerCase();
                    if (!this._weekdaysParse) for (this._weekdaysParse = [], this._shortWeekdaysParse = [], this._minWeekdaysParse = [], r = 0; r < 7; ++r) o = h([2e3, 1]).day(r), this._minWeekdaysParse[r] = this.weekdaysMin(o, "").toLocaleLowerCase(), this._shortWeekdaysParse[r] = this.weekdaysShort(o, "").toLocaleLowerCase(), this._weekdaysParse[r] = this.weekdays(o, "").toLocaleLowerCase();
                    return n ? "dddd" === t ? -1 !== (i = _e.call(this._weekdaysParse, a)) ? i : null : "ddd" === t ? -1 !== (i = _e.call(this._shortWeekdaysParse, a)) ? i : null : -1 !== (i = _e.call(this._minWeekdaysParse, a)) ? i : null : "dddd" === t ? -1 !== (i = _e.call(this._weekdaysParse, a)) || -1 !== (i = _e.call(this._shortWeekdaysParse, a)) || -1 !== (i = _e.call(this._minWeekdaysParse, a)) ? i : null : "ddd" === t ? -1 !== (i = _e.call(this._shortWeekdaysParse, a)) || -1 !== (i = _e.call(this._weekdaysParse, a)) || -1 !== (i = _e.call(this._minWeekdaysParse, a)) ? i : null : -1 !== (i = _e.call(this._minWeekdaysParse, a)) || -1 !== (i = _e.call(this._weekdaysParse, a)) || -1 !== (i = _e.call(this._shortWeekdaysParse, a)) ? i : null
                }

                function nt() {
                    function e(e, t) {
                        return t.length - e.length
                    }

                    var t, n, r, i, o, a = [], s = [], u = [], l = [];
                    for (t = 0; t < 7; t++) n = h([2e3, 1]).day(t), r = me(this.weekdaysMin(n, "")), i = me(this.weekdaysShort(n, "")), o = me(this.weekdays(n, "")), a.push(r), s.push(i), u.push(o), l.push(r), l.push(i), l.push(o);
                    a.sort(e), s.sort(e), u.sort(e), l.sort(e), this._weekdaysRegex = new RegExp("^(" + l.join("|") + ")", "i"), this._weekdaysShortRegex = this._weekdaysRegex, this._weekdaysMinRegex = this._weekdaysRegex, this._weekdaysStrictRegex = new RegExp("^(" + u.join("|") + ")", "i"), this._weekdaysShortStrictRegex = new RegExp("^(" + s.join("|") + ")", "i"), this._weekdaysMinStrictRegex = new RegExp("^(" + a.join("|") + ")", "i")
                }

                function rt() {
                    return this.hours() % 12 || 12
                }

                function it(e, t) {
                    R(e, 0, 0, (function () {
                        return this.localeData().meridiem(this.hours(), this.minutes(), t)
                    }))
                }

                function ot(e, t) {
                    return t._meridiemParse
                }

                R("H", ["HH", 2], 0, "hour"), R("h", ["hh", 2], 0, rt), R("k", ["kk", 2], 0, (function () {
                    return this.hours() || 24
                })), R("hmm", 0, 0, (function () {
                    return "" + rt.apply(this) + O(this.minutes(), 2)
                })), R("hmmss", 0, 0, (function () {
                    return "" + rt.apply(this) + O(this.minutes(), 2) + O(this.seconds(), 2)
                })), R("Hmm", 0, 0, (function () {
                    return "" + this.hours() + O(this.minutes(), 2)
                })), R("Hmmss", 0, 0, (function () {
                    return "" + this.hours() + O(this.minutes(), 2) + O(this.seconds(), 2)
                })), it("a", !0), it("A", !1), H("hour", "h"), q("hour", 13), he("a", ot), he("A", ot), he("H", ne), he("h", ne), he("k", ne), he("HH", ne, Q), he("hh", ne, Q), he("kk", ne, Q), he("hmm", re), he("hmmss", ie), he("Hmm", re), he("Hmmss", ie), ye(["H", "HH"], Se), ye(["k", "kk"], (function (e, t, n) {
                    var r = V(e);
                    t[Se] = 24 === r ? 0 : r
                })), ye(["a", "A"], (function (e, t, n) {
                    n._isPm = n._locale.isPM(e), n._meridiem = e
                })), ye(["h", "hh"], (function (e, t, n) {
                    t[Se] = V(e), p(n).bigHour = !0
                })), ye("hmm", (function (e, t, n) {
                    var r = e.length - 2;
                    t[Se] = V(e.substr(0, r)), t[Te] = V(e.substr(r)), p(n).bigHour = !0
                })), ye("hmmss", (function (e, t, n) {
                    var r = e.length - 4, i = e.length - 2;
                    t[Se] = V(e.substr(0, r)), t[Te] = V(e.substr(r, 2)), t[De] = V(e.substr(i)), p(n).bigHour = !0
                })), ye("Hmm", (function (e, t, n) {
                    var r = e.length - 2;
                    t[Se] = V(e.substr(0, r)), t[Te] = V(e.substr(r))
                })), ye("Hmmss", (function (e, t, n) {
                    var r = e.length - 4, i = e.length - 2;
                    t[Se] = V(e.substr(0, r)), t[Te] = V(e.substr(r, 2)), t[De] = V(e.substr(i))
                }));
                var at = $("Hours", !0);
                var st, ut = {
                    calendar: {
                        sameDay: "[Today at] LT",
                        nextDay: "[Tomorrow at] LT",
                        nextWeek: "dddd [at] LT",
                        lastDay: "[Yesterday at] LT",
                        lastWeek: "[Last] dddd [at] LT",
                        sameElse: "L"
                    },
                    longDateFormat: {
                        LTS: "h:mm:ss A",
                        LT: "h:mm A",
                        L: "MM/DD/YYYY",
                        LL: "MMMM D, YYYY",
                        LLL: "MMMM D, YYYY h:mm A",
                        LLLL: "dddd, MMMM D, YYYY h:mm A"
                    },
                    invalidDate: "Invalid date",
                    ordinal: "%d",
                    dayOfMonthOrdinalParse: /\d{1,2}/,
                    relativeTime: {
                        future: "in %s",
                        past: "%s ago",
                        s: "a few seconds",
                        ss: "%d seconds",
                        m: "a minute",
                        mm: "%d minutes",
                        h: "an hour",
                        hh: "%d hours",
                        d: "a day",
                        dd: "%d days",
                        w: "a week",
                        ww: "%d weeks",
                        M: "a month",
                        MM: "%d months",
                        y: "a year",
                        yy: "%d years"
                    },
                    months: Ee,
                    monthsShort: Ae,
                    week: {dow: 0, doy: 6},
                    weekdays: Je,
                    weekdaysMin: Xe,
                    weekdaysShort: Ze,
                    meridiemParse: /[ap]\.?m?\.?/i
                }, lt = {}, ct = {};

                function dt(e, t) {
                    var n, r = Math.min(e.length, t.length);
                    for (n = 0; n < r; n += 1) if (e[n] !== t[n]) return n;
                    return r
                }

                function ft(e) {
                    return e ? e.toLowerCase().replace("_", "-") : e
                }

                function ht(t) {
                    var n = null;
                    if (void 0 === lt[t] && e && e.exports && function (e) {
                        return null != e.match("^[^/\\\\]*$")
                    }(t)) try {
                        n = st._abbr, Object(function () {
                            var e = new Error("Cannot find module 'undefined'");
                            throw e.code = "MODULE_NOT_FOUND", e
                        }()), pt(n)
                    } catch (e) {
                        lt[t] = null
                    }
                    return lt[t]
                }

                function pt(e, t) {
                    var n;
                    return e && ((n = u(t) ? gt(e) : mt(e, t)) ? st = n : "undefined" != typeof console && console.warn && console.warn("Locale " + e + " not found. Did you forget to load it?")), st._abbr
                }

                function mt(e, t) {
                    if (null !== t) {
                        var n, r = ut;
                        if (t.abbr = e, null != lt[e]) D("defineLocaleOverride", "use moment.updateLocale(localeName, config) to change an existing locale. moment.defineLocale(localeName, config) should only be used for creating a new locale See http://momentjs.com/guides/#/warnings/define-locale/ for more info."), r = lt[e]._config; else if (null != t.parentLocale) if (null != lt[t.parentLocale]) r = lt[t.parentLocale]._config; else {
                            if (null == (n = ht(t.parentLocale))) return ct[t.parentLocale] || (ct[t.parentLocale] = []), ct[t.parentLocale].push({
                                name: e,
                                config: t
                            }), null;
                            r = n._config
                        }
                        return lt[e] = new N(M(r, t)), ct[e] && ct[e].forEach((function (e) {
                            mt(e.name, e.config)
                        })), pt(e), lt[e]
                    }
                    return delete lt[e], null
                }

                function gt(e) {
                    var t;
                    if (e && e._locale && e._locale._abbr && (e = e._locale._abbr), !e) return st;
                    if (!i(e)) {
                        if (t = ht(e)) return t;
                        e = [e]
                    }
                    return function (e) {
                        for (var t, n, r, i, o = 0; o < e.length;) {
                            for (t = (i = ft(e[o]).split("-")).length, n = (n = ft(e[o + 1])) ? n.split("-") : null; t > 0;) {
                                if (r = ht(i.slice(0, t).join("-"))) return r;
                                if (n && n.length >= t && dt(i, n) >= t - 1) break;
                                t--
                            }
                            o++
                        }
                        return st
                    }(e)
                }

                function yt(e) {
                    var t, n = e._a;
                    return n && -2 === p(e).overflow && (t = n[xe] < 0 || n[xe] > 11 ? xe : n[ke] < 1 || n[ke] > Oe(n[be], n[xe]) ? ke : n[Se] < 0 || n[Se] > 24 || 24 === n[Se] && (0 !== n[Te] || 0 !== n[De] || 0 !== n[Ce]) ? Se : n[Te] < 0 || n[Te] > 59 ? Te : n[De] < 0 || n[De] > 59 ? De : n[Ce] < 0 || n[Ce] > 999 ? Ce : -1, p(e)._overflowDayOfYear && (t < be || t > ke) && (t = ke), p(e)._overflowWeeks && -1 === t && (t = Me), p(e)._overflowWeekday && -1 === t && (t = Ne), p(e).overflow = t), e
                }

                var vt = /^\s*((?:[+-]\d{6}|\d{4})-(?:\d\d-\d\d|W\d\d-\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?::\d\d(?::\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/,
                    wt = /^\s*((?:[+-]\d{6}|\d{4})(?:\d\d\d\d|W\d\d\d|W\d\d|\d\d\d|\d\d|))(?:(T| )(\d\d(?:\d\d(?:\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/,
                    _t = /Z|[+-]\d\d(?::?\d\d)?/,
                    bt = [["YYYYYY-MM-DD", /[+-]\d{6}-\d\d-\d\d/], ["YYYY-MM-DD", /\d{4}-\d\d-\d\d/], ["GGGG-[W]WW-E", /\d{4}-W\d\d-\d/], ["GGGG-[W]WW", /\d{4}-W\d\d/, !1], ["YYYY-DDD", /\d{4}-\d{3}/], ["YYYY-MM", /\d{4}-\d\d/, !1], ["YYYYYYMMDD", /[+-]\d{10}/], ["YYYYMMDD", /\d{8}/], ["GGGG[W]WWE", /\d{4}W\d{3}/], ["GGGG[W]WW", /\d{4}W\d{2}/, !1], ["YYYYDDD", /\d{7}/], ["YYYYMM", /\d{6}/, !1], ["YYYY", /\d{4}/, !1]],
                    xt = [["HH:mm:ss.SSSS", /\d\d:\d\d:\d\d\.\d+/], ["HH:mm:ss,SSSS", /\d\d:\d\d:\d\d,\d+/], ["HH:mm:ss", /\d\d:\d\d:\d\d/], ["HH:mm", /\d\d:\d\d/], ["HHmmss.SSSS", /\d\d\d\d\d\d\.\d+/], ["HHmmss,SSSS", /\d\d\d\d\d\d,\d+/], ["HHmmss", /\d\d\d\d\d\d/], ["HHmm", /\d\d\d\d/], ["HH", /\d\d/]],
                    kt = /^\/?Date\((-?\d+)/i,
                    St = /^(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun),?\s)?(\d{1,2})\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(\d{2,4})\s(\d\d):(\d\d)(?::(\d\d))?\s(?:(UT|GMT|[ECMP][SD]T)|([Zz])|([+-]\d{4}))$/,
                    Tt = {
                        UT: 0,
                        GMT: 0,
                        EDT: -240,
                        EST: -300,
                        CDT: -300,
                        CST: -360,
                        MDT: -360,
                        MST: -420,
                        PDT: -420,
                        PST: -480
                    };

                function Dt(e) {
                    var t, n, r, i, o, a, s = e._i, u = vt.exec(s) || wt.exec(s), l = bt.length, c = xt.length;
                    if (u) {
                        for (p(e).iso = !0, t = 0, n = l; t < n; t++) if (bt[t][1].exec(u[1])) {
                            i = bt[t][0], r = !1 !== bt[t][2];
                            break
                        }
                        if (null == i) return void (e._isValid = !1);
                        if (u[3]) {
                            for (t = 0, n = c; t < n; t++) if (xt[t][1].exec(u[3])) {
                                o = (u[2] || " ") + xt[t][0];
                                break
                            }
                            if (null == o) return void (e._isValid = !1)
                        }
                        if (!r && null != o) return void (e._isValid = !1);
                        if (u[4]) {
                            if (!_t.exec(u[4])) return void (e._isValid = !1);
                            a = "Z"
                        }
                        e._f = i + (o || "") + (a || ""), Et(e)
                    } else e._isValid = !1
                }

                function Ct(e) {
                    var t = parseInt(e, 10);
                    return t <= 49 ? 2e3 + t : t <= 999 ? 1900 + t : t
                }

                function Mt(e) {
                    var t, n, r, i, o, a, s, u,
                        l = St.exec(e._i.replace(/\([^()]*\)|[\n\t]/g, " ").replace(/(\s\s+)/g, " ").replace(/^\s\s*/, "").replace(/\s\s*$/, ""));
                    if (l) {
                        if (n = l[4], r = l[3], i = l[2], o = l[5], a = l[6], s = l[7], u = [Ct(n), Ae.indexOf(r), parseInt(i, 10), parseInt(o, 10), parseInt(a, 10)], s && u.push(parseInt(s, 10)), t = u, !function (e, t, n) {
                            return !e || Ze.indexOf(e) === new Date(t[0], t[1], t[2]).getDay() || (p(n).weekdayMismatch = !0, n._isValid = !1, !1)
                        }(l[1], t, e)) return;
                        e._a = t, e._tzm = function (e, t, n) {
                            if (e) return Tt[e];
                            if (t) return 0;
                            var r = parseInt(n, 10), i = r % 100;
                            return (r - i) / 100 * 60 + i
                        }(l[8], l[9], l[10]), e._d = qe.apply(null, e._a), e._d.setUTCMinutes(e._d.getUTCMinutes() - e._tzm), p(e).rfc2822 = !0
                    } else e._isValid = !1
                }

                function Nt(e, t, n) {
                    return null != e ? e : null != t ? t : n
                }

                function Ot(e) {
                    var t, n, i, o, a, s = [];
                    if (!e._d) {
                        for (i = function (e) {
                            var t = new Date(r.now());
                            return e._useUTC ? [t.getUTCFullYear(), t.getUTCMonth(), t.getUTCDate()] : [t.getFullYear(), t.getMonth(), t.getDate()]
                        }(e), e._w && null == e._a[ke] && null == e._a[xe] && function (e) {
                            var t, n, r, i, o, a, s, u, l;
                            null != (t = e._w).GG || null != t.W || null != t.E ? (o = 1, a = 4, n = Nt(t.GG, e._a[be], Ve(Pt(), 1, 4).year), r = Nt(t.W, 1), ((i = Nt(t.E, 1)) < 1 || i > 7) && (u = !0)) : (o = e._locale._week.dow, a = e._locale._week.doy, l = Ve(Pt(), o, a), n = Nt(t.gg, e._a[be], l.year), r = Nt(t.w, l.week), null != t.d ? ((i = t.d) < 0 || i > 6) && (u = !0) : null != t.e ? (i = t.e + o, (t.e < 0 || t.e > 6) && (u = !0)) : i = o), r < 1 || r > $e(n, o, a) ? p(e)._overflowWeeks = !0 : null != u ? p(e)._overflowWeekday = !0 : (s = Ge(n, r, i, o, a), e._a[be] = s.year, e._dayOfYear = s.dayOfYear)
                        }(e), null != e._dayOfYear && (a = Nt(e._a[be], i[be]), (e._dayOfYear > Fe(a) || 0 === e._dayOfYear) && (p(e)._overflowDayOfYear = !0), n = qe(a, 0, e._dayOfYear), e._a[xe] = n.getUTCMonth(), e._a[ke] = n.getUTCDate()), t = 0; t < 3 && null == e._a[t]; ++t) e._a[t] = s[t] = i[t];
                        for (; t < 7; t++) e._a[t] = s[t] = null == e._a[t] ? 2 === t ? 1 : 0 : e._a[t];
                        24 === e._a[Se] && 0 === e._a[Te] && 0 === e._a[De] && 0 === e._a[Ce] && (e._nextDay = !0, e._a[Se] = 0), e._d = (e._useUTC ? qe : We).apply(null, s), o = e._useUTC ? e._d.getUTCDay() : e._d.getDay(), null != e._tzm && e._d.setUTCMinutes(e._d.getUTCMinutes() - e._tzm), e._nextDay && (e._a[Se] = 24), e._w && void 0 !== e._w.d && e._w.d !== o && (p(e).weekdayMismatch = !0)
                    }
                }

                function Et(e) {
                    if (e._f !== r.ISO_8601) if (e._f !== r.RFC_2822) {
                        e._a = [], p(e).empty = !0;
                        var t, n, i, o, a, s, u, l = "" + e._i, c = l.length, d = 0;
                        for (u = (i = L(e._f, e._locale).match(E) || []).length, t = 0; t < u; t++) o = i[t], (n = (l.match(pe(o, e)) || [])[0]) && ((a = l.substr(0, l.indexOf(n))).length > 0 && p(e).unusedInput.push(a), l = l.slice(l.indexOf(n) + n.length), d += n.length), P[o] ? (n ? p(e).empty = !1 : p(e).unusedTokens.push(o), we(o, n, e)) : e._strict && !n && p(e).unusedTokens.push(o);
                        p(e).charsLeftOver = c - d, l.length > 0 && p(e).unusedInput.push(l), e._a[Se] <= 12 && !0 === p(e).bigHour && e._a[Se] > 0 && (p(e).bigHour = void 0), p(e).parsedDateParts = e._a.slice(0), p(e).meridiem = e._meridiem, e._a[Se] = function (e, t, n) {
                            var r;
                            return null == n ? t : null != e.meridiemHour ? e.meridiemHour(t, n) : null != e.isPM ? ((r = e.isPM(n)) && t < 12 && (t += 12), r || 12 !== t || (t = 0), t) : t
                        }(e._locale, e._a[Se], e._meridiem), null !== (s = p(e).era) && (e._a[be] = e._locale.erasConvertYear(s, e._a[be])), Ot(e), yt(e)
                    } else Mt(e); else Dt(e)
                }

                function At(e) {
                    var t = e._i, n = e._f;
                    return e._locale = e._locale || gt(e._l), null === t || void 0 === n && "" === t ? g({nullInput: !0}) : ("string" == typeof t && (e._i = t = e._locale.preparse(t)), b(t) ? new _(yt(t)) : (c(t) ? e._d = t : i(n) ? function (e) {
                        var t, n, r, i, o, a, s = !1, u = e._f.length;
                        if (0 === u) return p(e).invalidFormat = !0, void (e._d = new Date(NaN));
                        for (i = 0; i < u; i++) o = 0, a = !1, t = w({}, e), null != e._useUTC && (t._useUTC = e._useUTC), t._f = e._f[i], Et(t), m(t) && (a = !0), o += p(t).charsLeftOver, o += 10 * p(t).unusedTokens.length, p(t).score = o, s ? o < r && (r = o, n = t) : (null == r || o < r || a) && (r = o, n = t, a && (s = !0));
                        f(e, n || t)
                    }(e) : n ? Et(e) : function (e) {
                        var t = e._i;
                        u(t) ? e._d = new Date(r.now()) : c(t) ? e._d = new Date(t.valueOf()) : "string" == typeof t ? function (e) {
                            var t = kt.exec(e._i);
                            null === t ? (Dt(e), !1 === e._isValid && (delete e._isValid, Mt(e), !1 === e._isValid && (delete e._isValid, e._strict ? e._isValid = !1 : r.createFromInputFallback(e)))) : e._d = new Date(+t[1])
                        }(e) : i(t) ? (e._a = d(t.slice(0), (function (e) {
                            return parseInt(e, 10)
                        })), Ot(e)) : o(t) ? function (e) {
                            if (!e._d) {
                                var t = U(e._i), n = void 0 === t.day ? t.date : t.day;
                                e._a = d([t.year, t.month, n, t.hour, t.minute, t.second, t.millisecond], (function (e) {
                                    return e && parseInt(e, 10)
                                })), Ot(e)
                            }
                        }(e) : l(t) ? e._d = new Date(t) : r.createFromInputFallback(e)
                    }(e), m(e) || (e._d = null), e))
                }

                function jt(e, t, n, r, a) {
                    var u, l = {};
                    return !0 !== t && !1 !== t || (r = t, t = void 0), !0 !== n && !1 !== n || (r = n, n = void 0), (o(e) && s(e) || i(e) && 0 === e.length) && (e = void 0), l._isAMomentObject = !0, l._useUTC = l._isUTC = a, l._l = n, l._i = e, l._f = t, l._strict = r, (u = new _(yt(At(l))))._nextDay && (u.add(1, "d"), u._nextDay = void 0), u
                }

                function Pt(e, t, n, r) {
                    return jt(e, t, n, r, !1)
                }

                r.createFromInputFallback = k("value provided is not in a recognized RFC2822 or ISO format. moment construction falls back to js Date(), which is not reliable across all browsers and versions. Non RFC2822/ISO date formats are discouraged. Please refer to http://momentjs.com/guides/#/warnings/js-date/ for more info.", (function (e) {
                    e._d = new Date(e._i + (e._useUTC ? " UTC" : ""))
                })), r.ISO_8601 = function () {
                }, r.RFC_2822 = function () {
                };
                var Rt = k("moment().min is deprecated, use moment.max instead. http://momentjs.com/guides/#/warnings/min-max/", (function () {
                        var e = Pt.apply(null, arguments);
                        return this.isValid() && e.isValid() ? e < this ? this : e : g()
                    })),
                    Yt = k("moment().max is deprecated, use moment.min instead. http://momentjs.com/guides/#/warnings/min-max/", (function () {
                        var e = Pt.apply(null, arguments);
                        return this.isValid() && e.isValid() ? e > this ? this : e : g()
                    }));

                function Lt(e, t) {
                    var n, r;
                    if (1 === t.length && i(t[0]) && (t = t[0]), !t.length) return Pt();
                    for (n = t[0], r = 1; r < t.length; ++r) t[r].isValid() && !t[r][e](n) || (n = t[r]);
                    return n
                }

                var It = ["year", "quarter", "month", "week", "day", "hour", "minute", "second", "millisecond"];

                function Ht(e) {
                    var t = U(e), n = t.year || 0, r = t.quarter || 0, i = t.month || 0, o = t.week || t.isoWeek || 0,
                        s = t.day || 0, u = t.hour || 0, l = t.minute || 0, c = t.second || 0, d = t.millisecond || 0;
                    this._isValid = function (e) {
                        var t, n, r = !1, i = It.length;
                        for (t in e) if (a(e, t) && (-1 === _e.call(It, t) || null != e[t] && isNaN(e[t]))) return !1;
                        for (n = 0; n < i; ++n) if (e[It[n]]) {
                            if (r) return !1;
                            parseFloat(e[It[n]]) !== V(e[It[n]]) && (r = !0)
                        }
                        return !0
                    }(t), this._milliseconds = +d + 1e3 * c + 6e4 * l + 1e3 * u * 60 * 60, this._days = +s + 7 * o, this._months = +i + 3 * r + 12 * n, this._data = {}, this._locale = gt(), this._bubble()
                }

                function Ft(e) {
                    return e instanceof Ht
                }

                function Ut(e) {
                    return e < 0 ? -1 * Math.round(-1 * e) : Math.round(e)
                }

                function Wt(e, t) {
                    R(e, 0, 0, (function () {
                        var e = this.utcOffset(), n = "+";
                        return e < 0 && (e = -e, n = "-"), n + O(~~(e / 60), 2) + t + O(~~e % 60, 2)
                    }))
                }

                Wt("Z", ":"), Wt("ZZ", ""), he("Z", de), he("ZZ", de), ye(["Z", "ZZ"], (function (e, t, n) {
                    n._useUTC = !0, n._tzm = Bt(de, e)
                }));
                var qt = /([\+\-]|\d\d)/gi;

                function Bt(e, t) {
                    var n, r, i = (t || "").match(e);
                    return null === i ? null : 0 === (r = 60 * (n = ((i[i.length - 1] || []) + "").match(qt) || ["-", 0, 0])[1] + V(n[2])) ? 0 : "+" === n[0] ? r : -r
                }

                function Gt(e, t) {
                    var n, i;
                    return t._isUTC ? (n = t.clone(), i = (b(e) || c(e) ? e.valueOf() : Pt(e).valueOf()) - n.valueOf(), n._d.setTime(n._d.valueOf() + i), r.updateOffset(n, !1), n) : Pt(e).local()
                }

                function Vt(e) {
                    return -Math.round(e._d.getTimezoneOffset())
                }

                function $t() {
                    return !!this.isValid() && this._isUTC && 0 === this._offset
                }

                r.updateOffset = function () {
                };
                var zt = /^(-|\+)?(?:(\d*)[. ])?(\d+):(\d+)(?::(\d+)(\.\d*)?)?$/,
                    Jt = /^(-|\+)?P(?:([-+]?[0-9,.]*)Y)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)W)?(?:([-+]?[0-9,.]*)D)?(?:T(?:([-+]?[0-9,.]*)H)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)S)?)?$/;

                function Zt(e, t) {
                    var n, r, i, o, s, u, c = e, d = null;
                    return Ft(e) ? c = {
                        ms: e._milliseconds,
                        d: e._days,
                        M: e._months
                    } : l(e) || !isNaN(+e) ? (c = {}, t ? c[t] = +e : c.milliseconds = +e) : (d = zt.exec(e)) ? (n = "-" === d[1] ? -1 : 1, c = {
                        y: 0,
                        d: V(d[ke]) * n,
                        h: V(d[Se]) * n,
                        m: V(d[Te]) * n,
                        s: V(d[De]) * n,
                        ms: V(Ut(1e3 * d[Ce])) * n
                    }) : (d = Jt.exec(e)) ? (n = "-" === d[1] ? -1 : 1, c = {
                        y: Xt(d[2], n),
                        M: Xt(d[3], n),
                        w: Xt(d[4], n),
                        d: Xt(d[5], n),
                        h: Xt(d[6], n),
                        m: Xt(d[7], n),
                        s: Xt(d[8], n)
                    }) : null == c ? c = {} : "object" == typeof c && ("from" in c || "to" in c) && (o = Pt(c.from), s = Pt(c.to), i = o.isValid() && s.isValid() ? (s = Gt(s, o), o.isBefore(s) ? u = Qt(o, s) : ((u = Qt(s, o)).milliseconds = -u.milliseconds, u.months = -u.months), u) : {
                        milliseconds: 0,
                        months: 0
                    }, (c = {}).ms = i.milliseconds, c.M = i.months), r = new Ht(c), Ft(e) && a(e, "_locale") && (r._locale = e._locale), Ft(e) && a(e, "_isValid") && (r._isValid = e._isValid), r
                }

                function Xt(e, t) {
                    var n = e && parseFloat(e.replace(",", "."));
                    return (isNaN(n) ? 0 : n) * t
                }

                function Qt(e, t) {
                    var n = {};
                    return n.months = t.month() - e.month() + 12 * (t.year() - e.year()), e.clone().add(n.months, "M").isAfter(t) && --n.months, n.milliseconds = +t - +e.clone().add(n.months, "M"), n
                }

                function Kt(e, t) {
                    return function (n, r) {
                        var i;
                        return null === r || isNaN(+r) || (D(t, "moment()." + t + "(period, number) is deprecated. Please use moment()." + t + "(number, period). See http://momentjs.com/guides/#/warnings/add-inverted-param/ for more info."), i = n, n = r, r = i), en(this, Zt(n, r), e), this
                    }
                }

                function en(e, t, n, i) {
                    var o = t._milliseconds, a = Ut(t._days), s = Ut(t._months);
                    e.isValid() && (i = null == i || i, s && Le(e, z(e, "Month") + s * n), a && J(e, "Date", z(e, "Date") + a * n), o && e._d.setTime(e._d.valueOf() + o * n), i && r.updateOffset(e, a || s))
                }

                Zt.fn = Ht.prototype, Zt.invalid = function () {
                    return Zt(NaN)
                };
                var tn = Kt(1, "add"), nn = Kt(-1, "subtract");

                function rn(e) {
                    return "string" == typeof e || e instanceof String
                }

                function on(e) {
                    return b(e) || c(e) || rn(e) || l(e) || function (e) {
                        var t = i(e), n = !1;
                        return t && (n = 0 === e.filter((function (t) {
                            return !l(t) && rn(e)
                        })).length), t && n
                    }(e) || function (e) {
                        var t, n, r = o(e) && !s(e), i = !1,
                            u = ["years", "year", "y", "months", "month", "M", "days", "day", "d", "dates", "date", "D", "hours", "hour", "h", "minutes", "minute", "m", "seconds", "second", "s", "milliseconds", "millisecond", "ms"],
                            l = u.length;
                        for (t = 0; t < l; t += 1) n = u[t], i = i || a(e, n);
                        return r && i
                    }(e) || null == e
                }

                function an(e, t) {
                    if (e.date() < t.date()) return -an(t, e);
                    var n = 12 * (t.year() - e.year()) + (t.month() - e.month()), r = e.clone().add(n, "months");
                    return -(n + (t - r < 0 ? (t - r) / (r - e.clone().add(n - 1, "months")) : (t - r) / (e.clone().add(n + 1, "months") - r))) || 0
                }

                function sn(e) {
                    var t;
                    return void 0 === e ? this._locale._abbr : (null != (t = gt(e)) && (this._locale = t), this)
                }

                r.defaultFormat = "YYYY-MM-DDTHH:mm:ssZ", r.defaultFormatUtc = "YYYY-MM-DDTHH:mm:ss[Z]";
                var un = k("moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.", (function (e) {
                    return void 0 === e ? this.localeData() : this.locale(e)
                }));

                function ln() {
                    return this._locale
                }

                var cn = 1e3, dn = 60 * cn, fn = 60 * dn, hn = 3506328 * fn;

                function pn(e, t) {
                    return (e % t + t) % t
                }

                function mn(e, t, n) {
                    return e < 100 && e >= 0 ? new Date(e + 400, t, n) - hn : new Date(e, t, n).valueOf()
                }

                function gn(e, t, n) {
                    return e < 100 && e >= 0 ? Date.UTC(e + 400, t, n) - hn : Date.UTC(e, t, n)
                }

                function yn(e, t) {
                    return t.erasAbbrRegex(e)
                }

                function vn() {
                    var e, t, n = [], r = [], i = [], o = [], a = this.eras();
                    for (e = 0, t = a.length; e < t; ++e) r.push(me(a[e].name)), n.push(me(a[e].abbr)), i.push(me(a[e].narrow)), o.push(me(a[e].name)), o.push(me(a[e].abbr)), o.push(me(a[e].narrow));
                    this._erasRegex = new RegExp("^(" + o.join("|") + ")", "i"), this._erasNameRegex = new RegExp("^(" + r.join("|") + ")", "i"), this._erasAbbrRegex = new RegExp("^(" + n.join("|") + ")", "i"), this._erasNarrowRegex = new RegExp("^(" + i.join("|") + ")", "i")
                }

                function wn(e, t) {
                    R(0, [e, e.length], 0, t)
                }

                function _n(e, t, n, r, i) {
                    var o;
                    return null == e ? Ve(this, r, i).year : (t > (o = $e(e, r, i)) && (t = o), bn.call(this, e, t, n, r, i))
                }

                function bn(e, t, n, r, i) {
                    var o = Ge(e, t, n, r, i), a = qe(o.year, 0, o.dayOfYear);
                    return this.year(a.getUTCFullYear()), this.month(a.getUTCMonth()), this.date(a.getUTCDate()), this
                }

                R("N", 0, 0, "eraAbbr"), R("NN", 0, 0, "eraAbbr"), R("NNN", 0, 0, "eraAbbr"), R("NNNN", 0, 0, "eraName"), R("NNNNN", 0, 0, "eraNarrow"), R("y", ["y", 1], "yo", "eraYear"), R("y", ["yy", 2], 0, "eraYear"), R("y", ["yyy", 3], 0, "eraYear"), R("y", ["yyyy", 4], 0, "eraYear"), he("N", yn), he("NN", yn), he("NNN", yn), he("NNNN", (function (e, t) {
                    return t.erasNameRegex(e)
                })), he("NNNNN", (function (e, t) {
                    return t.erasNarrowRegex(e)
                })), ye(["N", "NN", "NNN", "NNNN", "NNNNN"], (function (e, t, n, r) {
                    var i = n._locale.erasParse(e, r, n._strict);
                    i ? p(n).era = i : p(n).invalidEra = e
                })), he("y", ue), he("yy", ue), he("yyy", ue), he("yyyy", ue), he("yo", (function (e, t) {
                    return t._eraYearOrdinalRegex || ue
                })), ye(["y", "yy", "yyy", "yyyy"], be), ye(["yo"], (function (e, t, n, r) {
                    var i;
                    n._locale._eraYearOrdinalRegex && (i = e.match(n._locale._eraYearOrdinalRegex)), n._locale.eraYearOrdinalParse ? t[be] = n._locale.eraYearOrdinalParse(e, i) : t[be] = parseInt(e, 10)
                })), R(0, ["gg", 2], 0, (function () {
                    return this.weekYear() % 100
                })), R(0, ["GG", 2], 0, (function () {
                    return this.isoWeekYear() % 100
                })), wn("gggg", "weekYear"), wn("ggggg", "weekYear"), wn("GGGG", "isoWeekYear"), wn("GGGGG", "isoWeekYear"), H("weekYear", "gg"), H("isoWeekYear", "GG"), q("weekYear", 1), q("isoWeekYear", 1), he("G", le), he("g", le), he("GG", ne, Q), he("gg", ne, Q), he("GGGG", ae, ee), he("gggg", ae, ee), he("GGGGG", se, te), he("ggggg", se, te), ve(["gggg", "ggggg", "GGGG", "GGGGG"], (function (e, t, n, r) {
                    t[r.substr(0, 2)] = V(e)
                })), ve(["gg", "GG"], (function (e, t, n, i) {
                    t[i] = r.parseTwoDigitYear(e)
                })), R("Q", 0, "Qo", "quarter"), H("quarter", "Q"), q("quarter", 7), he("Q", X), ye("Q", (function (e, t) {
                    t[xe] = 3 * (V(e) - 1)
                })), R("D", ["DD", 2], "Do", "date"), H("date", "D"), q("date", 9), he("D", ne), he("DD", ne, Q), he("Do", (function (e, t) {
                    return e ? t._dayOfMonthOrdinalParse || t._ordinalParse : t._dayOfMonthOrdinalParseLenient
                })), ye(["D", "DD"], ke), ye("Do", (function (e, t) {
                    t[ke] = V(e.match(ne)[0])
                }));
                var xn = $("Date", !0);
                R("DDD", ["DDDD", 3], "DDDo", "dayOfYear"), H("dayOfYear", "DDD"), q("dayOfYear", 4), he("DDD", oe), he("DDDD", K), ye(["DDD", "DDDD"], (function (e, t, n) {
                    n._dayOfYear = V(e)
                })), R("m", ["mm", 2], 0, "minute"), H("minute", "m"), q("minute", 14), he("m", ne), he("mm", ne, Q), ye(["m", "mm"], Te);
                var kn = $("Minutes", !1);
                R("s", ["ss", 2], 0, "second"), H("second", "s"), q("second", 15), he("s", ne), he("ss", ne, Q), ye(["s", "ss"], De);
                var Sn, Tn, Dn = $("Seconds", !1);
                for (R("S", 0, 0, (function () {
                    return ~~(this.millisecond() / 100)
                })), R(0, ["SS", 2], 0, (function () {
                    return ~~(this.millisecond() / 10)
                })), R(0, ["SSS", 3], 0, "millisecond"), R(0, ["SSSS", 4], 0, (function () {
                    return 10 * this.millisecond()
                })), R(0, ["SSSSS", 5], 0, (function () {
                    return 100 * this.millisecond()
                })), R(0, ["SSSSSS", 6], 0, (function () {
                    return 1e3 * this.millisecond()
                })), R(0, ["SSSSSSS", 7], 0, (function () {
                    return 1e4 * this.millisecond()
                })), R(0, ["SSSSSSSS", 8], 0, (function () {
                    return 1e5 * this.millisecond()
                })), R(0, ["SSSSSSSSS", 9], 0, (function () {
                    return 1e6 * this.millisecond()
                })), H("millisecond", "ms"), q("millisecond", 16), he("S", oe, X), he("SS", oe, Q), he("SSS", oe, K), Sn = "SSSS"; Sn.length <= 9; Sn += "S") he(Sn, ue);

                function Cn(e, t) {
                    t[Ce] = V(1e3 * ("0." + e))
                }

                for (Sn = "S"; Sn.length <= 9; Sn += "S") ye(Sn, Cn);
                Tn = $("Milliseconds", !1), R("z", 0, 0, "zoneAbbr"), R("zz", 0, 0, "zoneName");
                var Mn = _.prototype;

                function Nn(e) {
                    return e
                }

                Mn.add = tn, Mn.calendar = function (e, t) {
                    1 === arguments.length && (arguments[0] ? on(arguments[0]) ? (e = arguments[0], t = void 0) : function (e) {
                        var t, n = o(e) && !s(e), r = !1,
                            i = ["sameDay", "nextDay", "lastDay", "nextWeek", "lastWeek", "sameElse"];
                        for (t = 0; t < i.length; t += 1) r = r || a(e, i[t]);
                        return n && r
                    }(arguments[0]) && (t = arguments[0], e = void 0) : (e = void 0, t = void 0));
                    var n = e || Pt(), i = Gt(n, this).startOf("day"), u = r.calendarFormat(this, i) || "sameElse",
                        l = t && (C(t[u]) ? t[u].call(this, n) : t[u]);
                    return this.format(l || this.localeData().calendar(u, this, Pt(n)))
                }, Mn.clone = function () {
                    return new _(this)
                }, Mn.diff = function (e, t, n) {
                    var r, i, o;
                    if (!this.isValid()) return NaN;
                    if (!(r = Gt(e, this)).isValid()) return NaN;
                    switch (i = 6e4 * (r.utcOffset() - this.utcOffset()), t = F(t)) {
                        case"year":
                            o = an(this, r) / 12;
                            break;
                        case"month":
                            o = an(this, r);
                            break;
                        case"quarter":
                            o = an(this, r) / 3;
                            break;
                        case"second":
                            o = (this - r) / 1e3;
                            break;
                        case"minute":
                            o = (this - r) / 6e4;
                            break;
                        case"hour":
                            o = (this - r) / 36e5;
                            break;
                        case"day":
                            o = (this - r - i) / 864e5;
                            break;
                        case"week":
                            o = (this - r - i) / 6048e5;
                            break;
                        default:
                            o = this - r
                    }
                    return n ? o : G(o)
                }, Mn.endOf = function (e) {
                    var t, n;
                    if (void 0 === (e = F(e)) || "millisecond" === e || !this.isValid()) return this;
                    switch (n = this._isUTC ? gn : mn, e) {
                        case"year":
                            t = n(this.year() + 1, 0, 1) - 1;
                            break;
                        case"quarter":
                            t = n(this.year(), this.month() - this.month() % 3 + 3, 1) - 1;
                            break;
                        case"month":
                            t = n(this.year(), this.month() + 1, 1) - 1;
                            break;
                        case"week":
                            t = n(this.year(), this.month(), this.date() - this.weekday() + 7) - 1;
                            break;
                        case"isoWeek":
                            t = n(this.year(), this.month(), this.date() - (this.isoWeekday() - 1) + 7) - 1;
                            break;
                        case"day":
                        case"date":
                            t = n(this.year(), this.month(), this.date() + 1) - 1;
                            break;
                        case"hour":
                            t = this._d.valueOf(), t += fn - pn(t + (this._isUTC ? 0 : this.utcOffset() * dn), fn) - 1;
                            break;
                        case"minute":
                            t = this._d.valueOf(), t += dn - pn(t, dn) - 1;
                            break;
                        case"second":
                            t = this._d.valueOf(), t += cn - pn(t, cn) - 1
                    }
                    return this._d.setTime(t), r.updateOffset(this, !0), this
                }, Mn.format = function (e) {
                    e || (e = this.isUtc() ? r.defaultFormatUtc : r.defaultFormat);
                    var t = Y(this, e);
                    return this.localeData().postformat(t)
                }, Mn.from = function (e, t) {
                    return this.isValid() && (b(e) && e.isValid() || Pt(e).isValid()) ? Zt({
                        to: this,
                        from: e
                    }).locale(this.locale()).humanize(!t) : this.localeData().invalidDate()
                }, Mn.fromNow = function (e) {
                    return this.from(Pt(), e)
                }, Mn.to = function (e, t) {
                    return this.isValid() && (b(e) && e.isValid() || Pt(e).isValid()) ? Zt({
                        from: this,
                        to: e
                    }).locale(this.locale()).humanize(!t) : this.localeData().invalidDate()
                }, Mn.toNow = function (e) {
                    return this.to(Pt(), e)
                }, Mn.get = function (e) {
                    return C(this[e = F(e)]) ? this[e]() : this
                }, Mn.invalidAt = function () {
                    return p(this).overflow
                }, Mn.isAfter = function (e, t) {
                    var n = b(e) ? e : Pt(e);
                    return !(!this.isValid() || !n.isValid()) && ("millisecond" === (t = F(t) || "millisecond") ? this.valueOf() > n.valueOf() : n.valueOf() < this.clone().startOf(t).valueOf())
                }, Mn.isBefore = function (e, t) {
                    var n = b(e) ? e : Pt(e);
                    return !(!this.isValid() || !n.isValid()) && ("millisecond" === (t = F(t) || "millisecond") ? this.valueOf() < n.valueOf() : this.clone().endOf(t).valueOf() < n.valueOf())
                }, Mn.isBetween = function (e, t, n, r) {
                    var i = b(e) ? e : Pt(e), o = b(t) ? t : Pt(t);
                    return !!(this.isValid() && i.isValid() && o.isValid()) && ("(" === (r = r || "()")[0] ? this.isAfter(i, n) : !this.isBefore(i, n)) && (")" === r[1] ? this.isBefore(o, n) : !this.isAfter(o, n))
                }, Mn.isSame = function (e, t) {
                    var n, r = b(e) ? e : Pt(e);
                    return !(!this.isValid() || !r.isValid()) && ("millisecond" === (t = F(t) || "millisecond") ? this.valueOf() === r.valueOf() : (n = r.valueOf(), this.clone().startOf(t).valueOf() <= n && n <= this.clone().endOf(t).valueOf()))
                }, Mn.isSameOrAfter = function (e, t) {
                    return this.isSame(e, t) || this.isAfter(e, t)
                }, Mn.isSameOrBefore = function (e, t) {
                    return this.isSame(e, t) || this.isBefore(e, t)
                }, Mn.isValid = function () {
                    return m(this)
                }, Mn.lang = un, Mn.locale = sn, Mn.localeData = ln, Mn.max = Yt, Mn.min = Rt, Mn.parsingFlags = function () {
                    return f({}, p(this))
                }, Mn.set = function (e, t) {
                    if ("object" == typeof e) {
                        var n, r = function (e) {
                            var t, n = [];
                            for (t in e) a(e, t) && n.push({unit: t, priority: W[t]});
                            return n.sort((function (e, t) {
                                return e.priority - t.priority
                            })), n
                        }(e = U(e)), i = r.length;
                        for (n = 0; n < i; n++) this[r[n].unit](e[r[n].unit])
                    } else if (C(this[e = F(e)])) return this[e](t);
                    return this
                }, Mn.startOf = function (e) {
                    var t, n;
                    if (void 0 === (e = F(e)) || "millisecond" === e || !this.isValid()) return this;
                    switch (n = this._isUTC ? gn : mn, e) {
                        case"year":
                            t = n(this.year(), 0, 1);
                            break;
                        case"quarter":
                            t = n(this.year(), this.month() - this.month() % 3, 1);
                            break;
                        case"month":
                            t = n(this.year(), this.month(), 1);
                            break;
                        case"week":
                            t = n(this.year(), this.month(), this.date() - this.weekday());
                            break;
                        case"isoWeek":
                            t = n(this.year(), this.month(), this.date() - (this.isoWeekday() - 1));
                            break;
                        case"day":
                        case"date":
                            t = n(this.year(), this.month(), this.date());
                            break;
                        case"hour":
                            t = this._d.valueOf(), t -= pn(t + (this._isUTC ? 0 : this.utcOffset() * dn), fn);
                            break;
                        case"minute":
                            t = this._d.valueOf(), t -= pn(t, dn);
                            break;
                        case"second":
                            t = this._d.valueOf(), t -= pn(t, cn)
                    }
                    return this._d.setTime(t), r.updateOffset(this, !0), this
                }, Mn.subtract = nn, Mn.toArray = function () {
                    var e = this;
                    return [e.year(), e.month(), e.date(), e.hour(), e.minute(), e.second(), e.millisecond()]
                }, Mn.toObject = function () {
                    var e = this;
                    return {
                        years: e.year(),
                        months: e.month(),
                        date: e.date(),
                        hours: e.hours(),
                        minutes: e.minutes(),
                        seconds: e.seconds(),
                        milliseconds: e.milliseconds()
                    }
                }, Mn.toDate = function () {
                    return new Date(this.valueOf())
                }, Mn.toISOString = function (e) {
                    if (!this.isValid()) return null;
                    var t = !0 !== e, n = t ? this.clone().utc() : this;
                    return n.year() < 0 || n.year() > 9999 ? Y(n, t ? "YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]" : "YYYYYY-MM-DD[T]HH:mm:ss.SSSZ") : C(Date.prototype.toISOString) ? t ? this.toDate().toISOString() : new Date(this.valueOf() + 60 * this.utcOffset() * 1e3).toISOString().replace("Z", Y(n, "Z")) : Y(n, t ? "YYYY-MM-DD[T]HH:mm:ss.SSS[Z]" : "YYYY-MM-DD[T]HH:mm:ss.SSSZ")
                }, Mn.inspect = function () {
                    if (!this.isValid()) return "moment.invalid(/* " + this._i + " */)";
                    var e, t, n, r = "moment", i = "";
                    return this.isLocal() || (r = 0 === this.utcOffset() ? "moment.utc" : "moment.parseZone", i = "Z"), e = "[" + r + '("]', t = 0 <= this.year() && this.year() <= 9999 ? "YYYY" : "YYYYYY", "-MM-DD[T]HH:mm:ss.SSS", n = i + '[")]', this.format(e + t + "-MM-DD[T]HH:mm:ss.SSS" + n)
                }, "undefined" != typeof Symbol && null != Symbol.for && (Mn[Symbol.for("nodejs.util.inspect.custom")] = function () {
                    return "Moment<" + this.format() + ">"
                }), Mn.toJSON = function () {
                    return this.isValid() ? this.toISOString() : null
                }, Mn.toString = function () {
                    return this.clone().locale("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ")
                }, Mn.unix = function () {
                    return Math.floor(this.valueOf() / 1e3)
                }, Mn.valueOf = function () {
                    return this._d.valueOf() - 6e4 * (this._offset || 0)
                }, Mn.creationData = function () {
                    return {
                        input: this._i,
                        format: this._f,
                        locale: this._locale,
                        isUTC: this._isUTC,
                        strict: this._strict
                    }
                }, Mn.eraName = function () {
                    var e, t, n, r = this.localeData().eras();
                    for (e = 0, t = r.length; e < t; ++e) {
                        if (n = this.clone().startOf("day").valueOf(), r[e].since <= n && n <= r[e].until) return r[e].name;
                        if (r[e].until <= n && n <= r[e].since) return r[e].name
                    }
                    return ""
                }, Mn.eraNarrow = function () {
                    var e, t, n, r = this.localeData().eras();
                    for (e = 0, t = r.length; e < t; ++e) {
                        if (n = this.clone().startOf("day").valueOf(), r[e].since <= n && n <= r[e].until) return r[e].narrow;
                        if (r[e].until <= n && n <= r[e].since) return r[e].narrow
                    }
                    return ""
                }, Mn.eraAbbr = function () {
                    var e, t, n, r = this.localeData().eras();
                    for (e = 0, t = r.length; e < t; ++e) {
                        if (n = this.clone().startOf("day").valueOf(), r[e].since <= n && n <= r[e].until) return r[e].abbr;
                        if (r[e].until <= n && n <= r[e].since) return r[e].abbr
                    }
                    return ""
                }, Mn.eraYear = function () {
                    var e, t, n, i, o = this.localeData().eras();
                    for (e = 0, t = o.length; e < t; ++e) if (n = o[e].since <= o[e].until ? 1 : -1, i = this.clone().startOf("day").valueOf(), o[e].since <= i && i <= o[e].until || o[e].until <= i && i <= o[e].since) return (this.year() - r(o[e].since).year()) * n + o[e].offset;
                    return this.year()
                }, Mn.year = Ue, Mn.isLeapYear = function () {
                    return B(this.year())
                }, Mn.weekYear = function (e) {
                    return _n.call(this, e, this.week(), this.weekday(), this.localeData()._week.dow, this.localeData()._week.doy)
                }, Mn.isoWeekYear = function (e) {
                    return _n.call(this, e, this.isoWeek(), this.isoWeekday(), 1, 4)
                }, Mn.quarter = Mn.quarters = function (e) {
                    return null == e ? Math.ceil((this.month() + 1) / 3) : this.month(3 * (e - 1) + this.month() % 3)
                }, Mn.month = Ie, Mn.daysInMonth = function () {
                    return Oe(this.year(), this.month())
                }, Mn.week = Mn.weeks = function (e) {
                    var t = this.localeData().week(this);
                    return null == e ? t : this.add(7 * (e - t), "d")
                }, Mn.isoWeek = Mn.isoWeeks = function (e) {
                    var t = Ve(this, 1, 4).week;
                    return null == e ? t : this.add(7 * (e - t), "d")
                }, Mn.weeksInYear = function () {
                    var e = this.localeData()._week;
                    return $e(this.year(), e.dow, e.doy)
                }, Mn.weeksInWeekYear = function () {
                    var e = this.localeData()._week;
                    return $e(this.weekYear(), e.dow, e.doy)
                }, Mn.isoWeeksInYear = function () {
                    return $e(this.year(), 1, 4)
                }, Mn.isoWeeksInISOWeekYear = function () {
                    return $e(this.isoWeekYear(), 1, 4)
                }, Mn.date = xn, Mn.day = Mn.days = function (e) {
                    if (!this.isValid()) return null != e ? this : NaN;
                    var t = this._isUTC ? this._d.getUTCDay() : this._d.getDay();
                    return null != e ? (e = function (e, t) {
                        return "string" != typeof e ? e : isNaN(e) ? "number" == typeof (e = t.weekdaysParse(e)) ? e : null : parseInt(e, 10)
                    }(e, this.localeData()), this.add(e - t, "d")) : t
                }, Mn.weekday = function (e) {
                    if (!this.isValid()) return null != e ? this : NaN;
                    var t = (this.day() + 7 - this.localeData()._week.dow) % 7;
                    return null == e ? t : this.add(e - t, "d")
                }, Mn.isoWeekday = function (e) {
                    if (!this.isValid()) return null != e ? this : NaN;
                    if (null != e) {
                        var t = function (e, t) {
                            return "string" == typeof e ? t.weekdaysParse(e) % 7 || 7 : isNaN(e) ? null : e
                        }(e, this.localeData());
                        return this.day(this.day() % 7 ? t : t - 7)
                    }
                    return this.day() || 7
                }, Mn.dayOfYear = function (e) {
                    var t = Math.round((this.clone().startOf("day") - this.clone().startOf("year")) / 864e5) + 1;
                    return null == e ? t : this.add(e - t, "d")
                }, Mn.hour = Mn.hours = at, Mn.minute = Mn.minutes = kn, Mn.second = Mn.seconds = Dn, Mn.millisecond = Mn.milliseconds = Tn, Mn.utcOffset = function (e, t, n) {
                    var i, o = this._offset || 0;
                    if (!this.isValid()) return null != e ? this : NaN;
                    if (null != e) {
                        if ("string" == typeof e) {
                            if (null === (e = Bt(de, e))) return this
                        } else Math.abs(e) < 16 && !n && (e *= 60);
                        return !this._isUTC && t && (i = Vt(this)), this._offset = e, this._isUTC = !0, null != i && this.add(i, "m"), o !== e && (!t || this._changeInProgress ? en(this, Zt(e - o, "m"), 1, !1) : this._changeInProgress || (this._changeInProgress = !0, r.updateOffset(this, !0), this._changeInProgress = null)), this
                    }
                    return this._isUTC ? o : Vt(this)
                }, Mn.utc = function (e) {
                    return this.utcOffset(0, e)
                }, Mn.local = function (e) {
                    return this._isUTC && (this.utcOffset(0, e), this._isUTC = !1, e && this.subtract(Vt(this), "m")), this
                }, Mn.parseZone = function () {
                    if (null != this._tzm) this.utcOffset(this._tzm, !1, !0); else if ("string" == typeof this._i) {
                        var e = Bt(ce, this._i);
                        null != e ? this.utcOffset(e) : this.utcOffset(0, !0)
                    }
                    return this
                }, Mn.hasAlignedHourOffset = function (e) {
                    return !!this.isValid() && (e = e ? Pt(e).utcOffset() : 0, (this.utcOffset() - e) % 60 == 0)
                }, Mn.isDST = function () {
                    return this.utcOffset() > this.clone().month(0).utcOffset() || this.utcOffset() > this.clone().month(5).utcOffset()
                }, Mn.isLocal = function () {
                    return !!this.isValid() && !this._isUTC
                }, Mn.isUtcOffset = function () {
                    return !!this.isValid() && this._isUTC
                }, Mn.isUtc = $t, Mn.isUTC = $t, Mn.zoneAbbr = function () {
                    return this._isUTC ? "UTC" : ""
                }, Mn.zoneName = function () {
                    return this._isUTC ? "Coordinated Universal Time" : ""
                }, Mn.dates = k("dates accessor is deprecated. Use date instead.", xn), Mn.months = k("months accessor is deprecated. Use month instead", Ie), Mn.years = k("years accessor is deprecated. Use year instead", Ue), Mn.zone = k("moment().zone is deprecated, use moment().utcOffset instead. http://momentjs.com/guides/#/warnings/zone/", (function (e, t) {
                    return null != e ? ("string" != typeof e && (e = -e), this.utcOffset(e, t), this) : -this.utcOffset()
                })), Mn.isDSTShifted = k("isDSTShifted is deprecated. See http://momentjs.com/guides/#/warnings/dst-shifted/ for more information", (function () {
                    if (!u(this._isDSTShifted)) return this._isDSTShifted;
                    var e, t = {};
                    return w(t, this), (t = At(t))._a ? (e = t._isUTC ? h(t._a) : Pt(t._a), this._isDSTShifted = this.isValid() && function (e, t, n) {
                        var r, i = Math.min(e.length, t.length), o = Math.abs(e.length - t.length), a = 0;
                        for (r = 0; r < i; r++) (n && e[r] !== t[r] || !n && V(e[r]) !== V(t[r])) && a++;
                        return a + o
                    }(t._a, e.toArray()) > 0) : this._isDSTShifted = !1, this._isDSTShifted
                }));
                var On = N.prototype;

                function En(e, t, n, r) {
                    var i = gt(), o = h().set(r, t);
                    return i[n](o, e)
                }

                function An(e, t, n) {
                    if (l(e) && (t = e, e = void 0), e = e || "", null != t) return En(e, t, n, "month");
                    var r, i = [];
                    for (r = 0; r < 12; r++) i[r] = En(e, r, n, "month");
                    return i
                }

                function jn(e, t, n, r) {
                    "boolean" == typeof e ? (l(t) && (n = t, t = void 0), t = t || "") : (n = t = e, e = !1, l(t) && (n = t, t = void 0), t = t || "");
                    var i, o = gt(), a = e ? o._week.dow : 0, s = [];
                    if (null != n) return En(t, (n + a) % 7, r, "day");
                    for (i = 0; i < 7; i++) s[i] = En(t, (i + a) % 7, r, "day");
                    return s
                }

                On.calendar = function (e, t, n) {
                    var r = this._calendar[e] || this._calendar.sameElse;
                    return C(r) ? r.call(t, n) : r
                }, On.longDateFormat = function (e) {
                    var t = this._longDateFormat[e], n = this._longDateFormat[e.toUpperCase()];
                    return t || !n ? t : (this._longDateFormat[e] = n.match(E).map((function (e) {
                        return "MMMM" === e || "MM" === e || "DD" === e || "dddd" === e ? e.slice(1) : e
                    })).join(""), this._longDateFormat[e])
                }, On.invalidDate = function () {
                    return this._invalidDate
                }, On.ordinal = function (e) {
                    return this._ordinal.replace("%d", e)
                }, On.preparse = Nn, On.postformat = Nn, On.relativeTime = function (e, t, n, r) {
                    var i = this._relativeTime[n];
                    return C(i) ? i(e, t, n, r) : i.replace(/%d/i, e)
                }, On.pastFuture = function (e, t) {
                    var n = this._relativeTime[e > 0 ? "future" : "past"];
                    return C(n) ? n(t) : n.replace(/%s/i, t)
                }, On.set = function (e) {
                    var t, n;
                    for (n in e) a(e, n) && (C(t = e[n]) ? this[n] = t : this["_" + n] = t);
                    this._config = e, this._dayOfMonthOrdinalParseLenient = new RegExp((this._dayOfMonthOrdinalParse.source || this._ordinalParse.source) + "|" + /\d{1,2}/.source)
                }, On.eras = function (e, t) {
                    var n, i, o, a = this._eras || gt("en")._eras;
                    for (n = 0, i = a.length; n < i; ++n) switch ("string" == typeof a[n].since && (o = r(a[n].since).startOf("day"), a[n].since = o.valueOf()), typeof a[n].until) {
                        case"undefined":
                            a[n].until = 1 / 0;
                            break;
                        case"string":
                            o = r(a[n].until).startOf("day").valueOf(), a[n].until = o.valueOf()
                    }
                    return a
                }, On.erasParse = function (e, t, n) {
                    var r, i, o, a, s, u = this.eras();
                    for (e = e.toUpperCase(), r = 0, i = u.length; r < i; ++r) if (o = u[r].name.toUpperCase(), a = u[r].abbr.toUpperCase(), s = u[r].narrow.toUpperCase(), n) switch (t) {
                        case"N":
                        case"NN":
                        case"NNN":
                            if (a === e) return u[r];
                            break;
                        case"NNNN":
                            if (o === e) return u[r];
                            break;
                        case"NNNNN":
                            if (s === e) return u[r]
                    } else if ([o, a, s].indexOf(e) >= 0) return u[r]
                }, On.erasConvertYear = function (e, t) {
                    var n = e.since <= e.until ? 1 : -1;
                    return void 0 === t ? r(e.since).year() : r(e.since).year() + (t - e.offset) * n
                }, On.erasAbbrRegex = function (e) {
                    return a(this, "_erasAbbrRegex") || vn.call(this), e ? this._erasAbbrRegex : this._erasRegex
                }, On.erasNameRegex = function (e) {
                    return a(this, "_erasNameRegex") || vn.call(this), e ? this._erasNameRegex : this._erasRegex
                }, On.erasNarrowRegex = function (e) {
                    return a(this, "_erasNarrowRegex") || vn.call(this), e ? this._erasNarrowRegex : this._erasRegex
                }, On.months = function (e, t) {
                    return e ? i(this._months) ? this._months[e.month()] : this._months[(this._months.isFormat || je).test(t) ? "format" : "standalone"][e.month()] : i(this._months) ? this._months : this._months.standalone
                }, On.monthsShort = function (e, t) {
                    return e ? i(this._monthsShort) ? this._monthsShort[e.month()] : this._monthsShort[je.test(t) ? "format" : "standalone"][e.month()] : i(this._monthsShort) ? this._monthsShort : this._monthsShort.standalone
                }, On.monthsParse = function (e, t, n) {
                    var r, i, o;
                    if (this._monthsParseExact) return Ye.call(this, e, t, n);
                    for (this._monthsParse || (this._monthsParse = [], this._longMonthsParse = [], this._shortMonthsParse = []), r = 0; r < 12; r++) {
                        if (i = h([2e3, r]), n && !this._longMonthsParse[r] && (this._longMonthsParse[r] = new RegExp("^" + this.months(i, "").replace(".", "") + "$", "i"), this._shortMonthsParse[r] = new RegExp("^" + this.monthsShort(i, "").replace(".", "") + "$", "i")), n || this._monthsParse[r] || (o = "^" + this.months(i, "") + "|^" + this.monthsShort(i, ""), this._monthsParse[r] = new RegExp(o.replace(".", ""), "i")), n && "MMMM" === t && this._longMonthsParse[r].test(e)) return r;
                        if (n && "MMM" === t && this._shortMonthsParse[r].test(e)) return r;
                        if (!n && this._monthsParse[r].test(e)) return r
                    }
                }, On.monthsRegex = function (e) {
                    return this._monthsParseExact ? (a(this, "_monthsRegex") || He.call(this), e ? this._monthsStrictRegex : this._monthsRegex) : (a(this, "_monthsRegex") || (this._monthsRegex = Re), this._monthsStrictRegex && e ? this._monthsStrictRegex : this._monthsRegex)
                }, On.monthsShortRegex = function (e) {
                    return this._monthsParseExact ? (a(this, "_monthsRegex") || He.call(this), e ? this._monthsShortStrictRegex : this._monthsShortRegex) : (a(this, "_monthsShortRegex") || (this._monthsShortRegex = Pe), this._monthsShortStrictRegex && e ? this._monthsShortStrictRegex : this._monthsShortRegex)
                }, On.week = function (e) {
                    return Ve(e, this._week.dow, this._week.doy).week
                }, On.firstDayOfYear = function () {
                    return this._week.doy
                }, On.firstDayOfWeek = function () {
                    return this._week.dow
                }, On.weekdays = function (e, t) {
                    var n = i(this._weekdays) ? this._weekdays : this._weekdays[e && !0 !== e && this._weekdays.isFormat.test(t) ? "format" : "standalone"];
                    return !0 === e ? ze(n, this._week.dow) : e ? n[e.day()] : n
                }, On.weekdaysMin = function (e) {
                    return !0 === e ? ze(this._weekdaysMin, this._week.dow) : e ? this._weekdaysMin[e.day()] : this._weekdaysMin
                }, On.weekdaysShort = function (e) {
                    return !0 === e ? ze(this._weekdaysShort, this._week.dow) : e ? this._weekdaysShort[e.day()] : this._weekdaysShort
                }, On.weekdaysParse = function (e, t, n) {
                    var r, i, o;
                    if (this._weekdaysParseExact) return tt.call(this, e, t, n);
                    for (this._weekdaysParse || (this._weekdaysParse = [], this._minWeekdaysParse = [], this._shortWeekdaysParse = [], this._fullWeekdaysParse = []), r = 0; r < 7; r++) {
                        if (i = h([2e3, 1]).day(r), n && !this._fullWeekdaysParse[r] && (this._fullWeekdaysParse[r] = new RegExp("^" + this.weekdays(i, "").replace(".", "\\.?") + "$", "i"), this._shortWeekdaysParse[r] = new RegExp("^" + this.weekdaysShort(i, "").replace(".", "\\.?") + "$", "i"), this._minWeekdaysParse[r] = new RegExp("^" + this.weekdaysMin(i, "").replace(".", "\\.?") + "$", "i")), this._weekdaysParse[r] || (o = "^" + this.weekdays(i, "") + "|^" + this.weekdaysShort(i, "") + "|^" + this.weekdaysMin(i, ""), this._weekdaysParse[r] = new RegExp(o.replace(".", ""), "i")), n && "dddd" === t && this._fullWeekdaysParse[r].test(e)) return r;
                        if (n && "ddd" === t && this._shortWeekdaysParse[r].test(e)) return r;
                        if (n && "dd" === t && this._minWeekdaysParse[r].test(e)) return r;
                        if (!n && this._weekdaysParse[r].test(e)) return r
                    }
                }, On.weekdaysRegex = function (e) {
                    return this._weekdaysParseExact ? (a(this, "_weekdaysRegex") || nt.call(this), e ? this._weekdaysStrictRegex : this._weekdaysRegex) : (a(this, "_weekdaysRegex") || (this._weekdaysRegex = Qe), this._weekdaysStrictRegex && e ? this._weekdaysStrictRegex : this._weekdaysRegex)
                }, On.weekdaysShortRegex = function (e) {
                    return this._weekdaysParseExact ? (a(this, "_weekdaysRegex") || nt.call(this), e ? this._weekdaysShortStrictRegex : this._weekdaysShortRegex) : (a(this, "_weekdaysShortRegex") || (this._weekdaysShortRegex = Ke), this._weekdaysShortStrictRegex && e ? this._weekdaysShortStrictRegex : this._weekdaysShortRegex)
                }, On.weekdaysMinRegex = function (e) {
                    return this._weekdaysParseExact ? (a(this, "_weekdaysRegex") || nt.call(this), e ? this._weekdaysMinStrictRegex : this._weekdaysMinRegex) : (a(this, "_weekdaysMinRegex") || (this._weekdaysMinRegex = et), this._weekdaysMinStrictRegex && e ? this._weekdaysMinStrictRegex : this._weekdaysMinRegex)
                }, On.isPM = function (e) {
                    return "p" === (e + "").toLowerCase().charAt(0)
                }, On.meridiem = function (e, t, n) {
                    return e > 11 ? n ? "pm" : "PM" : n ? "am" : "AM"
                }, pt("en", {
                    eras: [{
                        since: "0001-01-01",
                        until: 1 / 0,
                        offset: 1,
                        name: "Anno Domini",
                        narrow: "AD",
                        abbr: "AD"
                    }, {
                        since: "0000-12-31",
                        until: -1 / 0,
                        offset: 1,
                        name: "Before Christ",
                        narrow: "BC",
                        abbr: "BC"
                    }], dayOfMonthOrdinalParse: /\d{1,2}(th|st|nd|rd)/, ordinal: function (e) {
                        var t = e % 10;
                        return e + (1 === V(e % 100 / 10) ? "th" : 1 === t ? "st" : 2 === t ? "nd" : 3 === t ? "rd" : "th")
                    }
                }), r.lang = k("moment.lang is deprecated. Use moment.locale instead.", pt), r.langData = k("moment.langData is deprecated. Use moment.localeData instead.", gt);
                var Pn = Math.abs;

                function Rn(e, t, n, r) {
                    var i = Zt(t, n);
                    return e._milliseconds += r * i._milliseconds, e._days += r * i._days, e._months += r * i._months, e._bubble()
                }

                function Yn(e) {
                    return e < 0 ? Math.floor(e) : Math.ceil(e)
                }

                function Ln(e) {
                    return 4800 * e / 146097
                }

                function In(e) {
                    return 146097 * e / 4800
                }

                function Hn(e) {
                    return function () {
                        return this.as(e)
                    }
                }

                var Fn = Hn("ms"), Un = Hn("s"), Wn = Hn("m"), qn = Hn("h"), Bn = Hn("d"), Gn = Hn("w"), Vn = Hn("M"),
                    $n = Hn("Q"), zn = Hn("y");

                function Jn(e) {
                    return function () {
                        return this.isValid() ? this._data[e] : NaN
                    }
                }

                var Zn = Jn("milliseconds"), Xn = Jn("seconds"), Qn = Jn("minutes"), Kn = Jn("hours"), er = Jn("days"),
                    tr = Jn("months"), nr = Jn("years");
                var rr = Math.round, ir = {ss: 44, s: 45, m: 45, h: 22, d: 26, w: null, M: 11};

                function or(e, t, n, r, i) {
                    return i.relativeTime(t || 1, !!n, e, r)
                }

                var ar = Math.abs;

                function sr(e) {
                    return (e > 0) - (e < 0) || +e
                }

                function ur() {
                    if (!this.isValid()) return this.localeData().invalidDate();
                    var e, t, n, r, i, o, a, s, u = ar(this._milliseconds) / 1e3, l = ar(this._days),
                        c = ar(this._months), d = this.asSeconds();
                    return d ? (e = G(u / 60), t = G(e / 60), u %= 60, e %= 60, n = G(c / 12), c %= 12, r = u ? u.toFixed(3).replace(/\.?0+$/, "") : "", i = d < 0 ? "-" : "", o = sr(this._months) !== sr(d) ? "-" : "", a = sr(this._days) !== sr(d) ? "-" : "", s = sr(this._milliseconds) !== sr(d) ? "-" : "", i + "P" + (n ? o + n + "Y" : "") + (c ? o + c + "M" : "") + (l ? a + l + "D" : "") + (t || e || u ? "T" : "") + (t ? s + t + "H" : "") + (e ? s + e + "M" : "") + (u ? s + r + "S" : "")) : "P0D"
                }

                var lr = Ht.prototype;
                return lr.isValid = function () {
                    return this._isValid
                }, lr.abs = function () {
                    var e = this._data;
                    return this._milliseconds = Pn(this._milliseconds), this._days = Pn(this._days), this._months = Pn(this._months), e.milliseconds = Pn(e.milliseconds), e.seconds = Pn(e.seconds), e.minutes = Pn(e.minutes), e.hours = Pn(e.hours), e.months = Pn(e.months), e.years = Pn(e.years), this
                }, lr.add = function (e, t) {
                    return Rn(this, e, t, 1)
                }, lr.subtract = function (e, t) {
                    return Rn(this, e, t, -1)
                }, lr.as = function (e) {
                    if (!this.isValid()) return NaN;
                    var t, n, r = this._milliseconds;
                    if ("month" === (e = F(e)) || "quarter" === e || "year" === e) switch (t = this._days + r / 864e5, n = this._months + Ln(t), e) {
                        case"month":
                            return n;
                        case"quarter":
                            return n / 3;
                        case"year":
                            return n / 12
                    } else switch (t = this._days + Math.round(In(this._months)), e) {
                        case"week":
                            return t / 7 + r / 6048e5;
                        case"day":
                            return t + r / 864e5;
                        case"hour":
                            return 24 * t + r / 36e5;
                        case"minute":
                            return 1440 * t + r / 6e4;
                        case"second":
                            return 86400 * t + r / 1e3;
                        case"millisecond":
                            return Math.floor(864e5 * t) + r;
                        default:
                            throw new Error("Unknown unit " + e)
                    }
                }, lr.asMilliseconds = Fn, lr.asSeconds = Un, lr.asMinutes = Wn, lr.asHours = qn, lr.asDays = Bn, lr.asWeeks = Gn, lr.asMonths = Vn, lr.asQuarters = $n, lr.asYears = zn, lr.valueOf = function () {
                    return this.isValid() ? this._milliseconds + 864e5 * this._days + this._months % 12 * 2592e6 + 31536e6 * V(this._months / 12) : NaN
                }, lr._bubble = function () {
                    var e, t, n, r, i, o = this._milliseconds, a = this._days, s = this._months, u = this._data;
                    return o >= 0 && a >= 0 && s >= 0 || o <= 0 && a <= 0 && s <= 0 || (o += 864e5 * Yn(In(s) + a), a = 0, s = 0), u.milliseconds = o % 1e3, e = G(o / 1e3), u.seconds = e % 60, t = G(e / 60), u.minutes = t % 60, n = G(t / 60), u.hours = n % 24, a += G(n / 24), s += i = G(Ln(a)), a -= Yn(In(i)), r = G(s / 12), s %= 12, u.days = a, u.months = s, u.years = r, this
                }, lr.clone = function () {
                    return Zt(this)
                }, lr.get = function (e) {
                    return e = F(e), this.isValid() ? this[e + "s"]() : NaN
                }, lr.milliseconds = Zn, lr.seconds = Xn, lr.minutes = Qn, lr.hours = Kn, lr.days = er, lr.weeks = function () {
                    return G(this.days() / 7)
                }, lr.months = tr, lr.years = nr, lr.humanize = function (e, t) {
                    if (!this.isValid()) return this.localeData().invalidDate();
                    var n, r, i = !1, o = ir;
                    return "object" == typeof e && (t = e, e = !1), "boolean" == typeof e && (i = e), "object" == typeof t && (o = Object.assign({}, ir, t), null != t.s && null == t.ss && (o.ss = t.s - 1)), r = function (e, t, n, r) {
                        var i = Zt(e).abs(), o = rr(i.as("s")), a = rr(i.as("m")), s = rr(i.as("h")), u = rr(i.as("d")),
                            l = rr(i.as("M")), c = rr(i.as("w")), d = rr(i.as("y")),
                            f = o <= n.ss && ["s", o] || o < n.s && ["ss", o] || a <= 1 && ["m"] || a < n.m && ["mm", a] || s <= 1 && ["h"] || s < n.h && ["hh", s] || u <= 1 && ["d"] || u < n.d && ["dd", u];
                        return null != n.w && (f = f || c <= 1 && ["w"] || c < n.w && ["ww", c]), (f = f || l <= 1 && ["M"] || l < n.M && ["MM", l] || d <= 1 && ["y"] || ["yy", d])[2] = t, f[3] = +e > 0, f[4] = r, or.apply(null, f)
                    }(this, !i, o, n = this.localeData()), i && (r = n.pastFuture(+this, r)), n.postformat(r)
                }, lr.toISOString = ur, lr.toString = ur, lr.toJSON = ur, lr.locale = sn, lr.localeData = ln, lr.toIsoString = k("toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)", ur), lr.lang = un, R("X", 0, 0, "unix"), R("x", 0, 0, "valueOf"), he("x", le), he("X", /[+-]?\d+(\.\d{1,3})?/), ye("X", (function (e, t, n) {
                    n._d = new Date(1e3 * parseFloat(e))
                })), ye("x", (function (e, t, n) {
                    n._d = new Date(V(e))
                })), r.version = "2.29.4", t = Pt, r.fn = Mn, r.min = function () {
                    return Lt("isBefore", [].slice.call(arguments, 0))
                }, r.max = function () {
                    return Lt("isAfter", [].slice.call(arguments, 0))
                }, r.now = function () {
                    return Date.now ? Date.now() : +new Date
                }, r.utc = h, r.unix = function (e) {
                    return Pt(1e3 * e)
                }, r.months = function (e, t) {
                    return An(e, t, "months")
                }, r.isDate = c, r.locale = pt, r.invalid = g, r.duration = Zt, r.isMoment = b, r.weekdays = function (e, t, n) {
                    return jn(e, t, n, "weekdays")
                }, r.parseZone = function () {
                    return Pt.apply(null, arguments).parseZone()
                }, r.localeData = gt, r.isDuration = Ft, r.monthsShort = function (e, t) {
                    return An(e, t, "monthsShort")
                }, r.weekdaysMin = function (e, t, n) {
                    return jn(e, t, n, "weekdaysMin")
                }, r.defineLocale = mt, r.updateLocale = function (e, t) {
                    if (null != t) {
                        var n, r, i = ut;
                        null != lt[e] && null != lt[e].parentLocale ? lt[e].set(M(lt[e]._config, t)) : (null != (r = ht(e)) && (i = r._config), t = M(i, t), null == r && (t.abbr = e), (n = new N(t)).parentLocale = lt[e], lt[e] = n), pt(e)
                    } else null != lt[e] && (null != lt[e].parentLocale ? (lt[e] = lt[e].parentLocale, e === pt() && pt(e)) : null != lt[e] && delete lt[e]);
                    return lt[e]
                }, r.locales = function () {
                    return S(lt)
                }, r.weekdaysShort = function (e, t, n) {
                    return jn(e, t, n, "weekdaysShort")
                }, r.normalizeUnits = F, r.relativeTimeRounding = function (e) {
                    return void 0 === e ? rr : "function" == typeof e && (rr = e, !0)
                }, r.relativeTimeThreshold = function (e, t) {
                    return void 0 !== ir[e] && (void 0 === t ? ir[e] : (ir[e] = t, "s" === e && (ir.ss = t - 1), !0))
                }, r.calendarFormat = function (e, t) {
                    var n = e.diff(t, "days", !0);
                    return n < -6 ? "sameElse" : n < -1 ? "lastWeek" : n < 0 ? "lastDay" : n < 1 ? "sameDay" : n < 2 ? "nextDay" : n < 7 ? "nextWeek" : "sameElse"
                }, r.prototype = Mn, r.HTML5_FMT = {
                    DATETIME_LOCAL: "YYYY-MM-DDTHH:mm",
                    DATETIME_LOCAL_SECONDS: "YYYY-MM-DDTHH:mm:ss",
                    DATETIME_LOCAL_MS: "YYYY-MM-DDTHH:mm:ss.SSS",
                    DATE: "YYYY-MM-DD",
                    TIME: "HH:mm",
                    TIME_SECONDS: "HH:mm:ss",
                    TIME_MS: "HH:mm:ss.SSS",
                    WEEK: "GGGG-[W]WW",
                    MONTH: "YYYY-MM"
                }, r
            }()
        }, 1182: (e, t, n) => {
            const r = n(9455), i = n(9669), o = n(7340), a = n(6725);

            function s(e, t, n, r) {
                return new Promise(((i, o) => {
                    const a = "https://www.facebook.com/messages/t/" + e.user_id;
                    c(a).then((e => l(e))).then((i => u(i.id, {
                        action: "messagingThroughTabFB",
                        tab: i,
                        userData: e,
                        constructedMessage: t,
                        image: n,
                        birthdayType: r
                    }))).then((() => {
                        i()
                    })).catch((e => {
                        o(e)
                    }))
                }))
            }

            chrome.runtime.onMessage.addListener(((e, t, n) => {
                switch (e.action) {
                    case"activateTab":
                        chrome.tabs.update(t.tab.id, {active: !0}), n({status: "Tab activated"});
                        break;
                    case"getActiveTab":
                        return chrome.tabs.query({active: !0, currentWindow: !0}, (function (e) {
                            n({tabId: e[0].id})
                        })), !0;
                    case"switchToTab":
                        chrome.tabs.update(e.tabId, {active: !0});
                        break;
                    case"closeWindow":
                        chrome.tabs.remove(t.tab.id)
                }
            }));
            const u = async (e, t) => await new Promise(((n, r) => {
                try {
                    chrome.tabs.sendMessage(e, t, (function (t) {
                        n(e)
                    }))
                } catch (e) {
                    r(e.message)
                }
            })), l = e => new Promise(((t, n) => {
                try {
                    chrome.tabs.onUpdated.addListener((function n(r, i) {
                        "complete" === i.status && r === e.id && (chrome.tabs.onUpdated.removeListener(n), e.status = i.status, t(e))
                    }))
                } catch (e) {
                    n(e.message)
                }
            })), c = (e, t = null) => new Promise(((t, n) => {
                try {
                    chrome.storage.sync.get(["generalMessagetabID"], (function (n) {
                        n.generalMessagetabID ? chrome.tabs.get(n.generalMessagetabID, (function (r) {
                            r ? chrome.tabs.update(n.generalMessagetabID, {url: e, active: !1}, (function (e) {
                                t(e)
                            })) : chrome.storage.sync.remove(["generalMessagetabID"], (function () {
                                d(e, t)
                            }))
                        })) : d(e, t)
                    }))
                } catch (e) {
                    n(e.message)
                }
            })), d = (e, t) => {
                chrome.tabs.create({url: e, active: !1, pinned: !0}, (function (e) {
                    chrome.storage.sync.set({generalMessagetabID: e.id}, (function () {
                        t(e)
                    }))
                }))
            }, f = async e => {
                var t = {status: !0, data: [], message: ""};
                return new Promise((async function (e, n) {
                    let r = await new Promise((function (e, t) {
                        fetch("https://www.facebook.com/", {
                            method: "GET",
                            headers: {accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"}
                        }).then((e => e.text())).then((t => {
                            const n = /"ACCOUNT_ID":"([^"]+)"|USER_ID":"([^"]+)"|NAME":"([^"]+)"/g;
                            let r;
                            for (var i = {isError: !0}; r = n.exec(t);) r[1] ? i.ACCOUNT_ID = r[1] : r[2] ? i.USER_ID = r[2] : r[3] && (i.NAME = r[3]);
                            const o = t.match(/"DTSGInitialData".*?"token"\s*:\s*"([^"]+)"/);
                            o && (i.isError = !1, i.token = o[1]), e(i)
                        })).catch((t => {
                            e({isError: !0})
                        }))
                    }));
                    return !0 === r.isError ? (t.status = !1, t.message = "Please log in to Facebook to use LSD", e(t)) : (t.status = !0, t.message = "Successfully Fetched Fb Ids", t.data = {
                        dtsg: r.token,
                        fbId: r.USER_ID
                    }, e(t))
                }))
            }, h = function (e) {
                return null != e && null !== e.store && void 0 !== e.store && null !== e.store.user && void 0 !== e.store.user ? e.store.user.token : null
            }, p = () => new Promise(((e, t) => {
                chrome.storage.local.get("emailID", (function (t) {
                    e(t.emailID)
                }))
            })), m = async (e, t, n) => new Promise((async (r, i) => {
                var o = await fetch(n), a = await o.blob(),
                    s = {source: 8, profile_id: t, waterfallxapp: "comet", farr: a, upload_id: "jsc_c_7n"},
                    u = await fetch(`https://upload.facebook.com/ajax/react_composer/attachments/photo/upload?av=${t}&__user=${t}&__a=1&dpr=1&__comet_req=1&fb_dtsg=${e}`, {
                        method: "POST",
                        credentials: "include",
                        headers: {Accept: "*/*", Origin: "https://www.facebook.com"},
                        body: (e => {
                            var t = new FormData;
                            for (var n in e) t.append(n, e[n]);
                            return t
                        })(s)
                    }), l = await u.text();
                (l = function (e) {
                    let t = e.replace(/for\s*\(\s*;\s*;\s*\)\s*;\s*/, "");
                    return JSON.parse(t)
                }(l)).payload && l.payload.photoID ? r({
                    status: !0,
                    payload: {photoID: l.payload.photoID}
                }) : r({status: !1, payload: {}})
            }));
            e.exports = {
                retriveGroups: () => new Promise(((e, t) => {
                    try {
                        chrome.storage.sync.get("fcmessages", (function (t) {
                            void 0 === t.fcmessages || 0 === typeof t.fcmessages.groups.length ? e(new Array) : e(t.fcmessages.groups)
                        }))
                    } catch (t) {
                        e(new Array)
                    }
                })),
                checkAccessToken: function (e) {
                    const t = h(e);
                    return null != t && t.length > 0
                },
                getAccessToken: h,
                doAuthCheck: function (e) {
                    return null != e && e.length > 0
                },
                getLoggedInUser: p,
                retriveSegmentGroups: () => new Promise(((e, t) => {
                    try {
                        chrome.storage.local.get(["store"], (function (t) {
                            let n = {bw_token: t.store.user.bw_token},
                                i = r.bw_base_url + r.bw_apis.message.segments.getAll;
                            o.makeApiRequest("POST", n, i, {}).then((t => {
                                e(t.payload.data)
                            })).catch((t => {
                                e(new Array)
                            }))
                        }))
                    } catch (t) {
                        e(new Array)
                    }
                })),
                checkUserStatus: function (e) {
                    return p(), new Promise((function (t, n) {
                        fetch(a.checkUserStatusURL, {
                            method: "POST",
                            mode: "cors",
                            headers: {"Content-Type": "application/json"},
                            body: JSON.stringify({userToken: e})
                        }).then((e => e.json())).then((e => {
                            0 == e.status ? n(!1) : t(!0)
                        })).catch((e => {
                            n(!1)
                        }))
                    }))
                },
                getSettings: () => new Promise(((e, t) => {
                    try {
                        chrome.storage.sync.get(["settings"], (function (t) {
                            !function (e) {
                                for (var t in e) if (e.hasOwnProperty(t)) return !1;
                                return !0
                            }(t) ? e(t.settings) : e(new Array)
                        }))
                    } catch (t) {
                        e(new Array)
                    }
                })),
                saveSettings: e => new Promise(((t, n) => {
                    try {
                        chrome.storage.sync.set({settings: e}, (function (e) {
                            t(!0)
                        }))
                    } catch (e) {
                        t(!1)
                    }
                })),
                checkAuthStatus: () => {
                    chrome.storage.local.get(["store"], (function (e) {
                        null != e.store.user.email || null != e.store.user.email || "" != e.store.user.email ? fetch(a.checkUserStatusURL, {
                            method: "POST",
                            mode: "cors",
                            headers: {"Content-Type": "application/json"},
                            body: JSON.stringify({
                                email: e.store.user.email,
                                extId: a.extId,
                                deviceId: e.store.user.uid
                            })
                        }).then((e => e.json())).then((t => {
                            const n = t.data ? t.data : t;
                            if (!1 === n.status) chrome.storage.local.remove("store", (function () {
                                window.location.replace("../login.html")
                            })); else {
                                let t = JSON.stringify(e.store), i = JSON.parse(t);
                                i.user.plan = n.plan, chrome.storage.local.set({store: i}, (function () {
                                }));
                                let a = {bw_token: e.store.user.bw_token}, s = r.bw_base_url + r.bw_apis.checkStatus;
                                o.makeApiRequest("POST", a, s, {Authorization: "KYUBI_" + bw_token}).then((e => {
                                    e.status || chrome.storage.local.remove("store", (function () {
                                        window.location.replace("../login.html")
                                    }))
                                }))
                            }
                        })).catch((e => {
                        })) : window.location.href = "../login.html"
                    }))
                },
                parseAndFindDTSG: e => {
                    let t = "";
                    const n = /[\\]{0,2}["]{1}dtsg[\\]{0,2}["]{1}[:]+.[\\]{0,2}["]{1}token[\\]{0,2}["]{1}[:]{1}[\\]{0,2}["]{1}[a-zA-Z0-9_:-]+/g,
                        r = /name=[\\]{0,2}["]{1}fb_dtsg[\\]{0,2}["]{1}\svalue=[\\]{0,2}["]{1}[a-zA-Z0-9:_-]+/g,
                        i = /\\"dtsg\\":\{[^}]*\}/gm;
                    return null != e.match(i) ? (t = e.match(i)[0], t = "{" + t.replace(/[\\]/g, "") + "}", t = JSON.parse(t).dtsg, t.token) : (n.test(e) ? t = e.match(n)[0].split("token")[1].match(/[a-zA-Z0-9_-]+.[a-zA-Z0-9_-]+/g)[0] : r.test(e) && (t = e.match(r)[0].split("value")[1].match(/[a-zA-Z0-9_-]+.[a-zA-Z0-9_-]+/g)[0]), t)
                },
                parseAndFindFbId: function (e) {
                    let t = "";
                    const n = /USER_ID[\\":]+[0-9]+/g, r = /name=[\\":]+target[\\":]+\svalue=[\\":]+[0-9]+/g;
                    return n.test(e) ? t = +e.match(n)[0].match(/[0-9]+/g)[0] : r.test(e) && (t = +e.match(r)[0].match(/[0-9]+/g)[0]), t
                },
                getDtsg: f,
                scanFB: async () => new Promise((async (e, t) => {
                    try {
                        f().then((async t => {
                            if (t.status) {
                                let n = function (e) {
                                    let t = [];
                                    for (let n in e) e.hasOwnProperty(n) && t.push(encodeURIComponent(n) + "=" + encodeURIComponent(e[n]));
                                    return t.join("&")
                                }, r = {
                                    __user: t.data.fbId,
                                    fb_dtsg: t.data.dtsg,
                                    fb_api_caller_class: "RelayModern",
                                    fb_api_req_friendly_name: "BirthdayCometRootQuery",
                                    server_timestamps: !0,
                                    doc_id: "4576878779047229",
                                    variables: JSON.stringify({offset_month: -2, scale: 1})
                                }, i = await fetch("https://www.facebook.com/api/graphql/", {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/x-www-form-urlencoded",
                                        "x-fb-friendly-name": "BirthdayCometRootQuery"
                                    },
                                    body: n(r)
                                });
                                response = await i.json(), e({
                                    todays_birthdays: null != response.data && null != response.data.viewer ? response.data.viewer.all_friends.edges : [],
                                    monthly_birthdays: null != response.data && null != response.data.viewer ? response.data.viewer.all_friends_by_birthday_month.edges : []
                                })
                            }
                        }))
                    } catch (t) {
                        e({
                            todays_birthdays: [],
                            monthly_birthdays: [],
                            status: !1,
                            message: "This is coming from scan fb catch block"
                        })
                    }
                })),
                chill: e => new Promise(((t, n) => {
                    setTimeout((() => {
                        t(!0)
                    }), e)
                })),
                toast: (e, t, n, r, i = 70, o = "auto", a = 450, s = "auto") => {
                    try {
                        $.toast({
                            heading: e,
                            text: t,
                            showHideTransition: "slide",
                            bgColor: n,
                            textColor: "#eee",
                            allowToastClose: !1,
                            hideAfter: 3e3,
                            stack: 1,
                            textAlign: "left",
                            position: {left: i, right: o, top: a, bottom: s},
                            icon: r
                        })
                    } catch (e) {
                    }
                },
                fetchTodaysDay: () => ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][(new Date).getDay()],
                getCurrentPlan: () => new Promise(((e, t) => {
                    chrome.storage.local.get(["store"], (function (t) {
                        null == t.store.user.email && null == t.store.user.email && "" == t.store.user.email || fetch(a.checkUserStatusURL, {
                            method: "POST",
                            mode: "cors",
                            headers: {"Content-Type": "application/json"},
                            body: JSON.stringify({
                                email: t.store.user.email,
                                extId: a.extId,
                                deviceId: t.store.user.uid
                            })
                        }).then((e => e.json())).then((t => {
                            const n = t.data ? t.data : t;
                            1 == n.status ? e(n.plan) : e("0")
                        }))
                    }))
                })),
                lateComer: (e, t) => Math.floor(e + Math.random() * (t - e)),
                createCaretPlacer: (e, t, n) => {
                    var r = e;
                    if (r) if (r.focus(), void 0 !== window.getSelection && void 0 !== document.createRange) {
                        var i = document.createRange();
                        i.selectNodeContents(r), t && i.collapse(n);
                        var o = window.getSelection();
                        o.removeAllRanges(), o.addRange(i)
                    } else if (void 0 !== document.body.createTextRange) {
                        var a = document.body.createTextRange();
                        a.moveToElementText(r), t && a.collapse(n), a.select()
                    }
                },
                fetchFbToken: () => new Promise((async (e, t) => {
                    try {
                        await i.get("https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed")
                    } catch (e) {
                        t(e.message)
                    }
                })),
                createPostOnUsersTimeline: async (e, t, n, r, i = null) => new Promise((async (o, a) => {
                    try {
                        let a = await f(), d = [];
                        if (null != i) {
                            let e = await m(a.data.dtsg, a.data.fbId, i);
                            1 == e.status && d.push({photo: {id: e.payload.photoID}})
                        }
                        var s = a.data.fbId, u = {
                            input: {
                                composer_entry_point: "inline_composer",
                                composer_source_surface: "timeline",
                                source: "WWW",
                                attachments: d,
                                audience: {to_id: r},
                                message: {ranges: [], text: n},
                                with_tags_ids: [],
                                inline_activities: [],
                                explicit_place_id: "0",
                                text_format_preset_id: "0",
                                logging: {composer_session_id: ""},
                                tracking: [null],
                                actor_id: s,
                                client_mutation_id: "3"
                            },
                            displayCommentsFeedbackContext: null,
                            displayCommentsContextEnableComment: null,
                            displayCommentsContextIsAdPreview: null,
                            displayCommentsContextIsAggregatedShare: null,
                            displayCommentsContextIsStorySet: null,
                            feedLocation: "TIMELINE",
                            feedbackSource: 0,
                            focusCommentID: null,
                            gridMediaWidth: null,
                            scale: 1,
                            privacySelectorRenderLocation: "COMET_STREAM",
                            renderLocation: "timeline",
                            useDefaultActor: !1,
                            inviteShortLinkKey: null,
                            isFeed: !0,
                            isFundraiser: !1,
                            isFunFactPost: !1,
                            isGroup: !1,
                            isTimeline: !1,
                            isSocialLearning: !1,
                            isPageNewsFeed: !1,
                            isProfileReviews: !1,
                            UFI2CommentsProvider_commentsKey: e,
                            useCometPhotoViewerPlaceholderFrag: !0,
                            hashtag: null,
                            canUserManageOffers: !1
                        }, l = {
                            __a: "1",
                            fb_dtsg: a.data.dtsg,
                            fb_api_caller_class: "RelayModern",
                            fb_api_req_friendly_name: e,
                            variables: JSON.stringify(u),
                            doc_id: t
                        }, c = await fetch("https://www.facebook.com/api/graphql/", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/x-www-form-urlencoded",
                                Accept: "text/html,application/json",
                                "x-fb-friendly-name": e
                            },
                            body: function (e) {
                                var t = [];
                                for (var n in e) e.hasOwnProperty(n) && t.push(encodeURIComponent(n) + "=" + encodeURIComponent(e[n]));
                                return t.join("&")
                            }(l)
                        });
                        await c.json(), o(!0)
                    } catch (e) {
                        a(e)
                    }
                })),
                sendMessage: async (e, t, n, r, i, o = !1) => (chrome.storage.local.set({receiverId: n}, (function () {
                })), new Promise((async (t, n) => {
                    try {
                        const n = await new Promise(((e, t) => {
                            chrome.storage.local.get(["fire", "advance_wishser_fire", "followup_wihser_fire", "toggleBtnCurr", "toggleBtnAdv", "toggleBtnFollow"], (function (n) {
                                if (chrome.runtime.lastError) return t(chrome.runtime.lastError);
                                e(n)
                            }))
                        })), {
                            fire: o,
                            advance_wishser_fire: a,
                            followup_wihser_fire: u,
                            toggleBtnCurr: l,
                            toggleBtnAdv: c,
                            toggleBtnFollow: d
                        } = n;
                        f().then((async n => (n.data.fbId, await s(e, r, "", i), t(!0))))
                    } catch (e) {
                        t(!1)
                    }
                }))),
                checkNextExecutionDate: async e => new Promise((async (t, n) => {
                    try {
                        let n = r.bw_base_url + r.bw_apis.scheduler.checkNextExecutionDate;
                        var i = await fetch(n, {
                            method: "POST",
                            headers: {"Content-Type": "application/json", Accept: "text/html,application/json"},
                            body: JSON.stringify(e)
                        });
                        return t({data: await i.json(), status: !0})
                    } catch (e) {
                        return t({data: [], status: !1, message: e.message})
                    }
                })),
                createNextExecutionDate: async e => new Promise((async (t, n) => {
                    try {
                        let n = r.bw_base_url + r.bw_apis.scheduler.createNextExecutionDate;
                        var i = await fetch(n, {
                            method: "POST",
                            headers: {"Content-Type": "application/json", Accept: "text/html,application/json"},
                            body: JSON.stringify(e)
                        });
                        return t({data: await i.json(), status: !0})
                    } catch (e) {
                        return t({data: [], status: !1, message: e.message})
                    }
                })),
                uploadImage: m,
                uploadMessageImage: async (e, t, n, r, i) => new Promise((async (t, i) => {
                    chrome.storage.local.get(["fire", "advance_wishser_fire", "followup_wihser_fire", "toggleBtnCurr", "toggleBtnAdv", "toggleBtnFollow"], (async function (i) {
                        i.fire, i.advance_wishser_fire, i.followup_wihser_fire, i.toggleBtnCurr, i.toggleBtnAdv, i.toggleBtnFollow;
                        var o = await fetch(n);
                        await o.blob();
                        let a = await f();
                        a.data.fbId, a.data.dtsg, await s(e, r, n), t(!0)
                    }))
                }))
            }
        }, 7340: (e, t, n) => {
            let r = jQuery = n(9755);
            const i = n(9669);
            e.exports = {
                makeApiRequest: function (e, t, n, i) {
                    if (0 !== Object.keys(i).length && i.constructor === Object) {
                        let o = i;
                        return o["Content-Type"] = "application/json", o["Access-Control-Allow-Origin"] = "*", console.log("head :: ", JSON.stringify(o, null, 4)), new Promise((i => {
                            r.ajax({
                                url: n, type: e, data: t, headers: o, success: e => {
                                    i(e)
                                }, error: e => {
                                    console.log("e", e), i(e)
                                }
                            })
                        }))
                    }
                    return new Promise((i => {
                        r.ajax({
                            url: n, type: e, data: t, success: e => {
                                i(e)
                            }, error: e => {
                                i({status: !1, message: "Please check your request and retry."})
                            }
                        })
                    }))
                }, makePostAxiosCall: () => {
                    i.get("http://localhost:8000/api").then((e => {
                    }))
                }, makeFetchCalls: async (e, t) => new Promise((async (n, r) => {
                    try {
                        var i = await fetch(e, {
                            method: "POST",
                            headers: {"Content-Type": "application/json", Accept: "text/html,application/json"},
                            body: JSON.stringify(t)
                        });
                        return n({data: await i.json(), status: !0})
                    } catch (e) {
                        return console.log("error", e), n({data: [], status: !1, message: e.message})
                    }
                }))
            }
        }, 8593: e => {
            "use strict";
            e.exports = JSON.parse('{"name":"axios","version":"0.21.4","description":"Promise based HTTP client for the browser and node.js","main":"index.js","scripts":{"test":"grunt test","start":"node ./sandbox/server.js","build":"NODE_ENV=production grunt build","preversion":"npm test","version":"npm run build && grunt version && git add -A dist && git add CHANGELOG.md bower.json package.json","postversion":"git push && git push --tags","examples":"node ./examples/server.js","coveralls":"cat coverage/lcov.info | ./node_modules/coveralls/bin/coveralls.js","fix":"eslint --fix lib/**/*.js"},"repository":{"type":"git","url":"https://github.com/axios/axios.git"},"keywords":["xhr","http","ajax","promise","node"],"author":"Matt Zabriskie","license":"MIT","bugs":{"url":"https://github.com/axios/axios/issues"},"homepage":"https://axios-http.com","devDependencies":{"coveralls":"^3.0.0","es6-promise":"^4.2.4","grunt":"^1.3.0","grunt-banner":"^0.6.0","grunt-cli":"^1.2.0","grunt-contrib-clean":"^1.1.0","grunt-contrib-watch":"^1.0.0","grunt-eslint":"^23.0.0","grunt-karma":"^4.0.0","grunt-mocha-test":"^0.13.3","grunt-ts":"^6.0.0-beta.19","grunt-webpack":"^4.0.2","istanbul-instrumenter-loader":"^1.0.0","jasmine-core":"^2.4.1","karma":"^6.3.2","karma-chrome-launcher":"^3.1.0","karma-firefox-launcher":"^2.1.0","karma-jasmine":"^1.1.1","karma-jasmine-ajax":"^0.1.13","karma-safari-launcher":"^1.0.0","karma-sauce-launcher":"^4.3.6","karma-sinon":"^1.0.5","karma-sourcemap-loader":"^0.3.8","karma-webpack":"^4.0.2","load-grunt-tasks":"^3.5.2","minimist":"^1.2.0","mocha":"^8.2.1","sinon":"^4.5.0","terser-webpack-plugin":"^4.2.3","typescript":"^4.0.5","url-search-params":"^0.10.0","webpack":"^4.44.2","webpack-dev-server":"^3.11.0"},"browser":{"./lib/adapters/http.js":"./lib/adapters/xhr.js"},"jsdelivr":"dist/axios.min.js","unpkg":"dist/axios.min.js","typings":"./index.d.ts","dependencies":{"follow-redirects":"^1.14.0"},"bundlesize":[{"path":"./dist/axios.min.js","threshold":"5kB"}]}')
        }, 6725: e => {
            "use strict";
            e.exports = JSON.parse('{"extId":"626fd5cfdd18e80f9b97b523","appName":"Birthday messaging","loginURL":"https://app.kyubi.io/api/end-user/login","logoutURL":null,"forgotPassURL":"https://app.kyubi.io/api/end-user/generate-password-token","changePassURL":"https://app.kyubi.io/api/end-user/update-password","checkUserStatusURL":"https://app.kyubi.io/api/end-user/get-status","youtubeLink":null,"youtubeLink2":null,"signupURL":"https://www.birthdaymessaging.io","description":{"short_description":"Birthday Messaging has got your back covered when it comes to messaging friends on Facebook.","long_description":"LEVERAGE your friends birthday to get leads and sales with just a click!!!"},"logo":{"small_icon":"./images/62619b191202d2547f4aa10a-Birthday_messaging-1668510756126-small_icon.png","medium_icon":"./images/62619b191202d2547f4aa10a-Birthday_messaging-1668510756188-medium_icon.png","large_icon":"./images/62619b191202d2547f4aa10a-Birthday_messaging-1668510756252-large_icon.png","primary_logo":"./images/62619b191202d2547f4aa10a-Birthday_messaging-1677008429254-primary_logo.png","secondary_logo":"./images/62619b191202d2547f4aa10a-Birthday_messaging-1668510756400-secondary_logo.png","background_image":"./images/62619b191202d2547f4aa10a-Birthday_messaging-1651504570756-background_image.png"},"loader":{"preLoader":"./images/62619b191202d2547f4aa10a-Birthday_messaging-1652460588778-pre_loader.gif","replyLoader":"./images/62619b191202d2547f4aa10a-Birthday_messaging-1652460588849-reply_loader.gif","customLoader":"./images/62619b191202d2547f4aa10a-Birthday_messaging-1652460588901-custom_loader.gif"},"footer":{"poweredBy":{"label":"BIRTHDAYMESSAGING.IO","url":"https://birthdaymessaging.io/","willBeDisplayed":true},"partnership":{"label":"birthdaymessaging.com","url":"https://birthdaymessaging.com","willBeDisplayed":true},"chatSupport":{"label":"Chat Support","url":"https://m.me/112187374813614","willBeDisplayed":true},"officialGroup":{"label":"Birthday Messaging","url":"https://www.facebook.com/groups/367675895401967","willBeDisplayed":true},"showFooter":true},"isLive":true,"advertisementTextHtml":null,"mailTo":"support@birthdaymessaging.io","publicVapidKey":"BHcFkqcSHe3BS6EPkUWzYCXM2v4nSd541MqGyEao2EaSQeaQ_xfZrb8IcSasVN1G5pAwmDpXLNIjR7kTnEePOCA","clearSubscriptionObjectURL":"https://app.kyubi.io/api/clear-subscription-object","trainingVideos":"https://adilo.bigcommand.com/watch/9Y_wRLa7"}')
        }, 9455: e => {
            "use strict";
            e.exports = JSON.parse('{"kyubi_base_url":"https://app.kyubi.io/api/","login_api":"end-user/login","forgot_password_api":"end-user/generate-password-token","change_password_api":"end-user/update-password","check_status":"end-user/get-status","menus":[{"name":"Logout","img":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'14\' height=\'14\' viewBox=\'0 0 14 14\'><path d=\'M10.778,3H9.222v7.778h1.556Zm3.757,1.688-1.1,1.1A5.382,5.382,0,0,1,15.444,10,5.444,5.444,0,1,1,6.562,5.784l-1.1-1.1A6.994,6.994,0,1,0,17,10,6.947,6.947,0,0,0,14.534,4.688Z\' transform=\'translate(-3 -3)\' fill=\'#ff5367\'/></svg>","url":"#","id":"logout"}],"extensionId":"5fbc0716a4a7967e5fe87571","extensionElements":{"title":"Birthday Wisher","footer_links":{"powered_by":"https://www.tier5.us/","official_page":"https://facebook.com","fb_group":"","chat_support":"","signup_link":"https://www.birthdaywisher.io/"}},"facebook_links":{"birthday_page":"https://facebook.com/birthdays","m_basic_two":""},"bw_base_url":"https://db.birthdaymessaging.io/api/","bw_apis":{"login":"auth/login","checkStatus":"auth/checkStatus","post":{"createOrUpdate":"post/create","getall":"post/findall","delete":"post/delete","fetchRandomPost":"post/fetchRandomPost"},"image":{"create":"image/create","getall":"image/findAll","delete":"image/delete","fetchRandomImage":"image/fetchRandomImage"},"scheduler":{"checkNextExecutionDate":"scheduler/check-next-execution-date","createNextExecutionDate":"scheduler/create-next-execution-day","fetchScheduledTime":"scheduler/fetch-my-scheduled-time"},"message":{"group":{"createOrUpdate":"message/createGroup","getAll":"message/findAllGroups","delete":"message/deleteGroup","fetchRandomGroupMessage":"message/fetchGroupRandomMessage"},"segments":{"createOrUpdate":"message/createSegment","getAll":"message/findAllSegments","delete":"message/deleteSegment"}}}}')
        }
    }, t = {};

    function n(r) {
        var i = t[r];
        if (void 0 !== i) return i.exports;
        var o = t[r] = {id: r, loaded: !1, exports: {}};
        return e[r].call(o.exports, o, o.exports, n), o.loaded = !0, o.exports
    }

    n.nmd = e => (e.paths = [], e.children || (e.children = []), e), (() => {
        const e = n(1182), t = (n(6725), n(7340)), r = n(9455), i = n(381), {sendMessage: o, chill: a} = n(1182);
        let s;
        const u = chrome.runtime, l = chrome.storage.local;
        chrome.identity, chrome.tabs, u.onMessage.addListener((async (e, t, n) => {
            try {
                e.type
            } catch (e) {
            }
        }));
        const c = (e, t) => {
            chrome.alarms.get(e, (n => {
                n || chrome.alarms.create(e, {periodInMinutes: t, delayInMinutes: t})
            }))
        };

        function d(n, i, o, a) {
            return new Promise((async (s, u) => {
                try {
                    let u = "", l = null, c = r.bw_base_url + r.bw_apis.message.group.fetchRandomGroupMessage,
                        d = {bw_token: n, group_id: i}, f = await t.makeFetchCalls(c, d);
                    if ("1" == f.data.code) {
                        if (u = f.data.payload.message.replace("{First_Name}", o.first_name).replace("{Last_Name}", o.last_name).replace("{Today}", e.fetchTodaysDay()), u.includes("[Image]") && a >= 2) {
                            let e = r.bw_base_url + r.bw_apis.image.fetchRandomImage, i = {bw_token: n},
                                a = await t.makeFetchCalls(e, i);
                            a && a.data.payload.data.url && a.status && (l = a.data.payload.data.url.replace("MERGE_TAG", o.name)), u = u.replace("[Image]", "")
                        } else u = u.replace("[Image]", "");
                        return await e.chill("4000"), s({
                            status: !0,
                            payload: {birthdayType: o.birthdayType, message: u, image: l},
                            message: `framed message and now its ready to send to ${o.first_name}`
                        })
                    }
                } catch (e) {
                    u({status: !1, payload: {}, message: e.message})
                }
            }))
        }

        function f(n, i, o) {
            return new Promise((async (a, s) => {
                try {
                    let s = "", u = null, l = r.bw_base_url + r.bw_apis.post.fetchRandomPost, c = {
                        bw_token: n,
                        gender: i >= 5 && null != o.gender_option && o.gender_option ? o.gender : "NEUTRAL"
                    }, d = await t.makeFetchCalls(l, c);
                    if (d.data.status) {
                        if (s = d.data.payload.data.content.replace("[Tag Person]", o.name).replace("[Today]", e.fetchTodaysDay()), s.includes("[Image]") && i >= 2) {
                            let e = r.bw_base_url + r.bw_apis.image.fetchRandomImage, i = {bw_token: n},
                                a = await t.makeFetchCalls(e, i);
                            a && a.data.payload.data.url && a.status && (u = a.data.payload.data.url.replace("MERGE_TAG", o.name)), s = s.replace("[Image]", "")
                        } else s = s.replace("[Image]", "");
                        return await e.chill("4000"), a({
                            status: !0,
                            payload: {message: s, image: u},
                            message: `framed post and now its ready to send ${o.name}`
                        })
                    }
                } catch (e) {
                    s({status: !1, payload: {}, message: e.message})
                }
            }))
        }

        c("Scheduler", 1), c("Bank", 1), chrome.alarms.onAlarm.addListener((async t => {
            switch (t.name) {
                case"Scheduler":
                    (async () => {
                        try {
                            chrome.storage.local.get(["delayMilliSecs"]).then((e => {
                                s = e.delayMilliSecs
                            })), i().toString(), chrome.storage.local.get(["fire", "posts", "messages", "store", "advance_wishser_fire", "followup_wihser_fire"], (async function (t) {
                                if (null != t && null != t.store && null != t.store.user && null != t.fire && t.fire || null != t.advance_wishser_fire && t.advance_wishser_fire || null != t.followup_wihser_fire && t.followup_wihser_fire) {
                                    let n = await e.checkNextExecutionDate({bw_token: t.store.user.bw_token});
                                    n.status && n.data.status && (chrome.alarms.clear("bwRunning"), chrome.alarms.clear("ArchiveDelay"), c("bwRunning", 1), chrome.windows.getAll({}, (t => {
                                        t.length > 0 && chrome.storage.local.get(["fire", "posts", "messages", "store", "advance_wishser_fire", "followup_wihser_fire", "advanceDay", "followUpDay", "scheduled_time", "selectMessageGroup", "gender_option", "selectMessageMaleGroup", "selectMessageFemaleGroup", "selectAHBDMessageGroup", "selectFollowUpMessageGroup", "toggleBtnCurr", "toggleBtnAdv", "toggleBtnFollow"], (async function (t) {
                                            let n = t.fire, r = t.posts, o = t.messages, a = t.store,
                                                s = t.store.user.plan, u = t.advance_wishser_fire,
                                                c = t.followup_wihser_fire, d = t.advanceDay, f = t.followUpDay,
                                                h = (t.scheduled_time, t.selectMessageGroup), p = t.gender_option,
                                                m = t.selectMessageMaleGroup, g = t.selectMessageFemaleGroup,
                                                y = a.user.bw_token, v = t.selectAHBDMessageGroup,
                                                w = t.selectFollowUpMessageGroup, _ = (t.toggleBtnCurr, []);
                                            if (u || n || c) {
                                                let t = await e.scanFB(), a = t.todays_birthdays,
                                                    x = t.monthly_birthdays;
                                                if (a.length > 0 || x.length > 0) {
                                                    let a = i().format("MM"), k = i().add(d, "days").format("DD"),
                                                        S = i().add(d, "days").format("MM"),
                                                        T = i().subtract(f, "days").format("DD"),
                                                        D = i().subtract(f, "days").format("MM");
                                                    if (u && s >= 3 && null != v && null != v && v) if (S > a) {
                                                        let e = x[2].node.friends.edges;
                                                        for (let t = 0; t < e.length; t++) if (e[t].node.birthdate.day == k && e[t].node.birthdate.month == S) {
                                                            let n = {
                                                                name: e[t].node.name,
                                                                profile_url: e[t].node.profile_url,
                                                                user_id: e[t].node.id,
                                                                first_name: e[t].node.name.split(" ")[0],
                                                                last_name: e[t].node.name.split(" ")[1],
                                                                birthdayType: "advance"
                                                            }, r = v;
                                                            _.push({
                                                                bw_token: y,
                                                                groupId: r,
                                                                payload: n,
                                                                plan: s,
                                                                type: "message"
                                                            })
                                                        }
                                                    } else {
                                                        let e = x[1].node.friends.edges;
                                                        for (let t = 0; t < e.length; t++) if (e[t].node.birthdate.day == k && e[t].node.birthdate.month == S) {
                                                            let n = {
                                                                name: e[t].node.name,
                                                                profile_url: e[t].node.profile_url,
                                                                user_id: e[t].node.id,
                                                                first_name: e[t].node.name.split(" ")[0],
                                                                last_name: e[t].node.name.split(" ")[1],
                                                                birthdayType: "advance"
                                                            }, r = v;
                                                            _.push({
                                                                bw_token: y,
                                                                groupId: r,
                                                                payload: n,
                                                                plan: s,
                                                                type: "message"
                                                            })
                                                        }
                                                    }
                                                    if (n && (null != r && r || null != o && o) && t.todays_birthdays.length > 0) for (let n = 0; n < t.todays_birthdays.length; n++) {
                                                        let i = {
                                                            name: t.todays_birthdays[n].node.name,
                                                            profile_url: t.todays_birthdays[n].node.profile_url,
                                                            user_id: t.todays_birthdays[n].node.id,
                                                            gender: t.todays_birthdays[n].node.gender ? t.todays_birthdays[n].node.gender : "NEUTRAL",
                                                            first_name: t.todays_birthdays[n].node.name.split(" ")[0],
                                                            last_name: t.todays_birthdays[n].node.name.split(" ")[1],
                                                            gender_option: p,
                                                            birthdayType: "current"
                                                        };
                                                        if (r || o) {
                                                            let t = null != p && p && null != s && s >= 5 ? null != i.gender && "MALE" == i.gender && null != m && m ? m : null != i.gender && "FEMALE" == i.gender && null != g && g ? g : h : null != h && h ? h : null;
                                                            null != t && o && _.push({
                                                                bw_token: y,
                                                                groupId: t,
                                                                payload: i,
                                                                plan: s,
                                                                type: "message"
                                                            }), r && _.push({
                                                                bw_token: y,
                                                                payload: i,
                                                                plan: s,
                                                                type: "post"
                                                            }), await e.chill(3e3)
                                                        }
                                                    }
                                                    if (c && s >= 4 && null != w && null != w && w) if (D < a) {
                                                        let e = x[0].node.friends.edges;
                                                        for (let t = 0; t < e.length; t++) if (e[t].node.birthdate.day == T && e[t].node.birthdate.month == D) {
                                                            let n = {
                                                                name: e[t].node.name,
                                                                profile_url: e[t].node.profile_url,
                                                                user_id: e[t].node.id,
                                                                first_name: e[t].node.name.split(" ")[0],
                                                                last_name: e[t].node.name.split(" ")[1],
                                                                birthdayType: "followup"
                                                            }, r = w;
                                                            _.push({
                                                                bw_token: y,
                                                                groupId: r,
                                                                payload: n,
                                                                plan: s,
                                                                type: "message"
                                                            })
                                                        }
                                                    } else {
                                                        let e = x[1].node.friends.edges;
                                                        for (let t = 0; t < e.length; t++) if (e[t].node.birthdate.day == T && e[t].node.birthdate.month == D) {
                                                            let n = {
                                                                name: e[t].node.name,
                                                                profile_url: e[t].node.profile_url,
                                                                user_id: e[t].node.id,
                                                                first_name: e[t].node.name.split(" ")[0],
                                                                last_name: e[t].node.name.split(" ")[1],
                                                                birthdayType: "followup"
                                                            }, r = w;
                                                            _.push({
                                                                bw_token: y,
                                                                groupId: r,
                                                                payload: n,
                                                                plan: s,
                                                                type: "message"
                                                            })
                                                        }
                                                    }
                                                    var b = i().format("MM/DD/YYYY HH:mm:ss");
                                                    l.set({currTime: b}, (() => {
                                                    })), l.remove("bank"), l.set({bank: _}, (() => {
                                                    })), await e.createNextExecutionDate({bw_token: y})
                                                }
                                            }
                                        }))
                                    })))
                                }
                            }))
                        } catch (e) {
                        }
                    })();
                    break;
                case"Bank":
                    !async function () {
                        try {
                            e.checkAuthStatus(), l.get(["bank"], (async function (t) {
                                let n = t.bank, r = t.bank;
                                if (null != n && n.length > 0) {
                                    let t = 0;
                                    for (let i = 0; i < n.length; i++) if (1 == t) ; else {
                                        t = 1;
                                        let o = n[i].bw_token, s = null != n[i].groupId ? n[i].groupId : null,
                                            u = n[i].payload, c = n[i].plan;
                                        if (u.user_id, "message" == n[i].type) {
                                            let t = await d(o, s, u, c);
                                            r.splice(i, 1), l.set({bank: r}, (() => {
                                                r.map((e => {
                                                }))
                                            })), t.status && null == t.payload.image ? (e.sendMessage(u, "", u.user_id, t.payload.message, u.birthdayType), await a(1e4)) : (e.uploadMessageImage(u, u.user_id, t.payload.image, t.payload.message, u.birthdayType), await a(1e4))
                                        } else if ("post" == n[i].type) {
                                            let t = await f(o, c, u);
                                            if (r.splice(i, 1), l.set({bank: r}, (() => {
                                                r.map((e => {
                                                }))
                                            })), t.status) {
                                                let n = "ComposerStoryCreateMutation", r = "7517691441636945";
                                                e.createPostOnUsersTimeline(n, r, t.payload.message, u.user_id, t.payload.image), await a(1e4)
                                            }
                                        }
                                    }
                                }
                            }))
                        } catch (e) {
                        }
                    }();
                    break;
                case"bwRunning": {
                    let e = 1, t = setInterval((function () {
                        e++, 500 == e && (clearInterval(t), chrome.alarms.clear("bwRunning"))
                    }), 1e3)
                }
            }
        }))
    })()
})();